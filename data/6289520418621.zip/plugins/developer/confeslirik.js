const axios = require('axios');

exports.run = {
    usage: ['confeslirik'],
    hidden: ['confesslirik'],
    use: 'groupid,judul lagu',
    category: 'group',
    async: async (m, { func, anya }) => {
        if (!m.text) return m.reply(func.example(m.cmd, '120363264558127828@g.us|kecewa'));
        anya.sendReact(m.chat, '🕒', m.key);
        let [groupId, perasaan] = m.text.split('|').map(t => t.trim());
        if (!(groupId && perasaan)) return m.reply(`Format salah!\nContoh: ${m.cmd} 120363264558127828@g.us|kecewa`);

        try {
            let groupMeta = await anya.groupMetadata(groupId).catch(() => null);
            if (!groupMeta) return m.reply('Bot tidak bisa akses grup tersebut.');

            // Kirim pembaruan kehadiran
            await anya.sendPresenceUpdate('composing', groupId);

            // Ambil lirik lagu
            const lyricUrl = `https://api.ryzendesu.vip/api/search/lyrics?query=${encodeURIComponent(perasaan)}`;
            const response = await axios.get(lyricUrl);
            const lyricsData = response.data;

            if (!lyricsData || lyricsData.length === 0) {
                return m.reply('Lirik tidak ditemukan untuk lagu tersebut.');
            }

            const lyrics = lyricsData[0].plainLyrics.split('\n').filter(line => line.trim().length > 0);

            // Ambil semua bot yang aktif
            const array = [anya, ...Object.values(global.jadibot).filter(x => x.user)];
            const repeatedArray = repeatArray(array, 10); // Mengulangi array bot

            // Kirim lirik ke grup
            for (let i = 0; i < lyrics.length; i++) {
                setTimeout(async () => {
                    const client = repeatedArray[i % repeatedArray.length]; // Menggunakan bot yang berbeda
                    await client.sendMessage(groupId, { text: lyrics[i] });
                }, i * 3000); // Kirim setiap baris setiap detik
            }

            m.reply('Lirik sedang dikirim ke grup.');
        } catch (err) {
            m.reply(`Gagal mengirim lirik!\n\nError: ${err.message}`);
        }
    },
    location: 'plugins/developer/confeslirik.js'
};

// Fungsi untuk mengulangi array
function repeatArray(arr, times) {
    const result = [];
    for (let i = 0; i < times; i++) {
        result.push(...arr); // Menambahkan seluruh elemen array ke hasil
    }
    return result;
}