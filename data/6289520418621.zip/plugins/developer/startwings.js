const {
    Client
} = require('ssh2'); // Mengimpor Client dari ssh2

exports.run = {
    usage: ['startwings'],
    use: 'ipvps,pwvps',
    category: 'cpanel',
    async: async (m, {
        func,
        anya
    }) => {
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');
        if (!m.text) return m.reply(func.example(m.cmd, 'ipvps|pwvps|token'));

        let t = m.text.split('|');
        if (t.length !== 3) return m.reply("Cara Penggunaan: IPVps|PwVps|Token");

        let ipvps = t[0];
        let passwd = t[1];
        let token = t[2];

        const connSettings = {
            host: ipvps,
            port: '22',
            username: 'root',
            password: passwd
        };

        const command = `${token} && systemctl start wings`;

        const ress = new Client();

        ress.on('ready', () => {
            ress.exec(command, (err, stream) => {
                if (err) {
                    m.reply('Gagal mengeksekusi perintah: ' + err.message);
                    return ress.end();
                }

                stream.on('close', async (code, signal) => {
                    await anya.reply(m.chat, `*Berhasil menjalankan wings ✅*\n*Status wings : *aktif*`, m, {
                        expiration: m.expiration
                    })
                    ress.end();
                }).on('data', async (data) => {
                    console.log(data.toString());
                }).stderr.on('data', (data) => {
                    stream.write("y\n");
                    stream.write("systemctl start wings\n");
                    m.reply('STDERR: ' + data.toString()); // Kirim error ke pengguna
                });
            });
        }).on('error', (err) => {
            console.log('Connection Error: ' + err);
            m.reply('Katasandi atau IP tidak valid');
        }).connect(connSettings);
    },
    devs: true
};