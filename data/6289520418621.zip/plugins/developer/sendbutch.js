exports.run = {
    usage: ['sendbutch'],
    use: 'text',
    category: 'developer',
    async: async (m, {
        func,
        anya,
        setting
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'halo'))
        const buttons = [/*{
                index: 1,
                urlButton: {
                    displayText: "website",
                    url: 'https://websiteanyaofficial.vercel.app'
                }
            },*/
            {
                index: 1,
                quickReplyButton: {
                    displayText: 'nice try',
                    id: 'https://websiteanyaofficial.vercel.app'
                }
            }
        ];
        const buttonsMessage = {
            text: m.text.trim(),
            title: '',
            footer: '𝗈𝖿𝖿𝗂𝖼𝗂𝖺𝗅 𝖺𝗇𝗒𝖺 𝖻𝗈𝗍',
            viewOnce: true,
            templateButtons: buttons,
            headerType: 2
        }
        await anya.sendMessage(global.newsletter, buttonsMessage).then(() => anya.sendReact(m.chat, '✅', m.key))
            .catch(() => anya.sendReact(m.chat, '❌', m.key))
    },
    devs: true,
    location: 'plugins/developer/sendbutch.js'
}