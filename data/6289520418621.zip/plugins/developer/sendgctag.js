exports.run = {
    usage: ['sendgctag'],
    hidden: ['sendgrouptag'],
    category: 'developer',
    async: async (m, { func, anya }) => {
        // Check if the sender is the owner
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');

        // Extract the group ID and message from the command
        const groupId = '120363347494579697@g.us'; // Replace with your group ID
        const message = m.text.split(' ').slice(0).join(' '); // Get the message after the command

        // Check if a message was provided
        if (!message) return m.reply('Silakan masukkan pesan yang ingin dikirim.');

        try {
            // Get the group members
            const groupMembers = await anya.groupMetadata(groupId);
            const memberIds = groupMembers.participants.map(participant => participant.id);

            // Create a mention string for the members
            const mentions = memberIds.map(id => `@${id.split('@')[0]}`).join(' ');

            // Combine the mentions with the message
            const fullMessage = `${message}`;

            // Send the message to the group
            await anya.reply(groupId, fullMessage, func.fverified, {
                mentions: memberIds,
                expiration: m.expiration
            });
            m.reply('Pesan berhasil dikirim ke grup.');
        } catch (error) {
            console.error(error);
            m.reply('Terjadi kesalahan saat mengirim pesan.');
        }
    }
};