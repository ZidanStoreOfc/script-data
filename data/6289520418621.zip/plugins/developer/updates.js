let axios = require("axios"),
    fs = require("fs");

function changeVersion(e, t) {
    var a = e.split(".").map(Number);
    if (3 !== a.length) throw new Error('Format versi tidak valid. Harus dalam format "mayor.minor.patch".');
    switch (t) {
        case "mayor":
            a[0] += 1, a[1] = 0, a[2] = 0;
            break;
        case "minor":
            a[1] += 1, a[2] = 0;
            break;
        case "patch":
            a[2] += 1;
            break;
        default:
            throw new Error('Tipe versi tidak valid. Harus "mayor", "minor", atau "patch".')
    }
    return a.join(".")
}
exports.run = {
    usage: ["update-vip", "remove-vip", "update-free", "remove-free", "listupdate-vip", "listupdate-free", "cversion"],
    use: "parameter",
    category: "developer",
    async: async (a, {
        anya: r
    }) => {
        let n = "ZidanStoreOfc",
            o = "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";
        let l = "updates";
        async function e(e) {
            var t = (await axios.get(`https://api.github.com/repos/${n}/${l}/contents/` + e, {
                    headers: {
                        Authorization: "Bearer " + o
                    }
                })).data,
                a = Buffer.from(t.content, "base64").toString("utf8");
            return {
                pathName: e,
                fileData: t,
                updateData: JSON.parse(a)
            }
        }
        async function i(e, t, a) {
            try {
                var r = JSON.stringify(e, null, 2),
                    i = Buffer.from(r).toString("base64"),
                    p = await fetch(`https://api.github.com/repos/${n}/${l}/contents/` + a, {
                        method: "PUT",
                        headers: {
                            Authorization: "token " + o,
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            message: "Add files via upload",
                            sha: t,
                            content: i
                        })
                    }),
                    s = await p.json();
                return p.ok ? {
                    status: !0,
                    creator: "ZidanDev.",
                    result: s.content.html_url
                } : (console.error("Failed to upload file:", s.message), {
                    status: !1,
                    creator: "ZidanDev.",
                    message: s.message
                })
            } catch (e) {
                return console.error("Error occurred during file upload:", e.message), {
                    status: !0,
                    creator: "ZidanDev.",
                    message: e.message
                }
            }
        }
        switch (a.command) {
            case "update-vip": {
                if (!a.text) return a.reply("reply code or file script with `value` & `filepath`.");
                var [p, ...s] = a.text.split(" ");
                if (0 == s.length) return a.reply("filepath parameter is required.");
                var {
                    pathName: u,
                    fileData: d,
                    updateData: f
                } = await e("update-vip.json");
                let t = s.join(" ");
                if (Array.isArray(f.update))
                    if ("add" === p) {
                        let e;
                        if (a.quoted && /application\/(javascript|octet-stream)/i.test(a.quoted.mime)) {
                            s = await a.quoted.download();
                            e = Buffer.from(s, "base64").toString("utf-8")
                        } else {
                            if (!a.quoted || !a.quoted.text) return a.reply("reply code or file script with file path..");
                            e = a.quoted.text
                        }
                        await r.sendReact(a.chat, "🕒", a.key);
                        s = f.update.find(e => e.path === t);
                        s ? s.code = JSON.stringify(e) : f.update.push({
                            path: t,
                            code: JSON.stringify(e)
                        }), await i(f, d.sha, u).then(e => {
                            if (!e.status) return a.reply(e.message);
                            e = `successfully \`add updated\` vip script on file \`${t}\``;
                            r.reply(a.chat, e, a, {
                                expiration: a.expiration
                            })
                        })
                    } else if ("del" === p) {
                    if (0 == f.update.length) return a.reply("Data empty.");
                    s = f.update.findIndex(e => e.path === t); - 1 !== s ? (f.update.splice(s, 1), await i(f, d.sha, u).then(e => {
                        if (!e.status) return a.reply(e.message);
                        e = `successfully \`del updated\` vip script on file \`${t}\``;
                        r.reply(a.chat, e, a, {
                            expiration: a.expiration
                        })
                    })) : a.reply(`filepath \`${t}\` not found.

*List File Path:*
` + f.update.map(e => "- " + e.path).join("\n"))
                } else a.reply("reply code or file script with `add` / `del` <filepath>");
                else a.reply("update data is not an array.")
            }
            break;
            case "remove-vip": {
                if (!a.text) return a.reply("value & filepath paramater is required.");
                var [p, ...s] = a.text.split(" ");
                if (0 == s.length) return a.reply("filepath parameter is required.");
                var {
                    pathName: d,
                    fileData: u,
                    updateData: f
                } = await e("update-vip.json");
                let t = s.join(" ");
                if (Array.isArray(f.remove))
                    if ("add" === p) {
                        if (f.remove.includes(t)) return a.reply("this filepath already in database.");
                        f.remove.push(t), await i(f, u.sha, d).then(e => {
                            if (!e.status) return a.reply(e.message);
                            e = `successfully \`add removed\` vip script on file \`${t}\``;
                            r.reply(a.chat, e, a, {
                                expiration: a.expiration
                            })
                        })
                    } else if ("del" === p) {
                    if (0 == f.remove.length) return a.reply("Data empty.");
                    s = f.remove.indexOf(t); - 1 !== s ? (f.remove.splice(s, 1), await i(f, u.sha, d).then(e => {
                        if (!e.status) return a.reply(e.message);
                        e = `successfully \`del removed\` vip script on file \`${t}\``;
                        r.reply(a.chat, e, a, {
                            expiration: a.expiration
                        })
                    })) : a.reply(`filepath \`${t}\` not found.

*List File Path:*
` + f.remove.map(e => "- " + e).join("\n"))
                } else a.reply("input the parameters `add` / `del` <file path>");
                else a.reply("remove data is not an array.")
            }
            break;
            case "update-free": {
                if (!a.text) return a.reply("reply code or file script with `value` & `filepath`.");
                var [p, ...s] = a.text.split(" ");
                if (0 == s.length) return a.reply("filepath parameter is required.");
                var {
                    pathName: u,
                    fileData: d,
                    updateData: f
                } = await e("update-free.json");
                let t = s.join(" ");
                if (Array.isArray(f.update))
                    if ("add" === p) {
                        let e;
                        if (a.quoted && /application\/(javascript|octet-stream)/i.test(a.quoted.mime)) {
                            s = await a.quoted.download();
                            e = Buffer.from(s, "base64").toString("utf-8")
                        } else {
                            if (!a.quoted || !a.quoted.text) return a.reply("reply code or file script with `value` & `filepath`.");
                            e = a.quoted.text
                        }
                        await r.sendReact(a.chat, "🕒", a.key);
                        s = f.update.find(e => e.path === t);
                        s ? s.code = JSON.stringify(e) : f.update.push({
                            path: t,
                            code: JSON.stringify(e)
                        }), await i(f, d.sha, u).then(e => {
                            if (!e.status) return a.reply(e.message);
                            e = `successfully \`add updated\` free script on file \`${t}\``;
                            r.reply(a.chat, e, a, {
                                expiration: a.expiration
                            })
                        })
                    } else if ("del" === p) {
                    if (0 == f.update.length) return a.reply("Data empty.");
                    s = f.update.findIndex(e => e.path === t); - 1 !== s ? (f.update.splice(s, 1), await i(f, d.sha, u).then(e => {
                        if (!e.status) return a.reply(e.message);
                        e = `successfully \`del updated\` free script on file \`${t}\``;
                        r.reply(a.chat, e, a, {
                            expiration: a.expiration
                        })
                    })) : a.reply(`filepath \`${t}\` not found.

*List File Path:*
` + f.update.map(e => "- " + e.path).join("\n"))
                } else a.reply("reply code or file script with `add` / `del` <filepath>")
            }
            break;
            case "remove-free": {
                if (!a.text) return a.reply("value & filepath paramater is required.");
                var [p, ...s] = a.text.split(" ");
                if (0 == s.length) return a.reply("filepath parameter is required.");
                var {
                    pathName: d,
                    fileData: u,
                    updateData: f
                } = await e("update-free.json");
                let t = s.join(" ");
                if (Array.isArray(f.remove))
                    if ("add" === p) {
                        if (f.remove.includes(t)) return a.reply("this filepath already in database.");
                        f.remove.push(t), await i(f, u.sha, d).then(e => {
                            if (!e.status) return a.reply(e.message);
                            e = `successfully \`add removed\` free script on file \`${t}\``;
                            r.reply(a.chat, e, a, {
                                expiration: a.expiration
                            })
                        })
                    } else if ("del" === p) {
                    if (0 == f.remove.length) return a.reply("Data empty.");
                    s = f.remove.indexOf(t); - 1 !== s ? (f.remove.splice(s, 1), await i(f, u.sha, d).then(e => {
                        if (!e.status) return a.reply(e.message);
                        e = `successfully \`del removed\` free script on file \`${t}\``;
                        r.reply(a.chat, e, a, {
                            expiration: a.expiration
                        })
                    })) : a.reply(`filepath \`${t}\` not found.

*List File Path:*
` + f.remove.map(e => "- " + e).join("\n"))
                } else a.reply("input the parameters `add` / `del` <file path>");
                else a.reply("remove data is not an array.")
            }
            break;
            case "listupdate-vip":
                p = (await e("update-vip.json")).updateData;
                if (0 == [...p.update, ...p.remove].length) r.reply(a.chat, "Data empty.", a, {
                    expiration: a.expiration
                });
                else {
                    let e = "乂  *LIST UPDATE SCRIPT VIP*\n\n";
                    e += "*Update Version:* " + p.version, 0 < p.update.length && (e = (e += "\n\n◦  *List Updated:*\n") + p.update.map((e, t) => t + 1 + ". " + e.path).join("\n")), 0 < p.remove.length && (e = (e += "\n\n◦  *List Removed:*\n") + p.remove.map((e, t) => t + 1 + ". " + e).join("\n")), r.reply(a.chat, e, a, {
                        expiration: a.expiration
                    })
                }
                break;
            case "listupdate-free":
                s = (await e("update-free.json")).updateData;
                if (0 == [...s.update, ...s.remove].length) r.reply(a.chat, "Data empty.", a, {
                    expiration: a.expiration
                });
                else {
                    let e = "乂  *LIST UPDATE SCRIPT FREE*\n\n";
                    e += "*Update Version:* " + s.version, 0 < s.update.length && (e = (e += "\n\n◦  *List Updated:*\n") + s.update.map((e, t) => t + 1 + ". " + e.path).join("\n")), 0 < s.remove.length && (e = (e += "\n\n◦  *List Removed:*\n") + s.remove.map((e, t) => t + 1 + ". " + e).join("\n")), r.reply(a.chat, e, a, {
                        expiration: a.expiration
                    })
                }
                break;
            case "cversion":
                if (!a.text) return a.reply("value & version parameter is required.");
                var [u, ...d] = a.text.split(" ");
                if (0 == d.length) return a.reply("version parameter is required.");
                f = d.join(" ");
                if ("vip" === u) {
                    if (!/^(mayor|minor|patch)$/i.test(f)) return a.reply('tipe versi tidak valid. Harus "mayor", "minor", atau "patch".');
                    var {
                        pathName: p,
                        fileData: s,
                        updateData: d
                    } = await e("update-vip.json");
                    let t = changeVersion(d.version, f.toLowerCase());
                    d.version = t, await i(d, s.sha, p).then(e => {
                        if (!e.status) return a.reply(e.message);
                        e = `successfully change version vip script to *${t}*`;
                        r.reply(a.chat, e, a, {
                            expiration: a.expiration
                        })
                    })
                } else if ("free" === u) {
                    if (!/^(mayor|minor|patch)$/i.test(f)) return a.reply('Tipe versi tidak valid. Harus "mayor", "minor", atau "patch".');
                    var {
                        pathName: d,
                        fileData: s,
                        updateData: p
                    } = await e("update-free.json");
                    let t = changeVersion(p.version, f.toLowerCase());
                    p.version = t, await i(p, s.sha, d).then(e => {
                        if (!e.status) return a.reply(e.message);
                        e = `successfully change version free script to *${t}*`;
                        r.reply(a.chat, e, a, {
                            expiration: a.expiration
                        })
                    })
                } else a.reply("input the parameters `vip` / `free` <version>")
        }
    },
    devs: !0,
    location: "plugins/developer/updates.js"
};