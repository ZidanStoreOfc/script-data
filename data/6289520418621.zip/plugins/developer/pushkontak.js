exports.run = {
usage: ['pushkontak', 'pushkon'],
use: 'text',
category: 'developer',
async: async (m, { func, anya }) => {
const qchannel = {
            key: {
                remoteJid: 'status@broadcast',
                fromMe: false,
                participant: '0@s.whatsapp.net'
            },
            message: {
                newsletterAdminInviteMessage: {
                    newsletterJid: '120363261409301854@newsletter',
                    newsletterName: 'Powered by Anya Chan.',
                    jpegThumbnail: null,
                    caption: 'Powered By Anya Chan',
                    inviteExpiration: Date.now() + 1814400000
                }
            }
        }
if (!m.text && !m.quoted) return m.reply('Input text or reply chat.')
let members = await m.members.map(v => v.id)
let count = members.length;
let sentCount = 0;
m.reply(global.mess.wait)
for (let i = 0; i < members.length; i++) {
setTimeout(function() {
if (m.text) {
anya.sendMessage(members[i], {
text: m.text
}, {quoted: qchannel, ephemeralExpiration: m.expiration});
} else if (m.quoted) {
anya.copyNForward(members[i], m.getQuotedObj(), false);
} else if (m.text && m.quoted) {
anya.sendMessage(members[i], {
text: m.text + '\n' + m.quoted.text
}, {quoted: qchannel, ephemeralExpiration: m.expiration});
}
count--;
sentCount++;
if (count === 0) {
m.reply(`Berhasil Push Kontak:\nJumlah pesan terkirim: *${sentCount}*`);
}
}, i * 1000); // delay setiap pengiriman selama 1 detik
}
},
group: true,
devs: true
}