const { Client } = require('ssh2'); // Mengimpor Client dari ssh2

exports.run = {
    usage: ['uninstalltema'],
    use: 'ipvps,pwvps',
    category: 'cpanel',
    async: async (m, { func, anya }) => {
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');
        if (!m.text) return m.reply(func.example(m.cmd, 'ipvps|pwvps'));

        let vii = m.text.split("|");
        if (vii.length < 2) return m.reply(func.example(m.cmd, 'ipvps|pwvps'));

        global.installtema = {
            vps: vii[0], 
            pwvps: vii[1]
        };

        let ipvps = global.installtema.vps;
        let passwd = global.installtema.pwvps;

        const connSettings = {
            host: ipvps,
            port: '22',
            username: 'root',
            password: passwd
        };
        
        const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
        const ress = new Client();

        await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selesai...");

        ress.on('ready', () => {
            ress.exec(command, (err, stream) => {
                if (err) throw err;

                stream.on('close', async (code, signal) => {    
                    await m.reply("Berhasil *uninstall* tema pterodactyl ✅");
                    ress.end();
                }).on('data', async (data) => {
                    console.log(data.toString());
                    stream.write(`skyzodev\n`); // Key Token : skyzodev
                    stream.write(`2\n`);
                    stream.write(`y\n`);
                    stream.write(`x\n`);
                }).stderr.on('data', (data) => {
                    console.log('STDERR: ' + data);
                });
            });
        }).on('error', (err) => {
            console.log('Connection Error: ' + err);
            m.reply('Katasandi atau IP tidak valid');
        }).connect(connSettings);
    }
};