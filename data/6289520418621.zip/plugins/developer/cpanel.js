const is_eggs = false;
const location = '1' // ganti pake location panel lu
const fetch = require('node-fetch')

exports.run = {
    usage: [
        'listram',
        'listsrv',
        'delsrv',
        'listusr',
        'delusr',
        'addsrv',
        '1gb',
        '2gb',
        '3gb',
        '4gb',
        '5gb',
        '6gb',
        '7gb',
        '8gb',
        'unli',
        'autocpanel'
    ],
    use: 'parameter',
    category: 'cpanel',
    async: async (m, {
        func,
        anya
    }) => {
        try {
            const listcpu = {
                '1gb': '30',
                '2gb': '50',
                '3gb': '75',
                '4gb': '100',
                '5gb': '125',
                '6gb': '150',
                '7gb': '175',
                '8gb': '200',
                'unli': '0'
            }
            const listmemory = {
                '1gb': '1024',
                '2gb': '2024',
                '3gb': '3024',
                '4gb': '4024',
                '5gb': '5024',
                '6gb': '6024',
                '7gb': '7024',
                '8gb': '8024',
                'unli': '0'
            }
            const timezone = func.timezone();
            switch (m.command) {
                case 'listram': {
                    let listram = `*PRICE LIST ANYA PANEL*

⭝ ram 1𝗀𝖻 𝖼𝗉𝗎 ${listcpu['1gb']}% : 3.000
⭝ ram 2𝗀𝖻 𝖼𝗉𝗎 ${listcpu['2gb']}% : 5.000
⭝ ram 3𝗀𝖻 𝖼𝗉𝗎 ${listcpu['3gb']}% : 7.000
⭝ ram 4𝗀𝖻 𝖼𝗉𝗎 ${listcpu['4gb']}% : 9.000
⭝ ram 5𝗀𝖻 𝖼𝗉𝗎 ${listcpu['5gb']}% : 11.000
⭝ ram 6𝗀𝖻 𝖼𝗉𝗎 ${listcpu['6gb']}% : 13.000
⭝ ram 7𝗀𝖻 𝖼𝗉𝗎 ${listcpu['7gb']}% : 15.000
⭝ ram 8𝗀𝖻 𝖼𝗉𝗎 ${listcpu['8gb']}% : 17.000
⭝ ram unli 𝖼𝗉𝗎 unli : 20.000

*Benefits:*
- harga di atas untuk 1 bulan
- server private anti colong² script
- hemat kuota dan penyimpanan 
- web & wa close bot tetep jalan

*Payments:*
- Dana : 0895611957028
- Ovo : 0895611957028
- Gopay : 0895611957028
- QRIS (All Payment)

*Informations:*
- 𝗍𝗋𝖺𝗇𝗌𝖿𝖾𝗋 𝗌𝖾𝗌𝗎𝖺𝗂 𝗇𝗈𝗆𝗂𝗇𝖺Ⲓ & 𝗐𝖺𝗃𝗂𝖻 𝗌𝖾𝗋𝗍𝖺𝗄𝖺𝗇 𝖻𝗎𝗄𝗍𝗂 𝗍𝗋𝖺𝗇𝗌𝖿𝖾𝗋.
- melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
- semua pembelian bergaransi.
- tidak puas dengan layanan kami? kami kembalikan uang anda 100% dalam jangka waktu 1 jam setelah pembelian.

Berminat? Hubungi :
wa.me/${global.owner.replace(/[^0-9]/g, '')}`
                    anya.reply(m.chat, listram, m, {
                        expiration: m.expiration
                    })
                }
                break
                case 'listsrv': {
                    if (!m.isDevs) return m.reply(global.mess.devs)
                    let page = m.args[0] ? m.args[0] : '1';
                    let f = await fetch(global.panelApi.domain + '/api/application/servers?page=' + page, {
                        "method": "GET",
                        "headers": {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + global.panelApi.apikey
                        }
                    });
                    let res = await f.json();
                    let servers = res.data;
                    let sections = [];
                    let messageText = "Berikut adalah daftar server:\n\n";

                    for (let server of servers) {
                        let s = server.attributes;

                        let f3 = await fetch(global.panelApi.domain + "/api/client/servers/" + s.uuid.split`-` [0] + "/resources", {
                            "method": "GET",
                            "headers": {
                                "Accept": "application/json",
                                "Content-Type": "application/json",
                                "Authorization": "Bearer " + global.panelApi.capikey
                            }
                        });

                        let data = await f3.json();
                        let status = data.attributes ? data.attributes.current_state : s.status;
                        messageText += `ID Server: ${s.id}\n`;
                        messageText += `Nama Server: ${s.name}\n`;
                        messageText += `Status: ${status}\n\n`;
                    }
                    messageText += `Halaman: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
                    messageText += `Total Server: ${res.meta.pagination.count}`;
                    await anya.sendMessage(m.chat, {
                        text: messageText
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    });
                    if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
                        m.reply(`Gunakan perintah ${m.prefix}listsrv ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
                    }
                }
                break;
                case 'delsrv': {
                    if (!m.isDevs) return m.reply(global.mess.devs)
                    let srv = m.args[0]
                    if (!srv) return m.reply('ID nya mana?')
                    let f = await fetch(global.panelApi.domain + "/api/application/servers/" + srv, {
                        "method": "DELETE",
                        "headers": {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + global.panelApi.apikey,
                        }
                    })
                    let res = f.ok ? {
                        errors: null
                    } : await f.json()
                    if (res.errors) return m.reply('Server tidak ditemukan')
                    m.reply('Berhasil menghapus Server.')
                }
                break
                case 'listusr': {
                    if (!m.isDevs) return m.reply(global.mess.devs)
                    let page = m.args[0] ? m.args[0] : '1';
                    let f = await fetch(global.panelApi.domain + "/api/application/users?page=" + page, {
                        "method": "GET",
                        "headers": {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + global.panelApi.apikey
                        }
                    });
                    let res = await f.json();
                    let users = res.data;
                    let messageText = "Berikut list user:\n\n";
                    for (let user of users) {
                        let u = user.attributes;
                        messageText += `ID: ${u.id} - ${u.username}\n`;
                        messageText += `Status: ${u.attributes?.user?.server_limit === null ? 'Inactive' : 'Active'}\n`;
                        messageText += `First Name: ${u.first_name}\n`;
                        messageText += `Last Name: ${u.last_name}\n\n`;
                    }
                    messageText += `Page: ${res.meta.pagination.current_page}/${res.meta.pagination.total_pages}\n`;
                    messageText += `Total Users: ${res.meta.pagination.count}`;
                    await anya.sendMessage(m.chat, {
                        text: messageText
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    });
                    if (res.meta.pagination.current_page < res.meta.pagination.total_pages) {
                        m.reply(`Gunakan perintah ${m.prefix}listusr ${res.meta.pagination.current_page + 1} untuk melihat halaman selanjutnya.`);
                    }
                }
                break
                case 'delusr': {
                    if (!m.isDevs) return m.reply(global.mess.devs)
                    let usr = m.args[0]
                    if (!usr) return m.reply('ID nya mana?')
                    let f = await fetch(global.panelApi.domain + "/api/application/users/" + usr, {
                        "method": "DELETE",
                        "headers": {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + global.panelApi.apikey
                        }
                    })
                    let res = f.ok ? {
                        errors: null
                    } : await f.json()
                    if (res.errors) return m.reply('User tidak ditemukan')
                    m.reply('Berhasil menghapus User')
                }
                break
                case 'addsrv': {
                    if (!m.isDevs) return m.reply(global.mess.devs)
                    let [username, userId, ram] = m.text.split(',');
                    if (!(username && userId && ram)) return m.reply(`*Format salah!*

Penggunaan:
${m.cmd} username,userId,ram

\`Example\` : ${m.prefix}addsrv Zidan,1,3gb`)
                    let memory;
                    let disk;
                    let cpu;
                    if (/^(unli)$/i.test(ram)) {
                        memory = '0'
                        disk = '0'
                        cpu = '0'
                    } else if (/^(1gb)$/i.test(ram)) {
                        memory = '1024'
                        disk = '1024'
                        cpu = listcpu['1gb']
                    } else if (/^(2gb)$/i.test(ram)) {
                        memory = '2024'
                        disk = '2024'
                        cpu = listcpu['2gb']
                    } else if (/^(3gb)$/i.test(ram)) {
                        memory = '3024'
                        disk = '3024'
                        cpu = listcpu['3gb']
                    } else if (/^(4gb)$/i.test(ram)) {
                        memory = '4024'
                        disk = '4024'
                        cpu = listcpu['4gb']
                    } else if (/^(5gb)$/i.test(ram)) {
                        memory = '5024'
                        disk = '5024'
                        cpu = listcpu['5gb']
                    } else if (/^(6gb)$/i.test(ram)) {
                        memory = '6024'
                        disk = '6024'
                        cpu = listcpu['6gb']
                    } else if (/^(7gb)$/i.test(ram)) {
                        memory = '7024'
                        disk = '7024'
                        cpu = listcpu['7gb']
                    } else if (/^(8gb)$/i.test(ram)) {
                        memory = '8024'
                        disk = '8024'
                        cpu = listcpu['8gb']
                    } else {
                        return m.reply(`ram tidak valid!\n\n*LIST RAM* :\n- 1gb\n- 2gb\n- 3gb\n- 4gb\n- 5gb\n- 6gb\n- 7gb\n- 8gb\n- unli`)
                    }
                    let f1 = await fetch(global.panelApi.domain + "/api/application/nests/5/eggs" + (is_eggs ? '/' + global.panelApi.eggs : ''), {
                        "method": "GET",
                        "headers": {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + global.panelApi.apikey
                        }
                    })
                    let data = await f1.json();
                    let startup_cmd = (data?.attributes?.startup || data?.data[0]?.attributes?.startup);
                    if (!startup_cmd) return m.reply(JSON.stringify(data, null, 2));
                    let f = await fetch(global.panelApi.domain + "/api/application/servers", {
                        "method": "POST",
                        "headers": {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + global.panelApi.apikey,
                        },
                        "body": JSON.stringify({
                            "name": username + ` - ${ram.toUpperCase()}`,
                            "description": `${timezone.date} (${timezone.time})`,
                            "user": userId,
                            "egg": parseInt(global.panelApi.eggs),
                            "docker_image": "ghcr.io/parkervcp/yolks:nodejs_19",
                            "startup": startup_cmd,
                            "environment": {
                                "INST": "npm",
                                "USER_UPLOAD": "0",
                                "AUTO_UPDATE": "0",
                                "CMD_RUN": "npm start"
                            },
                            "limits": {
                                "memory": memory,
                                "swap": 0,
                                "disk": disk,
                                "io": 500,
                                "cpu": cpu
                            },
                            "feature_limits": {
                                "databases": 5,
                                "backups": 5,
                                "allocations": 5
                            },
                            deploy: {
                                locations: [parseInt(location)],
                                dedicated_ip: false,
                                port_range: [],
                            },
                        })
                    })
                    let res = await f.json()
                    if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
                    let server = res.attributes
                    m.reply(`*SUCCESSFULLY ADD SERVER*

TYPE: \`${res.object}\`

ID: \`${server.id}\`
UUID: ${server.uuid}\`
NAME: \`${server.name}\`
DESCRIPTION: \`${server.description}\`
MEMORY: \`${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB\`
DISK: \`${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB\`
CPU: \`${server.limits.cpu}%\`
CREATED AT: ${server.created_at}\``)
                }
                break
                case '1gb':
                case '2gb':
                case '3gb':
                case '4gb':
                case '5gb':
                case '6gb':
                case '7gb':
                case '8gb':
                case 'unli': {
                    if (!m.isDevs) return m.reply(global.mess.devs)
                    let jid;
                    let username;
                    let memo = listmemory[m.command];
                    let disk = memo;
                    let cpu = listcpu[m.command];
                    if (m.quoted && m.quoted.sender && m.text) {
                        jid = m.quoted.sender;
                        username = m.text;
                    } else if (m.text) {
                        let [name, number] = m.text.split(',');
                        if (!(name && number)) return m.reply(`*Format salah!*\nPenggunaan:\n${m.cmd} user,nomer`)
                        username = name;
                        jid = number.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
                    } else return m.reply('Invalid format!')
                    if (!(jid && username && memo && disk)) return anya.sendReact(m.chat, '❌', m.key)
                    let email = username.toLowerCase() + "@zidanstore.shop"
                    let password = username.toLowerCase() + Math.floor(Math.random() * 10000)
                    let d = (await anya.onWhatsApp(jid.split('@')[0]))[0] || {}
                    let f = await fetch(global.panelApi.domain + "/api/application/users", {
                        "method": "POST",
                        "headers": {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + global.panelApi.apikey
                        },
                        "body": JSON.stringify({
                            "email": email,
                            "username": username,
                            "first_name": username,
                            "last_name": username,
                            "language": "en",
                            "password": password
                        })
                    })
                    let data = await f.json();
                    if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
                    let user = data.attributes
                    let f2 = await fetch(global.panelApi.domain + "/api/application/nests/5/eggs" + (is_eggs ? '/' + global.panelApi.eggs : ''), {
                        "method": "GET",
                        "headers": {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + global.panelApi.apikey
                        }
                    })
                    let title = `Hai @${jid.split('@')[0]}, berikut data panel anda >
- Username: ${user.username}
- Password: ${password}
- Link: ${global.panelApi.domain}

Join Group Panel Buyer
https://chat.whatsapp.com/FyWdRpAoaUj0ywXJSkjKdo

_Harap simpan akun panel Anda dengan baik. Kami tidak bertanggung jawab jika Anda lupa password._`
                    await anya.reply(jid, title, func.fverified, {
                        expiration: 0
                    });
                    let data2 = await f2.json()
                    let startup_cmd = (data2?.attributes?.startup || data2?.data[0]?.attributes?.startup);
                    if (!startup_cmd) return m.reply(JSON.stringify(data2, null, 2));
                    let f3 = await fetch(global.panelApi.domain + "/api/application/servers", {
                        "method": "POST",
                        "headers": {
                            "Accept": "application/json",
                            "Content-Type": "application/json",
                            "Authorization": "Bearer " + global.panelApi.apikey,
                        },
                        "body": JSON.stringify({
                            "name": username + ` - ${m.command.toUpperCase()}`,
                            "description": `${timezone.date} (${timezone.time})`,
                            "user": user.id,
                            "egg": parseInt(global.panelApi.eggs),
                            "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                            "startup": startup_cmd,
                            "environment": {
                                "INST": "npm",
                                "USER_UPLOAD": "0",
                                "AUTO_UPDATE": "0",
                                "CMD_RUN": "npm start"
                            },
                            "limits": {
                                "memory": memo,
                                "swap": 0,
                                "disk": disk,
                                "io": 500,
                                "cpu": cpu
                            },
                            "feature_limits": {
                                "databases": 5,
                                "backups": 5,
                                "allocations": 5
                            },
                            deploy: {
                                locations: [parseInt(location)],
                                dedicated_ip: false,
                                port_range: [],
                            },
                        })
                    })
                    let res = await f3.json()
                    if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
                    let server = res.attributes
                    await m.reply(`Sukses menambahkan User dan Server

- UserId : ${user.id}
- ServerId : ${server.id}
- Username : ${user.username}
- Email : ${user.email}
- Name : ${user.first_name} ${user.last_name}
- Memory : ${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB
- Disk : ${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk + 'MB'}
- Cpu : ${server.limits.cpu === 0 ? 'Unlimited' : server.limits.cpu + '%'}`)
                    let servers = global.db.server[jid];
                    let serverId = server.id;
                    let expire = Date.now() + 2592000000
                    if (!servers) {
                        global.db.server[jid] = {
                            jid: jid,
                            data: [{
                                id: serverId,
                                ram: m.command,
                                username: username,
                                expired: expire,
                                date: timezone.date
                            }]
                        }
                    } else {
                        if (servers.data.find(item => item.username === username)) return
                        if (servers.data.find(item => item.id === serverId)) return
                        servers.data.push({
                            id: serverId,
                            ram: m.command,
                            username: username,
                            expired: expire,
                            date: timezone.date
                        })
                    }
                }
                break
                // ================================================================================
                case 'autocpanel': {
                    if (!m.isDevs) return m.reply(global.mess.devs)
                    await m.reply('Memulai auto create panel...')
                    async function createServer(jid, password, startup_cmd, user, serverdata) {
                        let currentServer = 1;
                        let totalServer = serverdata.length;
                        do {
                            for (let [index, servers] of serverdata.entries()) {
                                currentServer++;
                                let username = servers.username;
                                let ram = servers.ram;
                                let serverId = servers.id;
                                let memo_disk = listmemory[ram];
                                let cpu = listcpu[ram];
                                let f3 = await fetch(global.panelApi.domain + "/api/application/servers", {
                                    "method": "POST",
                                    "headers": {
                                        "Accept": "application/json",
                                        "Content-Type": "application/json",
                                        "Authorization": "Bearer " + global.panelApi.apikey,
                                    },
                                    "body": JSON.stringify({
                                        "name": username + ` - ${ram.toUpperCase()}`,
                                        "description": `${timezone.date} (${timezone.time})`,
                                        "user": user.id,
                                        "egg": parseInt(global.panelApi.eggs),
                                        "docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
                                        "startup": startup_cmd,
                                        "environment": {
                                            "INST": "npm",
                                            "USER_UPLOAD": "0",
                                            "AUTO_UPDATE": "0",
                                            "CMD_RUN": "npm start"
                                        },
                                        "limits": {
                                            "memory": memo_disk,
                                            "swap": 0,
                                            "disk": memo_disk,
                                            "io": 500,
                                            "cpu": cpu
                                        },
                                        "feature_limits": {
                                            "databases": 5,
                                            "backups": 5,
                                            "allocations": 5
                                        },
                                        deploy: {
                                            locations: [parseInt(location)],
                                            dedicated_ip: false,
                                            port_range: [],
                                        },
                                    })
                                })
                                let res = await f3.json()
                                if (res.errors) return anya.reply(global.owner, JSON.stringify(res.errors[0], null, 2), func.fverified);
                                let server = res.attributes;
                                if (serverId !== server.id) servers.id = server.id;
                                let caption = `*U S E R - I N F O*

- Jid : @${jid.split('@')[0]}
- ID : ${user.id}
- Username : ${user.username}
- Password : ${password}
- Email : ${user.email}
- First Name : ${user.first_name}
- Last Name : ${user.last_name}

*S E R V E R - I N F O*

- ID : \`${server.id}\`
- UUID : \`${server.uuid}\`
- Name : \`${server.name}\`
- Description : \`${server.description}\`
- Memory : \`${server.limits.memory === 0 ? 'Unlimited' : server.limits.memory} MB\`
- Disk : \`${server.limits.disk === 0 ? 'Unlimited' : server.limits.disk} MB\`
- CPU : \`${server.limits.cpu}%\`
- Created At : ${server.created_at}\``
                                await anya.reply(global.owner, caption, func.fverified, {
                                    expiration: m.expiration
                                });
                                await new Promise(resolve => setTimeout(resolve, 3000));
                            }
                        } while (currentServer <= totalServer);
                    }
                    async function createUser(jid, serverdata) {
                        let username = serverdata[0]?.username?.trim();
                        let ram = serverdata[0]?.ram;
                        let serverId = serverdata[0]?.id;
                        let memo_disk = listmemory[ram];
                        let cpu = listcpu[ram];
                        let email = username.toLowerCase() + "@zidanstore.shop"
                        let password = username.toLowerCase() + Math.floor(Math.random() * 10000)
                        let check = (await anya.onWhatsApp(jid.split('@')[0]))[0] || {}
                        if (check.hasOwnProperty('exists') && check.exists) {
                            let f = await fetch(global.panelApi.domain + "/api/application/users", {
                                "method": "POST",
                                "headers": {
                                    "Accept": "application/json",
                                    "Content-Type": "application/json",
                                    "Authorization": "Bearer " + global.panelApi.apikey
                                },
                                "body": JSON.stringify({
                                    "email": email,
                                    "username": username,
                                    "first_name": username,
                                    "last_name": username,
                                    "language": "en",
                                    "password": password
                                })
                            })
                            let data = await f.json();
                            if (data.errors) return anya.reply(global.owner, JSON.stringify(data.errors[0], null, 2), func.fverified);
                            let user = data.attributes
                            let f2 = await fetch(global.panelApi.domain + "/api/application/nests/5/eggs" + (is_eggs ? '/' + global.panelApi.eggs : ''), {
                                "method": "GET",
                                "headers": {
                                    "Accept": "application/json",
                                    "Content-Type": "application/json",
                                    "Authorization": "Bearer " + global.panelApi.apikey
                                }
                            })
                            let title = `Hai @${jid.split('@')[0]}, berikut data akun panel anda >
- Username: ${user.username}
- Password: ${password}
- Link: ${global.panelApi.domain}

_Harap simpan akun panel Anda dengan baik. Kami tidak bertanggung jawab jika Anda lupa password._`
                            await anya.reply(jid, title, func.fverified, {
                                expiration: 0
                            });
                            let data2 = await f2.json()
                            let startup_cmd = (data2?.attributes?.startup || data2?.data[0]?.attributes?.startup);
                            if (!startup_cmd) return anya.reply(global.owner, JSON.stringify(data2, null, 2), func.fverified);
                            await createServer(jid, password, startup_cmd, user, serverdata)
                        }
                    }
                    let now = Date.now();
                    for (let [jid, server] of Object.entries(global.db.server)) {
                        if (server.data && server.data.length > 0) {
                            server.data = server.data.filter(data => data.expired > now);
                            await createUser(jid, server.data)
                        }
                        await new Promise(resolve => setTimeout(resolve, 3000));
                    }
                    await anya.reply(m.chat, 'Successfully created an automatic panel.', m, {
                        expiration: m.expiration
                    })
                }
                break
            }
        } catch (error) {
            return anya.reply(m.chat, func.jsonFormat(error), m)
        }
    },
    location: 'plugins/developer/cpanel.js'
}