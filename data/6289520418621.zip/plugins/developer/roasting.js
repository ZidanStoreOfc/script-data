/**
* Created By Irull2nd
*/

const axios = require('axios');

async function roastGh(username, lang = "indonesian") {
return new Promise(async (resolve, reject) => {
const requestBody = {
username: username,
language: lang
};

await axios.post('https://github-roast.pages.dev/llama', requestBody).then(({ data }) => {
const lowUser = username.toLowerCase(); //Nambahin Klub Rusa 
const result = {
creator: "@Irull2nd",
roast: data.roast,
share: `https://github-roast.pages.dev/share/${lowUser}/?lang=${lang}`
}
resolve(result);
}).catch(reject);
});
}

exports.run = {
usage: ['roasting'],
hidden: ['roast'],
use: 'username github',
category: 'tools',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'adiwajshing'))
anya.sendReact(m.chat, '🕒', m.key)
await roastGh(m.text).then(result => {
anya.reply(m.chat, result.roast, m, {
expiration: m.expiration
})
}).catch(error => m.reply(String(error)));
},
devs: true
}