const fs = require('fs'),
fetch = require('node-fetch');

exports.run = {
usage: ['menfescs', 'stopmenfescs'],
category: 'developer',
async: async (m, { func, anya }) => {
const [nomor, pesan] = m.text.split(',');
switch (m.command) {
case 'menfescs':
if (!m.isPc) return m.reply(global.mess.private)
if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
if (Object.values(global.db.menfes).find(room => [room.a, room.b].includes(m.sender))) return m.reply(`Kamu masih berada dalam sesi customer service\nkirim ${m.prefix}stopmenfescs untuk stop customer service`)
if (!(nomor && pesan)) return m.reply(`Kirim Perintah ${m.cmd} nomor,pesan\n\nContoh :\n${m.prefix + m.command} +62xxx,Halo`)
let crush = nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
if (Object.values(global.db.menfes).find(room => [room.a, room.b].includes(crush))) return m.reply('Orang yang kamu customer service sedang customer service bersama orang lain :)')
if (crush.startsWith('0')) return m.reply(`Awali nomor dengan +62`)
let cekno = await anya.onWhatsApp(crush)
if (cekno.length == 0) return m.reply(`Masukkan nomor yang valid dan terdaftar di WhatsApp!`)
if (crush === m.sender) return m.reply(`Tidak bisa cs diri sendiri!`)
if (crush === m.bot) return m.reply(`Tidak bisa cs bot!`)
let txt = `Hi Customer Service Sedang Menghubungi Kamu

Pesan : ${pesan}

*Kirim (Y/N)* untuk menerima atau menolak Customer Service

_Pesan Ini Dari Customer Service Zidan Store_`
let id = anya.makeid(9).toUpperCase()
global.db.menfes[id] = {
id: id,
a: m.sender,
b: crush,
status: 'WAITING'
}
await anya.sendMessageModify(crush, txt, null, {
title: global.header,
body: global.footer,
thumbnail: await (await fetch('https://files.catbox.moe/0kz5dt.jpg')).buffer(),
largeThumb: true,
expiration: m.expiration
})
anya.reply(m.chat, `Pesan terkirim ke @${crush.split('@')[0]}\nSilahkan tunggu balasannya..`, m)
break
case 'stopmenfescs':
if (!m.isPc) return m.reply(global.mess.private)
let room = Object.values(global.db.menfes).find(room => [room.a, room.b].includes(m.sender))
if (!room) return m.reply('Belum ada sesi customer service!');
let tujuan = room.a == m.sender ? room.b : room.a;
await anya.reply(tujuan, `Customer Service chat kamu telah menghentikan chat ini.`, func.fstatus('System Notification'))
await anya.reply(m.chat, 'Customer Service berhasil di putuskan!', m)
delete global.db.menfes[room.id]
break
}
},
main: async (m, { func, anya }) => {
/* Function Menfes By SuryaDev */
if (m.isPc && !m.fromMe) {
let room = Object.values(global.db.menfes).find(room => room.status == 'WAITING' && [room.a, room.b].includes(m.sender))
let txt = `Chat Sudah Terhubung Dengan Customer Service ✓
Silahkan Kirim Pesan
Atau bisa kirim media seperti
Sticker/Audio/Video/Image/VN

Dilarang Spam Room Chat
Ketahuan : Banned

Jika pesan kamu direaction : 📬
Berarti pesan kamu diteruskan

_Ketik ${m.prefix}stopmenfescs untuk stop_`
if (room && m.sender == room.b && room.status == 'WAITING') {
if (func.somematch(['y', 'terima'], m.budy.toLowerCase())) {
room.status = 'CHATTING'
await anya.reply(room.a, txt, func.fstatus('System Notification'))
await anya.reply(room.b, txt, func.fstatus('System Notification'))
} else if (func.somematch(['n', 'tolak'], m.budy.toLowerCase())) {
await anya.reply(room.b, 'Customer Service berhasil di tolak.', m)
await anya.reply(room.a, `@${room.b.split('@')[0]} menolak customer service kamu :(`, func.fstatus('System Notification'))
delete global.db.menfes[room.id]
} else return m.reply(`Mohon masukkan keyword dengan benar!\n\n_kirim Y untuk menerima customer service dan kirim N untuk menolak customer service._`)
}
}

if (m.isPc && !m.isPrefix && !m.fromMe) {
let room = Object.values(global.db.menfes).find(room => room.status == 'CHATTING' && [room.a, room.b].includes(m.sender))
if (room) {
let other = room.a == m.sender ? room.b : room.a;
await anya.copyNForward(other, m, true, m.quoted && m.quoted.fromMe ? {contextInfo: {...m.msg.contextInfo, participant: other}} : {})
await anya.sendMessage(m.chat, {react: {text: '📬', key: m.key}})
}
}
},
private: true
}