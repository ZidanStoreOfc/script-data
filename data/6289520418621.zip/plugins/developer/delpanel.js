exports.run = {
    usage: ['delpanel'],
    use: 'mention or reply',
    category: 'developer',
    async: async (m, {
        func,
        anya
    }) => {
        if (m.quoted && m.text) {
            let username = m.text;
            let jid = m.quoted.sender;
            let server = global.db.server[jid];
            if (!server) return m.reply('User data not found.')
            let data = server.data.find(item => item.username === username)
            if (!data) return m.reply(`Username tersebut tidak ditemukan di server @${jid.replace(/@.+/, '')}`)
            // if (server.data.find(item => item.id === id)) return m.reply(`ID tersebut sudah ada pada server @${jid.replace(/@.+/, '')}`)
            let index = server.data.findIndex(x => x.username === username)
            if (index !== -1) {
                let caption = `Successfully removed username from server list.\n
- Jid : @${jid.replace(/@.+/, '')}
- ID : ${data.id}
- Username : ${data.username}`
                anya.reply(m.chat, caption, m, {
                    expiration: m.expiration
                })
                server.data.splice(index, 1)
            } else m.reply('Server tidak ditemukan.')
        } else if (m.text) {
            const [target, username] = m.text.split(',');
            if (!(target && username)) return m.reply(func.example(m.cmd, '62895354291993,Zidan'))
            let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : (target).split('@')[1]) : target;
            if (isNaN(number)) return m.reply('Invalid number.')
            if (number.length > 15) return m.reply('Invalid format.')
            let jid = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
            let server = global.db.server[jid];
            if (!server) return m.reply('User data not found.')
            let data = server.data.find(item => item.username === username)
            if (!data) return m.reply(`Username tersebut tidak ditemukan di server @${jid.replace(/@.+/, '')}`)
            // if (server.data.find(item => item.id === id)) return m.reply(`ID tersebut sudah ada pada server @${jid.replace(/@.+/, '')}`)
            let index = server.data.findIndex(x => x.username === username)
            if (index !== -1) {
                let caption = `Successfully removed username from server list.\n
- Jid : @${jid.replace(/@.+/, '')}
- ID : ${data.id}
- Username : ${data.username}`
                anya.reply(m.chat, caption, m, {
                    expiration: m.expiration
                })
                server.data.splice(index, 1)
            } else m.reply('Server tidak ditemukan.')
        } else m.reply('Mention or Reply chat target.')
    },
    devs: true
}