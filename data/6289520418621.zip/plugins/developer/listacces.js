const axios = require('axios');

function calculateExpireTime(expiredTimestamp) {
    const now = Date.now();
    const diff = expiredTimestamp - now;
    const seconds = Math.floor((diff / 1000) % 60);
    const minutes = Math.floor((diff / (1000 * 60)) % 60);
    const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    return { days, hours, minutes, seconds };
}

function parseDateString(dateString) {
    const [day, month, year] = dateString.split('-').map(Number);
    return new Date(year, month - 1, day).getTime(); // Bulan di JavaScript dimulai dari 0
}

exports.run = {
    usage: ['listacces'],
    category: 'developer',
    async: async (m, { func, anya, setting }) => {
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');

        const url = `https://api.github.com/repos/ZidanStoreOfc/ZIDANSTORE/contents/license`;
        const blacklistUrl = `https://raw.githubusercontent.com/ZidanStoreOfc/ZIDANSTORE/main/blacklist.json`;

        const config = {
            headers: {
                'Authorization': `token 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`,
                'Accept': 'application/vnd.github.v3+json'
            }
        };

        try {
            const response = await axios.get(url, config);
            const files = response.data;

            const blacklistResponse = await axios.get(blacklistUrl);
            const blacklist = blacklistResponse.data.blacklist;

            let accessDetails = '';
            let index = 1;

            for (const file of files) {
                if (file.name.endsWith('.json')) {
                    const fileResponse = await axios.get(file.download_url);
                    const fileData = fileResponse.data;

                    const userId = file.name.replace('.json', '');
                    const status = blacklist.includes(userId) ? '❌' : '✅';

                    const expiredTimestamp = parseDateString(fileData.expiry_date);
                    const { days, hours, minutes, seconds } = calculateExpireTime(expiredTimestamp);

                    // Cek apakah akses sudah kedaluwarsa
                    if (days < 0 || (days === 0 && (hours < 0 || (hours === 0 && (minutes < 0 || (minutes === 0 && seconds < 0)))))) {
                        // Jika sudah kedaluwarsa, tampilkan 0D 0H 0M 0S
                        accessDetails += `${index}. ${userId}\n- Nama: ${fileData.name}\n- Role: ${fileData.role}\n- Expire: 0D 0H 0M 0S\n- Acces: ❌\n\n`;
                    } else {
                        // Jika belum kedaluwarsa, tampilkan waktu kedaluwarsa
                        const expireTime = `${days}D ${hours}H ${minutes}M ${seconds}S`;
                        accessDetails += `${index}. ${userId}\n- Nama: ${fileData.name}\n- Role: ${fileData.role}\n- Expire: ${expireTime}\n- Acces: ${status}\n\n`;
                    }
                    index++;
                }
            }

            if (accessDetails) {
                accessDetails = accessDetails.trim();
                const responseMessage = `乂  *L I S T - A C C E S*\n\n${accessDetails}`;
                anya.reply(m.chat, responseMessage, m, {
                    expiration: m.expiration
                });
            } else {
                anya.reply(m.chat, 'Tidak ada file akses yang ditemukan di folder license.', m, {
                    expiration: m.expiration
                });
            }
        } catch (error) {
            console.error(error);
            anya.reply(m.chat, 'Terjadi kesalahan saat mengambil daftar akses. Pastikan folder license ada dan dapat diakses.', m, {
                expiration: m.expiration
            });
        }
    }
};