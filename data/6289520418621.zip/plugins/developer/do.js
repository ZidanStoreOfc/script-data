exports.run = {
    usage: ['r1c1', 'r2c1', 'r4c2', 'r8c4', 'r16c4'],
    use: 'hostname',
    category: 'digital ocean',
    async: async (m, { func, anya }) => {
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');
        switch (m.command) {
            case "r1c1":
            case "r2c1":
            case "r4c2":
            case "r8c4":
            case "r16c4": {
                if (!m.text) return m.reply(func.example(m.cmd, 'hostname'));
                const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
                let images;
                let region = "sgp1";
                if (m.command == "r1c1") {
                    images = "s-1vcpu-1gb";
                } else if (m.command == "r2c1") {
                    images = "s-1vcpu-2gb";
                } else if (m.command == "r4c2") {
                    images = "s-2vcpu-4gb";
                } else if (m.command == "r8c4") {
                    images = 's-4vcpu-8gb';
                } else {
                    images = "s-4vcpu-16gb-amd";
                    region = "syd1";
                }
                let hostname = m.text.toLowerCase();
                if (!hostname) return m.reply(func.example(m.cmd, 'hostname'));

                function generateRandomPassword() {
                    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
                    const length = 10;
                    let password = '';
                    for (let i = 0; i < length; i++) {
                        const randomIndex = Math.floor(Math.random() * characters.length);
                        password += characters[randomIndex];
                    }
                    return password;
                }

                try {
                    let dropletData = {
                        name: hostname,
                        region: region,
                        size: images,
                        image: 'ubuntu-20-04-x64',
                        ssh_keys: null,
                        backups: false,
                        ipv6: true,
                        user_data: null,
                        private_networking: null,
                        volumes: null,
                        tags: ['T']
                    };

                    const password = generateRandomPassword();
                    dropletData.user_data = `#cloud-config
password: ${password}
chpasswd: { expire: False }`;

                    let response = await fetch('https://api.digitalocean.com/v2/droplets', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Authorization': "Bearer " + global.token_do
                        },
                        body: JSON.stringify(dropletData)
                    });

                    let responseData = await response.json();

                    if (response.ok) {
                        let dropletConfig = responseData.droplet;
                        let dropletId = dropletConfig.id;

                        await m.reply(`Memproses pembuatan vps...\nSilahkan Tunggu 2-5 Menit !`);
                        await new Promise(resolve => setTimeout(resolve, 60000));

                        let dropletResponse = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                            method: 'GET',
                            headers: {
                                'Content-Type': 'application/json',
                                'Authorization': "Bearer " + global.token_do
                            }
                        });

                        let dropletDataInfo = await dropletResponse.json();
                        let ipVPS = dropletDataInfo.droplet.networks.v4 && dropletDataInfo.droplet.networks.v4.length > 0 
                            ? dropletDataInfo.droplet.networks.v4[0].ip_address 
                            : "Tidak ada alamat IP yang tersedia";

                        let messageText = `Sukses Membuat VPS!\n\n`;
                        messageText += `ID: ${dropletId}\n`;
                        messageText += `IP VPS: ${ipVPS}\n`;
                        messageText += `Password: ${password}`;

                        await anya.sendMessage(m.chat, { text: messageText });
                    } else {
                        throw new Error(`Gagal membuat VPS: ${responseData.message}`);
                    }
                } catch (err) {
                    console.error(err);
                    m.reply(`Terjadi kesalahan saat membuat VPS: ${err}`);
                }
            }
        }
    }
};