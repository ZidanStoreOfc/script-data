const { proto } = require('@whiskeysockets/baileys');

exports.run = {
usage: ['sendch2'],
hidden: ['sendchannel2'],
use: 'text',
category: 'developer',
async: async (m, { func, anya, users, setting }) => {
if (!users.hasOwnProperty('lastsendch')) {
users.lastsendch = 0;
}
if (!m.text) return m.reply(func.example(m.cmd, 'halo'))
async function sendMessageToChannel (text) {
let messages = {
extendedTextMessage: {
text: text,
mentions: anya.ments(text),
contextInfo: {
mentionedJid: anya.ments(text),
externalAdReply: {
title: 'Powered By Zidan Store',
body: global.header,
thumbnailUrl: setting.cover,
sourceUrl: setting.link,
mediaType: 1,
renderLargerThumbnail: false
}
}
}
};
let messageToChannel = proto.Message.encode(messages).finish();
let result = {
tag: 'message',
attrs: {
to: global.newsletter2,
type: 'text'
},
content: [
{
tag: 'plaintext',
attrs: {},
content: messageToChannel
}
]
};
return anya.query(result);
}
await sendMessageToChannel(m.text)
.then(() => anya.sendReact(m.chat, '✅', m.key))
.catch(() => anya.sendReact(m.chat, '❌', m.key))
},
devs: true
}