const axios = require('axios');

exports.run = {
usage: ['blacksc', 'whitesc', 'checksc', 'blacklistsc'],
use: 'parameter',
category: 'owner',
async: async (m, { func, anya }) => {
const username = 'ZidanStoreOfc';
const token = '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';
const branch = 'main';
const repo = 'Database';
const pathName = 'gamesanya/blacklist.json';

async function getFileContent() {
const { data: fileData } = await axios.get(`https://api.github.com/repos/${username}/${repo}/contents/${pathName}`, {
headers: {
Authorization: `Bearer ${token}`,
},
});
const fileContent = Buffer.from(fileData.content, 'base64').toString('utf8');
return { fileData, jsonArray: JSON.parse(fileContent) };
}

async function updateFileContent(jsonArray, sha) {
const newFileContent = JSON.stringify(jsonArray, null, 2);
const base64Content = Buffer.from(newFileContent).toString('base64');
await axios.put(`https://api.github.com/repos/${username}/${repo}/contents/${pathName}`, {
message: `Update ${pathName}`,
content: base64Content,
sha: sha,
branch: branch
}, {
headers: {
Authorization: `Bearer ${token}`,
},
});
}

switch (m.command) {
case 'blacksc':{
if (!m.text) return m.reply('input number target.')
let user = m.text.replace(/[^0-9]/gi, '') + '@s.whatsapp.net'
const { fileData, jsonArray } = await getFileContent();
if (jsonArray.includes(user)) return m.reply('target already in database.')
jsonArray.push(user);
await updateFileContent(jsonArray, fileData.sha);
let caption = `success blocked access on @${user.replace(/@.+/, '')} to use anya-bot script`;
anya.reply(m.chat, caption, m, {
expiration: m.expiration
})
}
break
case 'whitesc':{
if (!m.text) return m.reply('input number target.')
let user = m.text.replace(/[^0-9]/gi, '') + '@s.whatsapp.net'
const { fileData, jsonArray } = await getFileContent();
if (!jsonArray.includes(user)) return m.reply('target not in database.')
const indexToRemove = jsonArray.indexOf(user);
if (indexToRemove !== -1) {
jsonArray.splice(indexToRemove, 1);
await updateFileContent(jsonArray, fileData.sha);
let caption = `successfully removed blocked on @${user.replace(/@.+/, '')} to use anya-bot script`;
anya.reply(m.chat, caption, m, {
expiration: m.expiration
})
} else anya.reply(m.chat, 'target not in database.', m, {
expiration: m.expiration
})
}
break
case 'checksc':{
if (!m.text) return m.reply('input number target.')
let user = m.text.replace(/[^0-9]/gi, '') + '@s.whatsapp.net'
const { fileData, jsonArray } = await getFileContent();
const isAllowed = jsonArray.includes(user);
let caption = isAllowed ? `@${user.replace(/@.+/, '')} is already listed in the black list.` : `@${user.replace(/@.+/, '')} is not listed in the black list.`;
anya.reply(m.chat, caption, m, {
expiration: m.expiration
})
}
break
case 'blacklistsc':{
const { fileData, jsonArray } = await getFileContent();
if (jsonArray.length === 0) {
anya.reply(m.chat, 'Data empty.', m, {
expiration: m.expiration
})
} else {
let caption = '*ANYA SCRIPT USER BLACK LIST*\n\n'
caption += jsonArray.map((user, index) => `${index + 1}. @${user.replace(/@.+/, '')}`).join('\n')
anya.reply(m.chat, caption, m, {
expiration: m.expiration
})
}
}
break
}
},
devs: true
}