const { Client } = require('ssh2'); // Mengimpor Client dari ssh2
const axios = require('axios'); // Pastikan axios diimpor

exports.run = {
    usage: ['domain'],
    use: 'host,ipvps',
    category: 'cpanel',
    async: async (m, { func, anya, args }) => {
        // Cek apakah user adalah developer
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');
        if (!m.text) return m.reply(func.example(m.cmd, '2 host|ipvps'));

        // Cek argumen domain
        if (!m.args[0]) return m.reply("Domain tidak ditemukan!\nContoh Penggunaan Yang Benar: .domain 3 hostname|ipVps");
        if (isNaN(m.args[0])) return m.reply("Domain tidak ditemukan!\nContoh Penggunaan Yang Benar: .domain 3 hostname|ipVps");

        const dom = Object.keys(global.subdomain);
        if (Number(m.args[0]) > dom.length) return m.reply("Domain tidak ditemukan!\nContoh Penggunaan Yang Benar: .domain 3 hostname|ipVps");

        // Cek argumen hostname/IP
        if (!m.args[1] || !m.args[1].includes("|")) return m.reply("Hostname/IP tidak ditemukan!");

        let tldnya = dom[m.args[0] - 1];
        const [host, ip] = m.args[1].split("|");

        // Fungsi untuk membuat subdomain
        async function subDomain1(host, ip) {
            return new Promise((resolve) => {
                axios.post(
                    `https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
                    {
                        type: "A",
                        name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya,
                        content: ip.replace(/[^0-9.]/gi, ""),
                        ttl: 3600,
                        priority: 10,
                        proxied: false
                    },
                    {
                        headers: {
                            Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
                            "Content-Type": "application/json",
                        },
                    }
                ).then((response) => {
                    let res = response.data;
                    if (res.success) {
                        resolve({
                            success: true,
                            zone: res.result?.zone_name,
                            name: res.result?.name,
                            ip: res.result?.content
                        });
                    }
                }).catch((error) => {
                    let errMsg = error.response?.data?.errors?.[0]?.message || error.response?.data?.errors || error.response?.data || error;
                    resolve({ success: false, error: String(errMsg) });
                });
            });
        }

        // Panggil fungsi subDomain1 dan tangani hasilnya
        await subDomain1(host.toLowerCase(), ip).then(async (result) => {
            if (result.success) {
                let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${result.ip}\n*Subdomain :* ${result.name}
`;
                await m.reply(teks);
            } else {
                return m.reply(`${result.error}`);
            }
        });
    },
    devs: true
};