let {
    generateWAMessage,
    STORIES_JID,
    generateWAMessageFromContent
} = require("@whiskeysockets/baileys");

function itemStages(t) {
    var a = [];
    for (let e = 0; e < t.length; e += 5) {
        var i = t.slice(e, e + 5);
        a.push(i)
    }
    return a
}
exports.run = {
    usage: ["upswnotag"],
    hidden: ["upswnomentiongc"],
    use: "reply media",
    category: "developer",
    async: async (t, {
        anya: p,
        quoted: a
    }) => {
        try {
            if (a && /audio|video|image|conversation|extendedTextMessage/.test(a.mtype)) {
                var i = Object.values(await p.groupFetchAllParticipating()).filter(e => e.participants.find(e => e.id == p.user.jid) && !e.announce),
                    s = i.map(e => e.id),
                    n = i.flatMap(e => e.participants.map(e => e.id));
                if (0 === s.length || 0 === n.length) return t.reply("Tidak ada grup atau pengguna yang ditemukan untuk mengirim cerita.");
                var o = t.text || "#UP STATUS DARI BOT";
                p.sendReact(t.chat, "🕒", t.key);
                let e;
                a.download && (e = await a.download());
                var r = {
                        caption: o
                    },
                    {
                        success: d,
                        failed: g
                    } = (/image\/(jpe?g|png)/.test(a.mime) ? r.image = e : /video\/mp4/.test(a.mime) ? r.video = e : /audio/.test(a.mime) ? (r.audio = e, r.ptt = !0, r.mimetype = a.mime || "audio/mpeg") : /conversation|extendedTextMessage/.test(a.mtype) && (r.text = o), await (async (e, t, a) => {
                        let i = 0,
                            s = 0,
                            n = 0;
                        var o, r = await generateWAMessage(STORIES_JID, e, {
                            upload: p.waUploadToServer
                        });
                        for (o of itemStages(t)) {
                            var d, g = [{
                                tag: "meta",
                                attrs: {},
                                content: [{
                                    tag: "mentioned_users",
                                    attrs: {},
                                    content: o.map(e => ({
                                        tag: "to",
                                        attrs: {
                                            jid: e
                                        },
                                        content: void 0
                                    }))
                                }]
                            }];
                            await p.relayMessage(STORIES_JID, r.message, {
                                messageId: r.key.id,
                                statusJidList: a,
                                additionalNodes: g
                            });
                            for (d of o) {
                                try {
                                    var m = await generateWAMessageFromContent(d, {
                                        statusMentionMessage: {
                                            message: {
                                                protocolMessage: {
                                                    key: r.key,
                                                    type: 25
                                                }
                                            }
                                        }
                                    }, {});
                                    await p.relayMessage(d, m.message, {
                                        additionalNodes: [{
                                            tag: "meta",
                                            attrs: {
                                                is_status_mention: "true"
                                            },
                                            content: void 0
                                        }]
                                    }), i++
                                } catch (e) {
                                    console.log("Error pada: " + d, e), s++
                                }
                                let t = ++n % 10 == 0 ? 3e4 : 3e3;
                                await new Promise(e => setTimeout(e, t))
                            }
                            await new Promise(e => setTimeout(e, 5e3))
                        }
                        return {
                            success: i,
                            failed: s
                        }
                    })(r, s, n));
                p.reply(t.chat, `Berhasil mengirim cerita ke ${n.length} user di ${s.length} group.
Success: ` + d + (0 < g ? "\nFailed: " + g : ""), t, {
                    expiration: t.expiration
                })
            } else t.reply("Input media yang ingin dijadikan story.")
        } catch (e) {
            console.log(e), p.reply(t.chat, "Nice Try Dev:\n" + e.message, t, {
                expiration: t.expiration
            })
        }
    },
    devs: !0,
    location: "plugins/developer/upswnotag.js"
};