exports.run = {
    usage: ['blackgc', 'whitegc', 'blacklistgc'],
    use: 'id grup',
    category: 'developer',
    async: async (m, {
        func,
        anya
    }) => {
        if (/blacklistgc/.test(m.command)) {
            let groupData = Object.values(global.db.groups).filter(x => x.banned)
            if (groupData.length == 0) return m.reply('Empty data.');
            let caption = '*BLACK LIST GROUP*'
            groupData.forEach((item, index) => {
                caption += `\n\n${index + 1}. ${item.jid}\n- Name: ${item.name}`
            })
            return await m.reply(caption)
        }
        if (!m.text) return m.reply(func.example(m.cmd, '120xxx@g.us'));
        const [groupId] = m.args;
        if (!/^\d.*(@g\.us)$/.test(groupId)) return m.reply('id grup tidak valid.');
        let groups = global.db.groups[groupId];
        if (typeof groups == 'undefined') return m.reply('Data grup tersebut tidak ditemukan.');
        switch (m.command) {
            case 'blackgc':
                if (groups.banned) return m.reply('grub tersebut sudah di banned.');
                groups.banned = true;
                m.reply(`Successfully blacklisted group “${groups.name}“.`);
                break
            case 'whitegc':
                if (!groups.banned) return m.reply('grub tersebut tidak di banned.');
                groups.banned = false;
                m.reply(`Successfully removed group “${groups.name}“ from blacklist.`);
                break
        }
    },
    devs: true,
    location: 'plugins/developer/banned-group.js'
}