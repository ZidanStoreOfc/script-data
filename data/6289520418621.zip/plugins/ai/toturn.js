const axios = require('axios');
exports.run = {
usage: ['toturn'],
use: 'reply photo',
category: 'ai',
async: async (m, { func, anya, quoted }) => {
if (!quoted || !/image/.test(quoted.mime)) return anya.sendReact(m.chat, '❌', m.key) && m.reply('Input media dengan benar! Hanya gambar yang diizinkan.');
anya.sendReact(m.chat, '🕒', m.key);
try {
const media = await anya.downloadAndSaveMediaMessage(quoted);
const uploadedUrl = (await func.UploadFileUgu(media)).url;
const resultUrl = await processImage(uploadedUrl, 'turn');
await anya.sendMessage(m.chat, { image: { url: resultUrl }, caption: 'Turn effect applied.' }, { quoted: m });
anya.sendReact(m.chat, '✅', m.key);
} catch (error) {
console.error(error);
anya.sendReact(m.chat, '❌', m.key);
m.reply('Maaf, terjadi kesalahan saat memproses gambar.');
}
},
limit: true
};
async function processImage(imageUrl, mode) {
const { data } = await axios.get(`https://api.alyachan.dev/api/expression`, {
params: {
image: imageUrl,
mode: mode,
apikey: global.alya
}
});
if (data?.status === true) return data.data.url;
throw new Error('Pemrosesan gagal.');
}