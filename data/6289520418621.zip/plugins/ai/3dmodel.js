const axios = require('axios');
async function generate3DModel(prompt, apiKey) {
const response = await axios.get(`https://itzpire.com/ai/3dmodel?prompt=${encodeURIComponent(prompt)}`, {
headers: {
'accept': 'application/json'
}
});
return response.data.result;
}
exports.run = {
usage: ['3dmodel'],
hidden: [],
use: 'text',
category: 'ai',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'neko girl, soft anime'));
anya.sendReact(m.chat, '🕐', m.key);
try {
const modelUrl = await generate3DModel(m.text, global.itzpire);
await anya.sendMessage(m.chat, { image: { url: modelUrl }, caption: global.mess.ok }, { quoted: m });
anya.sendReact(m.chat, '✅', m.key);
} catch (error) {
anya.sendReact(m.chat, '❌', m.key);
}
},
premium: false,
limit: 1
};