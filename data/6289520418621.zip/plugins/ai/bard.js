const fetch = require('node-fetch');

exports.run = {
usage: ['bard'],
hidden: ['b'],
use: 'query',
category: 'ai',
async: async (m, { func, anya, quoted }) => {
let text;
if (m.args.length >= 1) {
text = m.args.slice(0).join(" ");
} else if (m.quoted && m.quoted.text) {
text = m.quoted.text;
} else return m.reply(func.example(m.cmd, 'halo'));
let { key } = await anya.sendMessage(m.chat, { text: global.mess.wait }, { quoted: m, ephemeralExpiration: m.expiration });
try {
let res = await GoogleBard(text);
await anya.sendMessage(m.chat, {
text: `${res.data}`,
edit: key
}, { quoted: m, ephemeralExpiration: m.expiration });
} catch (error) {
return m.reply(String(error));
}
},
premium: true
};

async function GoogleBard(query) {
const response = await fetch("https://apisku.biz.id/api/gpt/bard", {
method: 'POST',
headers: {
'accept': '*/*',
'api_key': 'free',
'Content-Type': 'application/json',
'Accept-Language': 'id-ID'
},
body: JSON.stringify({ text: query })
});
return response.json();
}