const axios = require('axios');
const fs = require('fs');
const path = require('path');

exports.run = {
    usage: ['jadianime'],
    hidden: ['toanime'],
    use: 'reply photo',
    category: 'ai',
    async: async (m, {
        func,
        anya,
        quoted
    }) => {
        const styles = ["anime", "manga", "3d", "comic", "realistic"];
        const qualitys = ["low", "medium"];

        const drawever = {
            queue: async (imageBuffer, mimeType, style, quality) => {
                try {
                    // Mengubah buffer menjadi base64
                    const base64Image = Buffer.from(imageBuffer).toString('base64');
                    const base64ImageUrl = `data:${mimeType};base64,${base64Image}`;
                    const data = JSON.stringify({
                        "image": base64ImageUrl,
                        "style": style,
                        "quality": quality,
                        "strength": 0.4
                    });

                    const api = await axios.request({
                        method: 'POST',
                        url: 'https://www.drawever.com/api/tools/queue',
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0 Firefox/131.0',
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'accept-language': 'id-ID',
                            'referer': 'https://www.drawever.com/ai/photo-to-anime?start=1736212737985',
                            'path': '/ai/photo-to-anime',
                            'origin': 'https://www.drawever.com',
                            'alt-used': 'www.drawever.com',
                            'sec-fetch-dest': 'empty',
                            'sec-fetch-mode': 'cors',
                            'sec-fetch-site': 'same-origin',
                            'priority': 'u=0',
                            'te': 'trailers',
                            'Cookie': '_ga_H15YQYJC6R=GS1.1.1736212732.1.0.1736212732.0.0.0; _ga=GA1.1.1471909988.1736212732'
                        },
                        data: data
                    });
                    return {
                        status: true,
                        ...api.data
                    }
                } catch (error) {
                    return {
                        status: false,
                        message: error.message
                    }
                }
            },
            create: async (imageUrl, mimeType, style, quality) => {
                return new Promise(async (resolve) => {
                    const {
                        status,
                        queueId,
                        message
                    } = await drawever.queue(imageUrl, mimeType, style, quality);
                    if (!status) return resolve({
                        status,
                        message
                    })
                    try {
                        const checkStatus = async () => {
                            const config = {
                                method: 'GET',
                                url: `https://www.drawever.com/api/tools/queue?queueId=${queueId}`,
                                headers: {
                                    'User-Agent': 'Mozilla/5.0 (Android 10; Mobile; rv:131.0) Gecko/131.0 Firefox/131.0',
                                    'accept-language': 'id-ID',
                                    'referer': 'https://www.drawever.com/ai/photo-to-anime?start=1736212737985',
                                    'content-type': 'application/json',
                                    'alt-used': 'www.drawever.com',
                                    'sec-fetch-dest': 'empty',
                                    'sec-fetch-mode': 'cors',
                                    'sec-fetch-site': 'same-origin',
                                    'priority': 'u=4',
                                    'te': 'trailers',
                                    'Cookie': '_ga_H15YQYJC6R=GS1.1.1736226490.2.1.1736226501.0.0.0; _ga=GA1.1.1471909988.1736212732; _ym_uid=1736782704433305783; _ym_d=1736782704; _ym_isad=2; _ym_visorc=w'
                                }
                            };

                            const api = await axios.request(config);
                            const output = api.data.output;
                            const images = api.data;
                            console.log('images:', images);
                            const savedPaths = [];
                            console.log('output:', output)
                            if (output) {
                                /*            output.forEach((base64Image, index) => {
                const matches = base64Image.match(/^data:([A-Za-z-+/]+);base64,(.+)$/);
                if (matches && matches.length === 3) {
                    const fileType = matches[1];
                    const base64Data = matches[2];
                    const fileExtension = fileType.split('/')[1];
                    const fileName = func.filename(fileExtension);
                    const filePath = path.join(process.cwd(), 'media', fileName);
                    fs.writeFileSync(filePath, base64Data, 'base64');
                    savedPaths.push(filePath);
                }
            });
                    console.log(savedPaths);
            resolve(savedPaths);*/
                                const base64Image = output.split(';base64,').pop();
                                const imageBuffer = Buffer.from(base64Image, 'base64');
                                const fileName = func.filename('png');
                                const filePath = path.join(process.cwd(), 'media', fileName);
                                fs.writeFileSync(filePath, imageBuffer);
                                console.log('Image saved at:', filePath);
                                resolve({
                                    status,
                                    filePath,
                                    id: images.id,
                                    startTime: images.startTime,
                                    credits: images.credits,
                                    prompt: images.prompt
                                });
                            } else {
                                setTimeout(checkStatus, 1000);
                            }
                        };
                        checkStatus();
                    } catch (error) {
                        console.log(error);
                        resolve({
                            status: false,
                            message: error.message
                        })
                    }
                })
            }
        };

        if (/image\/(jpe?g|png)/.test(quoted.mime)) {
            anya.sendReact(m.chat, '🕒', m.key)
            let imageBuffer = await quoted.download();
            let mimeType = quoted?.mime || 'image/jpeg';
            try {
                const result = await drawever.create(imageBuffer, mimeType, 'anime', 'medium')
                if (!result.status) return m.reply(result.message);
                /*if (openAIResponse) {
                    for (let [index, imagePath] of openAIResponse.entries()) {
                        await anya.sendMessage(m.chat, {
                            image: fs.readFileSync(imagePath),
                            caption: `Image (${index + 1}/${openAIResponse.length})`
                        }, {
                            quoted: index == 0 ? m : null,
                            ephemeralExpiration: m.expiration
                        }).then(_ => fs.unlinkSync(imagePath))
                        await new Promise(resolve => setTimeout(resolve, 1000))
                    }
                } else {
                    return m.reply("Tidak ada respons dari OpenAI atau terjadi kesalahan.");
                }*/
                const imagePath = result.filePath;
                await anya.sendMessage(m.chat, {
                    image: fs.readFileSync(imagePath),
                    caption: `- ID: ${result.id}
- startTime: ${result.startTime}
- credits: ${result.credits}
- prompt: ${result.prompt}`
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                }).then(_ => fs.unlinkSync(imagePath))
            } catch (error) {
                console.log(error);
                anya.reply(m.chat, error.message, m, {
                    expiration: m.expiration
                })
            }
        } else m.reply(`Kirim/Reply foto dengan caption ${m.cmd}`)
    },
    premium: true,
    location: 'plugins/ai/jadianime.js'
}