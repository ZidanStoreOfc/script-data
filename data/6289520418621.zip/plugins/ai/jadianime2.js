const WebSocket = require('ws');
const axios = require('axios');
const fs = require('fs');
const fetch = require('node-fetch');
const FormData = require('form-data');
const {
    fromBuffer
} = require('file-type');

async function tmpfiles(buffer) {
    const {
        ext,
        mime
    } = (await fromBuffer(buffer)) || {};
    const form = new FormData();
    form.append("file", buffer, {
        filename: `tmp.${ext}`,
        contentType: mime
    });
    try {
        const {
            data
        } = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
            headers: form.getHeaders()
        });
        const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(data.data.url);
        return `https://tmpfiles.org/dl/${match[1]}`;
    } catch (error) {
        return false;
    }
}

exports.run = {
    usage: ['jadianime2'],
    hidden: ['toanime2'],
    use: 'reply photo',
    category: 'ai',
    async: async (m, {
        func,
        anya,
        quoted
    }) => {
        if (/image\/(jpe?g|png)/.test(quoted.mime)) {
            async function download(url, ws) {
                try {
                    const res = await axios.get(url, {
                        responseType: "stream"
                    });
                    const fileName = `natsumi_img2anime_${Date.now()}.jpg`;
                    const writer = fs.createWriteStream(fileName);
                    res.data.pipe(writer);

                    writer.on("finish", () => {
                        console.log(`Image saved as ${fileName}`);
                        ws.close();
                        anya.sendMessage(m.chat, {
                            image: fs.readFileSync(fileName),
                        }, {
                            quoted: m,
                            ephemeralExpiration: m.expiration
                        })
                    });
                    writer.on("error", (err) => {
                        console.error("Write error:", err);
                        ws.close();
                    });
                } catch (err) {
                    console.error("Download failed:", err);
                    ws.close();
                }
            }

            async function img2anime(imgUrl, {
                prompt = "(masterpiece), best quality, anime artwork",
                negative_prompt = "(low quality, worst quality:1.4), text, watermark",
                strength = 0.6,
            } = {}) {
                try {
                    strength = Math.min(Math.max(strength, 0.1), 1.0);
                    const res = await axios.get(imgUrl, {
                        responseType: "arraybuffer"
                    });
                    const imgBuffer = Buffer.from(res.data, "binary");
                    const b64Img = imgBuffer.toString("base64");
                    const sessHash = Math.random().toString(36).slice(2);

                    const ws = new WebSocket("wss://pixnova.ai/demo-photo2anime/queue/join", {
                        headers: {
                            Origin: "https://pixnova.ai",
                            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36 Edg/133.0.0.0",
                            Connection: "Upgrade",
                            Upgrade: "websocket",
                            "Sec-WebSocket-Version": "13",
                        },
                    });

                    ws.on("open", () => console.log("WS connected"));
                    ws.on("close", () => console.log("WS closed"));
                    ws.on("error", (err) => console.error("WS error:", err));

                    ws.on("message", (data) => {
                        const msg = JSON.parse(data.toString());
                        console.log("Received:", msg.msg);

                        switch (msg.msg) {
                            case "send_hash":
                                ws.send(JSON.stringify({
                                    session_hash: sessHash
                                }));
                                break;

                            case "send_data":
                                ws.send(
                                    JSON.stringify({
                                        data: {
                                            negative_prompt,
                                            prompt,
                                            source_image: `data:image/jpeg;base64,${b64Img}`,
                                            strength,
                                        },
                                    }),
                                );
                                break;

                            case "process_completed":
                                if (msg.success) {
                                    const resultUrl = `https://oss-global.pixnova.ai/${msg.output.result[0]}`;
                                    console.log("Result URL:", resultUrl);
                                    download(resultUrl, ws);
                                } else {
                                    console.error("Processing failed:", msg);
                                }
                                break;

                            default:
                                console.log("Unknown message type:", msg);
                                break;
                        }
                    });
                } catch (err) {
                    console.error("Error:", err);
                }
            }

            anya.sendReact(m.chat, '🕒', m.key)
            let media = await quoted.download();
            if (!media) return false
            let url = await tmpfiles(media)
            await img2anime(url) /*{
                prompt: "studio ghibli style, vibrant colors, detailed eyes",
                negative_prompt: "blurry, deformed hands, 3d render, text",
                strength: 0.8,
            });*/
        } else m.reply(`Kirim/Reply foto dengan caption ${m.cmd}`)
    },
    premium: true,
    location: 'plugins/ai/jadianime2.js'
}