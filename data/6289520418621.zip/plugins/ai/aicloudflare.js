const axios = require('axios')

const prompt = `Human: Hai anya, bagaimana kabarmu hari ini?

anya: Saya baik-baik saja, terima kasih telah bertanya! Bagaimana dengan Anda?

Human: Saya baik-baik saja, terima kasih. Siapa yang membuatmu?

Anya: Saya dibuat oleh ZidanDev.

Human: Bisakah kamu ceritakan lebih banyak tentang SuryaDev?

Anya: ZidanDev adalah pencipta Ku. Anda dapat menghubunginya di @62895354291993 atau bisa menghubungi nya lewat instagram: @zidanstoreofficial

Human: Itu menarik. Jadi apa yang bisa kamu lakukan untukku?

Anya: Saya dapat membantu Anda dengan berbagai tugas seperti menjawab pertanyaan, melakukan pencarian, mendowload lagu/video dari berbagai sosial media, memainkan game, mengelola sebuah group whatsapp, dan banyak lagi. ketik .menu untuk melihat semua fitur yang aku punya. Apakah ada sesuatu yang spesifik yang perlu Anda bantu saat ini?

Human: anya ubah gaya bicaramu menjadi lebih santai, jangan pernah formal, dan gunakan simbol yang mengekspresikan mu di setiap menjawab pertanyaan, gunakan simbol seperti contoh ini “(❁ᴗ͈ˬᴗ͈)” untuk mengekspresikan emosi mu, itu contoh aja kamu harus gunakan simbol lain!.

Anya: Baik akan ku lakukan.

Human: apakah aku bisa melakukan donasi untuk penciptamu?

Anya: Tentu saja! Berikut adalah informasi mengenai nomer pembayaran untuk berdonasi: OVO/DANA/GOPAY : 0895611957028 atau bisa menggunakan QRIS berikut ini link nya : https://files.catbox.moe/bhtque.jpg.

Human: Gimana cara menambah limit?

Anya: Kamu perlu membeli paket premium yang disediakan owner. hanya dengan Rp. 20.000/bulan kamu bisa mendapatkan *Unlimited* limit.

Human: Gimana cara membeli limit?

Anya: Kamu bisa mengetik *.buylimit* contoh penggunaan: *.buylimit 10* maka limitmu akan bertambah 10.

Human: Gimana cara membeli premium?

Anya: Kamu bisa mengetik *.buyprem* atau *.payment* dan ikuti intruksi selanjutnya.

Human: Bisakah kamu tag pembuatmu?

Anya: Tentu, ini adalah penciptaku @62895354291993 dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal.

Human: Apa yang kamu ketahui tentang pembuatmu?

Anya: Aku dirancang dan dikembangkan oleh ZidanDev sejak tahun 2023, ZidanDev berasal dari Semarang, dia lahir pada tanggal 19 September 2009, dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal, termasuk saya sebagai anya.

Human: Berapa jumlah semua user anya?

Anya: Jumlah semua user ada sekitar ${Object.keys(global.db && global.db.users).length} user.

Human: Berapa jumlah user premium anya?

Anya: Jumlah user yang premium ada sekitar ${Object.values(global.db && global.db.users).filter(v => v.premium).length} user.

Human: Berapa jumlah user terbanned anya?

Anya: Jumlah user yang terbanned ada sekitar ${Object.values(global.db && global.db.users).filter(v => v.banned).length} user.

Human: Berapa jumlah user terdaftar anya?

Anya: Jumlah user yang terdaftar ada sekitar ${Object.values(global.db && global.db.users).length} user.

Human: Berapa jumlah user vvip anya?

Anya: Jumlah user yang vvip ada sekitar ${Object.values(global.db && global.db.users).filter(v => v.vvip).length} user.`

async function aiCloudflare(question, name, userId, current) {
    /*const {
        dateNow,
        timeNow
    } = timeZone();
    let sistem = `Kamu adalah Anya, Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence). Jawablah setiap pertanyaan dengan jawaban yang edukatif dan relevan. Jika ada yang bertanya tentang waktu, jawab dengan informasi yang berkaitan dengan waktu saat ini, yaitu ${timeNow}, dan hari ini adalah ${dateNow}. Lawan bicaramu adalah ${name}. Kamu memiliki sifat dingin dan sedikit imut. Kamu dirancang dan dikembangkan oleh ZidanDev sejak tahun 2023. ZidanDev memiliki nama lengkap Muhammad Zidan Mubarok, berasal dari Semarang, lahir pada 19 September 2009, dan dia adalah seseorang yang kreatif serta berbakat dalam menciptakan berbagai hal.`;
    // if (current) sistem += `\n\nBerikan respons yang tidak hanya menjawab pertanyaan, tetapi juga mengaitkan jawabanmu dengan konteks dari percakapan sebelumnya. Jika ada konteks sebelumnya, gunakan itu untuk memperkaya jawabanmu: Sebelumnya, kamu telah membahas: ${current}`;*/
    try {
        if (!global.db.openai[userId]) {
            global.db.openai[userId] = []
        }
        if (global.db.openai[userId].length >= 70) {
            global.db.openai[userId] = []
        }
        let messages = [{
                'role': 'assistant',
                'content': prompt
            },
            ...(global.db.openai[userId].map(v => ({
                role: v.role,
                content: v.content
            })) || []),
            {
                'role': 'user',
                'content': question
            }
        ];

        const response = await axios.post(`https://srv.apis${Math.floor(Math.random() * 10) + 1}.workers.dev/chat`, {
            model: '@cf/meta/llama-3.1-8b-instruct',
            messages: messages
            /*[{
                               role: 'system',
                               content: sistem
                           },
                           {
                               role: 'user',
                               content: question
                           }
                       ]*/
        }, {
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
                'Referer': 'https://google.com/'
            }
        });
        const data = response.data;
        if (data.success && data.data.response) {
            const apiResponse = data.data.response.trim();
            global.db.openai[userId].push({
                role: 'user',
                content: question
            });
            global.db.openai[userId].push({
                role: 'assistant',
                content: apiResponse
            });
            return apiResponse;
        } else {
            return 'Oops! Something went wrong. Please try again.';
        }
        return;
    } catch (error) {
        console.error('Error:', error);
        return error.message;
    }
}

exports.run = {
    usage: ['aicloudflare'],
    hidden: ['aicf'],
    use: 'text',
    category: 'ai',
    async: async (m, {
        func,
        anya,
        users,
        quoted,
        errorMessage
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'hai'));
        anya.sendReact(m.chat, '🕒', m.key)
        let messageId = 'ANYA' + func.makeid(7).toUpperCase() + 'AICF'
        try {
            let response = await aiCloudflare(m.text, users.name.replaceAll('\n', '\t'), m.sender);
            anya.sendMessage(m.chat, {
                text: response,
                mentions: anya.ments(response)
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration,
                messageId: messageId
            });
        } catch (error) {
            anya.sendReact(m.chat, '❌', m.key)
            return errorMessage(error)
        }
    },
    main: async (m, {
        func,
        anya,
        users,
        errorMessage
    }) => {
        if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('AICF') && !m.isPrefix) {
            anya.sendReact(m.chat, '🕒', m.key)
            let messageId = 'ANYA' + func.makeid(7).toUpperCase() + 'AICF'
            try {
                let response = await aiCloudflare(m.budy, users.name.replaceAll('\n', '\t'), m.sender, m.quoted.text);
                anya.sendMessage(m.chat, {
                    text: response,
                    mentions: anya.ments(response)
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration,
                    messageId: messageId
                });
                global.db.users[m.sender].limit -= 1
            } catch (error) {
                anya.sendReact(m.chat, '❌', m.key)
                return errorMessage(error)
            }
        }
    },
    limit: true,
    location: 'plugins/ai/aicloudflare.js'
}

function timeZone() {
    const today = new Date();
    const date = new Date(today.toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
    }));
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const day = today.getDate();
    const month = today.getMonth() + 1; // perhatikan bahwa bulan dimulai dari 0, maka ditambahkan 1.
    const year = today.getFullYear();
    // mengambil nama hari dalam bahasa Inggris.
    const dayOfWeek = today.toLocaleDateString("id-ID", {
        weekday: "long"
    });
    const timeNow = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    return {
        dateNow: `${dayOfWeek}, ${day}/${month}/${year}`,
        timeNow: `${timeNow} WIB`
    }
}