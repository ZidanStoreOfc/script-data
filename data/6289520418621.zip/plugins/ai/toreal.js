const axios = require('axios');
exports.run = {
usage: ['toreal'],
use: 'reply photo',
category: 'ai',
async: async (m, { func, anya, quoted }) => {
if (!quoted || !/image/.test(quoted.mime)) return m.reply('Input media dengan benar! Hanya gambar yang diizinkan.');
anya.sendReact(m.chat, '🕒', m.key);
try {
const media = await anya.downloadAndSaveMediaMessage(quoted);
const anu = await func.UploadFileUgu(media);
const result = await processToReal(anu.url);
if (result.status) {
await anya.sendMessage(m.chat, { image: { url: result.data.url }, caption: global.mess.ok }, { quoted: m });
anya.sendReact(m.chat, '✅', m.key);
} else {
throw new Error(JSON.stringify(result, null, 2));
}
} catch (error) {
let errorMessage = 'Terjadi kesalahan saat memproses gambar.\n\n';
errorMessage += '```json\n' + JSON.stringify(JSON.parse(error.message), null, 2) + '\n```';
m.reply(errorMessage);
anya.sendReact(m.chat, '❌', m.key);
}
},
limit: true
};
async function processToReal(imageUrl) {
const apiUrl = `https://api.alyachan.dev/api/ai-anime-toreal?image=${encodeURIComponent(imageUrl)}&apikey=${global.alya}`;
const { data } = await axios.get(apiUrl);
return data;
}