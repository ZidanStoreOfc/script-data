const axios = require('axios');
const FormData = require('form-data');

async function uploadImage(imageBuffer) {
    try {
        const form = new FormData();
        form.append('file', imageBuffer, {
            filename: 'image.jpg',
            contentType: 'image/jpeg'
        });

        const headers = {
            ...form.getHeaders(),
            'Content-Length': form.getLengthSync()
        };

        const response = await axios.post('https://www.pic.surf/upload.php', form, {
            headers
        });
        const identifier = response.data.identifier;

        return `https://www.pic.surf/${identifier}`;
    } catch (error) {
        throw new Error(`Upload gagal: ${error.response ? error.response.data : error.message}`);
    }
}

async function upscale(img, options = {}) {
    const validation = await getImageInfo(img);
    if (!validation.valid) {
        return {
            success: false,
            code: 400,
            result: {
                error: validation.error
            }
        };
    }

    const inputx = isValid(options.style, options.noise);
    if (!inputx.valid) {
        return {
            success: false,
            code: 400,
            result: {
                error: inputx.error
            }
        };
    }

    const config = {
        x2: '2',
        style: inputx.style,
        noise: inputx.noise,
        file_name: validation.info.fileName,
        files_size: validation.info.fileSize,
        file_height: validation.info.height,
        file_width: validation.info.width,
        input: img
    };

    try {
        const params = new URLSearchParams();
        params.append('conf', JSON.stringify(config));

        const taskx = await axios.post(
            `https://bigjpg.com/task`,
            params, {
                headers: getHeaders()
            }
        );

        if (taskx.data.status !== 'ok') {
            return {
                success: false,
                code: 400,
                result: {
                    error: "Error"
                }
            };
        }

        const taskId = taskx.data.info;
        let attempts = 0;
        const maxAttempts = 20;

        while (attempts < maxAttempts) {
            const res = await axios.get(
                `https://bigjpg.com/free?fids=${JSON.stringify([taskId])}`, {
                    headers: getHeaders()
                }
            );

            const result = res.data[taskId];

            if (result[0] === 'success') {
                return {
                    success: true,
                    code: 200,
                    result: {
                        info: validation.info,
                        url: result[1],
                        size: result[2],
                        config: {
                            style: config.style,
                            styleName: getAvailableStyles()[config.style],
                            noise: config.noise,
                            noiseName: getAvailableNoise()[config.noise]
                        }
                    }
                };
            } else if (result[0] === 'error') {
                return {
                    success: false,
                    code: 400,
                    result: {
                        error: "Upscalenya gagal bree.. Coba lagi nanti yak"
                    }
                };
            }

            await new Promise(resolve => setTimeout(resolve, 15000));
            attempts++;
        }

        return {
            success: false,
            code: 400,
            result: {
                error: "Timeout"
            }
        };

    } catch (err) {
        return {
            success: false,
            code: 400,
            result: {
                error: err.message || "Error"
            }
        };
    }
}

function getAvailableStyles() {
    return {
        'art': 'Artwork',
        'photo': 'Foto'
    };
}

function getAvailableNoise() {
    return {
        '-1': 'Ninguno',
        '0': 'Bajo',
        '1': 'Medio',
        '2': 'Alto',
        '3': 'El más alto'
    };
}

function getHeaders() {
    return {
        'origin': 'https://bigjpg.com',
        'referer': 'https://bigjpg.com/',
        'user-agent': 'Postify/1.0.0',
        'x-requested-with': 'XMLHttpRequest'
    };
}

function isValid(style, noise) {
    if (!style && !noise) {
        return {
            valid: true,
            style: 'art',
            noise: '-1'
        };
    }

    if (style && !getAvailableStyles()[style]) {
        return {
            valid: false,
            error: `Stylenya kagak valid bree.. Pilih salah satunya yak: ${Object.keys(getAvailableStyles()).join(', ')}`
        };
    }

    if (noise && !getAvailableNoise()[noise]) {
        return {
            valid: false,
            error: `Noise levelnya kagak valid bree.. Pilih salah satunya yak: ${Object.keys(getAvailableNoise()).join(', ')}`
        };
    }

    return {
        valid: true,
        style: style || 'art',
        noise: noise || '-1'
    };
}

async function getImageInfo(img) {
    if (!img) {
        return {
            valid: false,
            error: 'input image url'
        };
    }

    try {
        const response = await axios.get(img, {
            responseType: 'arraybuffer'
        });

        const fileSize = parseInt(response.headers['content-length'] || response.data.length);
        const width = Math.floor(Math.random() * (2000 - 800 + 1)) + 800;
        const height = Math.floor(Math.random() * (2000 - 800 + 1)) + 800;

        let fileName = img.split('/').pop().split('#')[0].split('?')[0] || 'image.jpg';
        if (fileName.endsWith('.webp')) {
            fileName = fileName.replace('.webp', '.jpg');
        }

        if (fileSize > 5 * 1024 * 1024) {
            return {
                valid: false,
                error: "Maximum image size 5MB"
            };
        }

        return {
            valid: true,
            info: {
                fileName,
                fileSize,
                width,
                height
            }
        };

    } catch (err) {
        return {
            valid: false,
            error: err.message
        };
    }
}

exports.run = {
    usage: ['bigjpg'],
    use: 'reply image',
    category: 'ai',
    async: async (m, {
        func,
        anya,
        quoted
    }) => {
        if (/image\/(jpe?g|png)/.test(quoted.mime)) {
            try {
                anya.sendReact(m.chat, '🕒', m.key);
                let media = await quoted.download();
                let imageUrl = await uploadImage(media);
                const [style, noise] = m.args;

                const result = await upscale(imageUrl, {
                    style,
                    noise
                });

                if (!result.success) {
                    return m.reply(result.result.error);
                }

                const {
                    info,
                    url: resultUrl,
                    size,
                    config
                } = result.result;

                const caption = `*Hasil Upscale*\n\n*Nama File*: ${info.fileName}\n*Ukuran Asli*: ${(info.fileSize / 1024 / 1024).toFixed(2)} MB\n*Ukuran Hasil*: ${func.formatSize(size)}\n*Style*: ${config.styleName}\n*Noise Level*: ${config.noiseName}`;

                anya.sendMessage(m.chat, {
                    image: {
                        url: resultUrl
                    },
                    caption
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                });

            } catch (error) {
                m.reply(`${error.message}`);
            }
        } else {
            const [url, style, noise] = m.args;

            if (!url) {
                return m.reply(`Contoh penggunaan :\n1. *URL*: ${m.cmd} <url_image> <style> <noise_level>\n2. *Gambar*: Reply gambar atau kirim gambar dengan caption .bigjpg <style> <noise_level>\n\n*Available Styles*: art, photo\n*Available Noise Levels*: -1, 0, 1, 2, 3`);
            }
            anya.sendReact(m.chat, '🕒', m.key);
            const result = await upscale(url, {
                style,
                noise
            });

            if (!result.success) {
                return m.reply(result.result.error);
            }

            const {
                info,
                url: resultUrl,
                size,
                config
            } = result.result;

            const caption = `*Hasil Upscale*\n\n*Nama File*: ${info.fileName}\n*Ukuran Asli*: ${(info.fileSize / 1024 / 1024).toFixed(2)} MB\n*Ukuran Hasil*: ${func.formatSize(size)}\n*Style*: ${config.styleName}\n*Noise Level*: ${config.noiseName}`;

            anya.sendMessage(m.chat, {
                image: {
                    url: resultUrl
                },
                caption
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        }
    },
    premium: true,
    location: 'plugins/ai/bigjpg.js'
}