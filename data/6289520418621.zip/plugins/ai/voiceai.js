const axios = require('axios');
exports.run = {
usage: ['voiceai'],
use: 'prompt',
category: 'ai',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'halo sayangkuh, kasih kata kata penyemangat dong'));
try {
await anya.sendReact(m.chat, '🕒', m.key);
const prompt = m.text.trim();
const defaultStyle = 'Kamu adalah asisten AI yang pintar dan informatif. Jawablah setiap pertanyaan dengan penjelasan yang lengkap namun mudah dimengerti, seolah-olah kamu sedang berdialog dengan manusia. Berikan informasi yang relevan dan akurat, dan jika ada pertanyaan yang ambigu, klarifikasi sebelum memberikan jawaban. Pastikan jawabanmu tetap sopan dan profesional.';
const response = await axios.get(`https://api.nyxs.pw/ai/ai-voice2`, {
params: {
prompt,
gaya: defaultStyle
}
});
if (response.data.status) {
await anya.sendReact(m.chat, '✅', m.key);
anya.sendMedia(m.chat, await func.fetchBuffer(response.data.result), m, { expiration: m.expiration });
} else {
throw new Error('Failed to generate AI voice');
}
} catch (error) {
console.error(error);
await anya.sendReact(m.chat, '❌', m.key);
return m.reply('Failed to generate AI voice.');
}
},
limit: 3,
restrict: true
}