const axios = require('axios');

const textToImage = async (prompt = "a cat", weight = 1024, height = 1024, guiscale = 5, paguiscale = 2, nis = 18, step = 20, sid = -1) => {
    const url = 'https://api.freesana.ai/v1/images/generate';
    const headers = {
        'authority': 'api.freesana.ai',
        'origin': 'https://freesana.ai',
        'referer': 'https://freesana.ai/',
        'user-agent': 'Postify/1.0.0',
    };

    const data = {
        prompt: prompt,
        model: "sana_1_6b",
        width: weight,
        height: height,
        guidance_scale: guiscale,
        pag_guidance_scale: paguiscale,
        num_inference_steps: nis,
        steps: step,
        seed: sid
    };

    try {
        const response = await axios.post(url, data, {
            headers
        });
        const {
            id,
            status,
            result,
            processingTime,
            width,
            height,
            nsfw,
            seed
        } = response.data;

        return {
            id,
            status,
            result,
            processingTime,
            width,
            height,
            nsfw,
            seed
        };
    } catch (error) {
        console.error(error);
        throw error;
    }
}

exports.run = {
    usage: ['text2img'],
    hidden: ['txt2img', 'buatkan'],
    use: 'prompt',
    category: 'ai',
    async: async (m, {
        func,
        anya
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'a girls'))
        anya.sendReact(m.chat, '🕒', m.key)
        try {
            let data = await textToImage(m.text)
            let caption = `Processing Time: ${data.processingTime}
- Width: ${data.width}
- Height: ${data.height}
- NSFW: ${data.nsfw ? 'Yes' : 'No'}
- Seed: ${data.seed}`
            anya.sendMedia(m.chat, data.result, m, {
                caption: caption,
                expiration: m.expiration
            })
        } catch (error) {
            anya.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    premium: true
}