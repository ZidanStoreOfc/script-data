exports.run = {
  usage: ['remini2'],
  hidden: ['hd2'],
  use: 'reply photo',
  category: 'ai',
  async: async (m, { func, anya, quoted }) => {
    const sharp = require('sharp');
    const fs = require('fs');
    const path = require('path');
    
    m.reply('segera di proses');

    async function upscaleImage(inputPath, resolutionOption) {
      const outputPath = './sampah/';
      
      try {
        if (!fs.existsSync(inputPath)) {
          throw new Error(`File tidak ditemukan: ${inputPath}`);
        }

        const outputDir = path.dirname(outputPath);
        if (!fs.existsSync(outputDir)) {
          fs.mkdirSync(outputDir, { recursive: true });
        }

        const resolutions = {
          1: { label: '1080p', width: 1920, height: 1080 },
          2: { label: '2k', width: 2560, height: 1440 },
          3: { label: '4k', width: 3840, height: 2160 },
          4: { label: '8k', width: 7680, height: 4320 },
          5: { label: '16k', width: 15360, height: 8640 },
        };

        if (!resolutions[resolutionOption]) {
          return m.reply('Pilihan resolusi tidak valid. Pilih antara 1 - 5.');
        }

        const selectedResolution = resolutions[resolutionOption];
        const outputPathResolution = `./sampah/${selectedResolution.label}.jpg`;

        await sharp(inputPath)
          .resize({
            width: selectedResolution.width,
            height: selectedResolution.height,
            fit: sharp.fit.inside,
            kernel: sharp.kernel.lanczos3,
          })
          .sharpen({ sigma: 2, m1: 3, m2: 1 })
          .normalize()
          .modulate({ saturation: 1.3, brightness: 0.85 })
          .toFormat('jpeg', { quality: 100, progressive: true })
          .toFile(outputPathResolution);

        await anya.sendMessage(m.chat, { image: fs.readFileSync(outputPathResolution), caption: "Done Cik" }, { quoted: m });
      } catch (e) {
        return anya.reply(m.chat, String(e), m);
      }
    }

    if (!m.quoted) return m.reply("Reply foto nya");
    
    const resolutionOption = m.args[0];
    if (!resolutionOption) {
      return m.reply(`pakai opsi hd yang memiliki 5 type yaitu

1 = 1080p
2 = 2k
3 = 4k
4 = 8k
5 = 16k`);
    }

    const bufferImage = await m.quoted.download();
    const tempFilePath = path.join(__dirname, `temp_image_${Date.now()}.jpg`);
    fs.writeFileSync(tempFilePath, bufferImage);
    
    await upscaleImage(tempFilePath, resolutionOption);
    fs.unlinkSync(tempFilePath);
  }
};