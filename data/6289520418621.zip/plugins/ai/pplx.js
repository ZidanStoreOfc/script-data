const axios = require('axios');

const pplx = (query) => {
return new Promise(async (resolve, reject) => {
try {
const response = await axios.post('https://api.yanzbotz.my.id/api/ai/perplexity', {
query: query
}, {
headers: {
'Content-Type': 'application/json'
}
});
const regex = /"answer":"([^"]*)"/g;
let match;
let result = '';
while ((match = regex.exec(response.data)) !== null) {
result += match[1];
}
resolve(result.replace(/\\n/g, '\n').replace(/\\/g, ''));
} catch (error) {
reject(error);
}
});
}

exports.run = {
usage: ['perplexity'],
hidden: ['pplx'],
use: 'question',
category: 'ai',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'Kamu di ciptakan oleh siapa'))
anya.sendReact(m.chat, '🕒', m.key)
let result = await pplx(m.text)
anya.reply(m.chat, result, m, {
expiration: m.expiration
})
},
limit: true
}