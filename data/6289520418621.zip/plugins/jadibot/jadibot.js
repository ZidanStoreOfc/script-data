const { jidNormalizedUser } = require('@whiskeysockets/baileys');

exports.run = {
usage: ['jadibot', 'stopbot'],
category: 'jadibot',
async: async (m, { func, anya, plugins, users }) => {
switch (m.command) {
case 'jadibot':
let [value, params] = m.args;
let settings = global.db.jadibot.find(v => v.number === m.sender)
if (!settings) global.db.jadibot.push({
number: m.sender,
session: '',
notify: true,
status: true
})
if (value && func.somematch(['on', 'off'], value.toLowerCase()) && settings) {
let option = value.toLowerCase();
let statuses = option === 'on' ? true : false;
if (settings.status == statuses) return m.reply(`Jadibot has been ${option == 'on' ? 'activated' : 'inactivated'} previously.`)
settings.status = statuses;
return m.reply(`Jadibot has been ${option == 'on' ? 'activated' : 'inactivated'} successfully.`)
} else if (value && params && /^notify$/i.test(value) && func.somematch(['on', 'off'], params.toLowerCase()) && settings) {
let option = params.toLowerCase();
let statuses = option === 'on' ? true : false;
if (settings.notify == statuses) return m.reply(`Jadibot notify has been ${option == 'on' ? 'activated' : 'inactivated'} previously.`)
settings.notify = statuses;
return m.reply(`Jadibot notify has been ${option == 'on' ? 'activated' : 'inactivated'} successfully.`)
} else {
if (!users.jadibot) return m.reply(global.mess.jadibot)
const bot = (global.pairing.number || '').replace(/[^0-9]/g, '') + '@s.whatsapp.net'
if (m.user.jadibot) return m.reply(`Tidak dapat menggunakan jadibot disini!\n\nklik wa.me/${bot.split('@')[0]}?text=` + global.db.setting[bot].prefix + 'jadibot')
if (typeof global.jadibot[m.sender] != 'undefined') return m.reply(`Kamu sudah menjadi bot sebelumnya!\nIngin menghapus sesi? ketik *${m.prefix}delsesibot*`)
if (Object.keys(global.jadibot).length !== 0){
const array = Object.values(global.jadibot).filter(x => x.user)
if (array.length != 0){
const userbot = array.map(client => jidNormalizedUser(client.user.id))
const find = userbot.find(item => item.includes(m.sender))
if (find) return anya.reply(m.chat, `Kamu sudah menjadi bot sebelumnya!\nIngin menghapus sesi? ketik *${m.prefix}delsesibot*`, m)
}
}
if (Object.keys(global.jadibot).length >= 5) return m.reply('User jadibot sudah mencapai maksimal 2')
anya.sendReact(m.chat, '🕒', m.key)
await require('../../system/jadibot.js').Jadibot(anya, m.sender);
}
break
case 'stopbot':
if (!users.jadibot) return m.reply(global.mess.jadibot)
if (Object.keys(global.jadibot).length == 0) return m.reply('Tidak ada bot sementara yang aktif saat ini')
require('../../system/jadibot.js').StopJadibot(m.sender);
break
}
},
private: true
}