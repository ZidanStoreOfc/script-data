const fetch = require('node-fetch')

exports.run = {
usage: ['listbot'],
hidden: ['listjadibot'],
category: 'jadibot',
async: async (m, { func, anya, setting }) => {
const data = Object.values(global.db.users).filter(item => item.jadibot)
if (data.length == 0) return m.reply('*Empty data.*')
let txt = '乂  *L I S T  J A D I  B O T*\n'
data.forEach((item, index) => {
let bot = Object.values(global.jadibot).filter(x => x.user && x.user.jadibot).find(v => v.user.jid === item.jid)
txt += `\n${index + 1}. @${item.jid.split('@')[0]}`
txt += `\n◦  Expire: ${item.expired.jadibot === 'PERMANENT' ? 'PERMANENT' : func.expireTime(item.expired.jadibot)}`
txt += `\n◦  Status: ${bot ? '✅Active' : '❌Non-active'}`
txt += `\n◦  Maintenance: ${setting.maintenance ? 'Yes' : 'No'}\n`
if (bot) txt += `◦  Uptime : ${func.clockString(new Date - bot.user.uptime)}\n`
})
m.reply(txt)
},
premium: false
}