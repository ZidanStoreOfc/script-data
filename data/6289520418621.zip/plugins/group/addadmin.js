const toMs = require('ms')

exports.run = {
usage: ['addadmin'],
hidden: ['+admin'],
use: 'mention or reply',
category: 'group',
async: async (m, { func, anya }) => {
const [target, time] = m.text && m.text.split('|');

if (m.quoted) {
if (!m.text) return m.reply(`Input waktunya\nContoh: ${m.cmd} 1d`)
let user = global.db.groups[m.chat].member[m.quoted.sender]
if (typeof user == 'undefined') return m.reply(func.texted('bold', 'User data not found.'))
if (typeof user.admin == 'undefined') user.admin = false;
if (typeof user.expired == 'undefined') user.expired = 0;
let expire = Date.now() + toMs(m.text);
if (user.admin) return m.reply(`@${m.quoted.sender.replace(/@.+/, '')} already admin.`)
anya.groupParticipantsUpdate(m.chat, [m.quoted.sender], 'promote').then(res => {
user.admin = true
user.expired = expire
m.reply(`Successfully added @${m.quoted.sender.replace(/@.+/, '')} to admin for ${m.text}`)
})
} else if (m.text) {
if (!target) return m.reply(`Contoh : ${comand} @0|1d`)
if (!time) return m.reply(`Input waktunya\nContoh: ${m.prefix + m.command} @0|1d`)
let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : (target).split('@')[1]) : target
if (isNaN(number)) return m.reply(func.texted('bold', 'Invalid number.'))
if (number.length > 15) return m.reply(func.texted('bold', 'Invalid format.'))
let admin = number.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
let user = global.db.groups[m.chat].member[admin]
if (typeof user == 'undefined') return m.reply(func.texted('bold', 'User data not found.'))
if (typeof user.admin == 'undefined') user.admin = false;
if (typeof user.expired == 'undefined') user.expired = 0;
let expire = Date.now() + toMs(time);
if (user.admin) return m.reply(`@${admin.replace(/@.+/, '')} already admin.`)
anya.groupParticipantsUpdate(m.chat, [admin], 'promote').then(res => {
user.admin = true
user.expired = expire
m.reply(`Successfully added @${admin.replace(/@.+/, '')} to admin for ${time}`)
})
} else m.reply('Mention or Reply chat target.')
},
group: true,
admin: true,
botAdmin: true
}