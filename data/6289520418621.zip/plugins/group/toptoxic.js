const {
    areJidsSameUser
} = require('@whiskeysockets/baileys');

exports.run = {
    usage: ['toptoxic'],
    category: 'group',
    async: async (m, {
        anya,
        setting,
        groups
    }) => {
        const membersData = groups.member;
        if (membersData.length === 0) return m.reply('Empty data.');

        const topToxicUsers = membersData.sort((a, b) => b.toxic - a.toxic);
        const toxicUsers = topToxicUsers.map(user => user.jid);
        const userRank = toxicUsers.indexOf(m.sender) + 1;

        const caption = createCaption(userRank, membersData.length, topToxicUsers, setting.max_toxic, m.members);
        m.reply(caption);
    },
    group: true,
    admin: true,
    location: 'plugins/group/toptoxic.js'
}

function createCaption(userRank, totalUsers, topToxicUsers, maxToxic, members) {
    let caption = `You are Top *${userRank}* Toxic out of *${totalUsers}* Users\n\n`;
    caption += topToxicUsers.slice(0, 30).map((user, index) => {
        const name = members.some(member => areJidsSameUser(user.jid, member.id)) ?
            (global.db.users[user.jid]?.name || 'No name').replaceAll('\n', '\t') :
            '@' + (user.jid || user.id).split('@')[0];
        return `${index + 1}. ${name} => (${user.toxic}/${maxToxic})`;
    }).join('\n');
    return caption;
}