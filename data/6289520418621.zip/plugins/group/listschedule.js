exports.run = {
    usage: ['listschedule'],
    use: 'parameter',
    category: 'admin tools',
    async: async (m, { func, anya }) => {
        if (!global.schedules || !global.schedules[m.chat]) {
            return m.reply("Tak ada schedule yang aktif di grup ini!");
        }

        const schedules = global.schedules[m.chat].times;
        if (schedules.length === 0) {
            return m.reply("Tak ada schedule yang tersisa di grup ini.");
        }

        let scheduleList = "Daftar Schedule:\n";
        schedules.forEach((entry, index) => {
            scheduleList += `${index + 1}. Waktu: ${entry.time}\n`;
        });

        return m.reply(scheduleList);
    },
    group: true,
    admin: true,
    botAdmin: true
};