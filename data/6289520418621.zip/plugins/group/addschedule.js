exports.run = {
    usage: ['addschedule'],
    use: 'parameter',
    category: 'admin tools',
    async: async (m, { func, anya }) => {
        if (!global.schedules) global.schedules = {};

        const actions = {
            'open': 'not_announcement',
            'close': 'announcement'
        };

        let [action, time, timezone, say] = m.text.split("|");

        if (!action || !time || !timezone || !say) {
            return m.reply("Example: .addschedule *close|22:00:00|Asia/Jakarta|Grupnya ditutup, udah malem bobok aja kalian*");
        }
        
        if (!(action in actions)) {
            return m.reply(`Action tidak tersedia, silahkan lihat list nya: \n- ${Object.keys(actions).join("\n- ")}`);
        }

        const validTimezones = ['Asia/Jakarta', 'Asia/Makassar', 'Asia/Jayapura'];
        action = actions[action];

        if (!validTimezones.includes(timezone)) {
            return m.reply('Timezone tidak valid. Pilihan yang tersedia: Asia/Jakarta, Asia/Makassar, Asia/Jayapura.');
        }

        const timeRegex = /^([01]\d|2[0-3]):([0-5]\d):([0-5]\d)$/;
        if (!timeRegex.test(time)) {
            return m.reply('Format waktu tidak valid. Harus dalam format HH:MM:SS\nContoh: .addschedule *close|22:00:00|Asia/Jakarta|Grupnya ditutup, udah malem bobok aja kalian*');
        }

        if (!global.schedules[m.chat]) {
            global.schedules[m.chat] = { timezone: timezone, times: [] };
        }

        let times = global.schedules[m.chat].times.map(a => a.time);
        if (times.includes(time)) {
            return m.reply("Format waktu telah ditambahkan sebelumnya!");
        }

        global.schedules[m.chat].times.push({ time, action, say, last: null });
        m.reply(`Berhasil menambahkan schedule di group ini!\nTime ${time}\nAction: ${action} group`);

        if (!global.scheduler) {
            console.log('Setting up interval for schedule function');
            setInterval(schedule.bind(null, anya), 1000);
            global.scheduler = true;
        }
    },
    group: true,
    admin: true,
    botAdmin: true
};

function schedule(anya) {
    const now = new Date();
    const today = now.toISOString().split('T')[0];

    Object.keys(global.schedules).forEach(id => {
        const logData = global.schedules[id];
        if (logData) {
            const formatter = new Intl.DateTimeFormat('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false,
                timeZone: logData.timezone
            });

            const formattedTime = formatter.format(now);

            logData.times.forEach(async entry => {
                if (formattedTime === entry.time && entry.last !== today) {
                    let act = entry.action == "announcement" ? "tutup" : "buka";
                    await anya.groupSettingUpdate(id, entry.action);
                    await anya.sendMessage(id, { text: `[ *${entry.time} ${logData.timezone}* ]\n${entry.say}` });
                    entry.last = today;
                }
            });
        } else {
            console.log(`No logData found for ID: ${id}`);
        }
    });
}