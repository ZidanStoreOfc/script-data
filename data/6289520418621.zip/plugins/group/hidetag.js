exports.run = {
    usage: ["hidetag"],
    hidden: ["h"],
    use: "text",
    category: "group",
    async: async (e, {
        func: t,
        anya: a
    }) => {
        a.sendMessage(e.chat, {
            text: e.text || (e.quoted ? e.quoted.text : ""),
            mentions: e.members.map(e => e.id)
        }, {
            quoted: t.fverified,
            ephemeralExpiration: e.expiration
        })
    },
    group: !0,
    admin: !0
};