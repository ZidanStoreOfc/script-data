const util = require('util');
const {
    getAggregateVotesInPollMessage,
    normalizeMessageContent,
    getKeyAuthor,
    decryptPollVote,
    jidNormalizedUser
} = require('@whiskeysockets/baileys');

exports.run = {
    usage: ['vote'],
    hidden: ['pol'],
    category: 'group',
    async: async (m, {
        func,
        anya
    }) => {
        anya.voting = anya.voting || {};
        if (!anya.voting[m.chat]) {
            let args = m.text.split('\n').map(a => a.trim())
            let name = args[0]
            let values = args.slice(1)
            if (!name) return m.reply(`Contoh: ${m.cmd} nama\nvalue\n\nContoh: ${m.cmd} *JUDUL*\nText1\nText2`)
            if (values.length < 2) return m.reply('Harap berikan setidaknya dua nilai untuk jejak pendapat')
            let poll = {
                name: name,
                values: values.filter(vote => vote.startsWith('vote') ? vote.replace('vote', '').trim() : vote).map(name => 'vote ' + name.trim()),
                selectableCount: true
            }

            let {
                key
            } = await anya.sendMessage(m.chat, {
                poll: poll
            })

            anya.voting[m.chat] = {
                chatId: m.chat,
                key,
                voters: [],
                timeout: setTimeout(async function() {
                    const chatId = m.chat;
                    await anya.sendMessage(chatId, {
                        delete: key
                    })
                    let voting = anya.voting[chatId];
                    if (voting && voting.voters.length > 0) {
                        const votesArray = voting.voters;
                        let voters = getVoteResult(votesArray);
                        anya.sendMessage(chatId, {
                            text: `Voting terbanyak jatuh kepada *${voters.winner}* dengan jumlah vote: ${voters.count}`
                        }, {
                            quoted: func.fverified,
                            ephemeralExpiration: m.expiration
                        })
                    }
                    delete anya.voting[chatId];
                }, 1000 * 30 * values.length)
            }
        }
    },
    main: async (m, {
        func,
        anya,
        store
    }) => {
        anya.voting = anya.voting || {};
        if (typeof anya.voting[m.chat] !== 'undefined') {
            let votingData = anya.voting[m.chat];
            if (m.message?.pollUpdateMessage && m.message?.pollUpdateMessage?.pollCreationMessageKey?.id === votingData.key.id) {
                const messageCtx = normalizeMessageContent(m.message);
                const key = messageCtx.pollUpdateMessage.pollCreationMessageKey;
                const msg = store.messages[m.chat]?.array?.find(x => key.id === x.key.id);
                if (!msg) return false
                const message = msg.message;
                const botJid = jidNormalizedUser(anya.authState.creds.me.id);
                const voterJid = getKeyAuthor(m.key, botJid);
                const pollCreatorJid = getKeyAuthor(key, botJid);
                const pollEncKey = message.messageContextInfo?.messageSecret;
                const vote = decryptPollVote(messageCtx.pollUpdateMessage.vote, {
                    pollEncKey: pollEncKey,
                    pollCreatorJid: pollCreatorJid,
                    pollMsgId: key.id,
                    voterJid: voterJid
                });
                if (!vote) return false
                const pollCreation = [{
                    key: key,
                    update: {
                        pollUpdates: [{
                            pollUpdateMessageKey: m.key,
                            vote: vote,
                            senderTimestampMs: m.messageTimestamp
                        }]
                    }
                }];
                const pollUpdate = await getAggregateVotesInPollMessage({
                    message: message,
                    pollUpdates: pollCreation[0]?.update.pollUpdates
                });
                if (!pollUpdate) return false;
                const voteName = pollUpdate?.find(v => v.voters.length !== 0)?.name;
                let votersData = votingData.voters.find(x => x.jid === m.sender);
                let name = voteName.replace('vote', '')?.trim();
                if (!votersData) {
                    votingData.voters.push({
                        jid: m.sender,
                        vote: name
                    })
                } else {
                    votersData.vote = name
                }
            }
        }
    },
    group: true,
    admin: true
}

function getVoteResult(votes) {
    const voteCount = {};

    // Hitung jumlah vote untuk setiap pilihan
    votes.forEach(vote => {
        if (voteCount[vote.vote]) {
            voteCount[vote.vote]++;
        } else {
            voteCount[vote.vote] = 1;
        }
    });

    // Temukan vote terbanyak
    let maxVote = 0;
    let winner = '';

    for (const [candidate, count] of Object.entries(voteCount)) {
        if (count > maxVote) {
            maxVote = count;
            winner = candidate;
        }
    }

    return {
        winner: winner,
        count: maxVote
    };
}