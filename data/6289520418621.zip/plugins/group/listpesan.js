exports.run = {
  usage: ['listpesan', 'totalchat'],
  hidden: ['listchat'],
  category: 'group',
  async: async (m, { func, anya, groups }) => {
    let members = groups.member.filter((v) => v.chat !== undefined && global.db.users[v.jid] !== undefined && v.chat > 0);
    let data = members.filter(itemPertama => m.members.some(itemKedua => itemKedua.id === itemPertama.jid));
    if (data.length == 0) return m.reply('Empty data.');
    
    let listchat = data.sort((a, b) => b.chat - a.chat);
    let totalpesan = 0;
    for (let x of listchat) totalpesan += x.chat;
    
    let txt = `乂  *L I S T - P E S A N*\n`;
    txt += `\nNama Group: *${m.groupName}*`;
    txt += `\nTotal Peserta: *${data.length}*`;
    txt += `\nTotal Semua Pesan: *${func.rupiah(totalpesan)}*`;
    txt += `\nKamu Top ${listchat.findIndex(v => v.jid === m.sender) + 1} Chat dari ${m.members.length} Peserta\n`;
    
    // Ngetag tanpa s.whatsapp.net
    txt += listchat.map((v, i) => `${i + 1}. @${v.jid.split('@')[0]} ~> ${v.chat} pesan`).join('\n');
    
    m.reply(txt, { mentions: listchat.map(v => v.jid) }); // Pastikan ngetag dengan mentions
  },
  group: true
}