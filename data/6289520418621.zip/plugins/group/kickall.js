let database = {};
let count = 0;

exports.run = {
usage: ['kickall'],
category: 'admin tools',
async: async (m, { func, anya }) => {
if (m.isGc && !m.isBotAdmin) return m.reply(global.mess.botAdmin)
if (m.isGc && !m.isAdmin && !m.isOwner) return m.reply(global.mess.admin)
if (m.isPc && !m.text) return m.reply('Input id grupnya!')
let from = m.isGc ? m.chat : m.text;
if (!from.endsWith('@g.us')) return m.reply('Input id grup dengan benar!')
if (!anya.isgroup(from)) return m.reply('Bot tidak berada didalam grup tersebut.')
let meta = await (await anya.groupMetadata(from));
let members = meta.participants.filter(v => v.admin == null).map(x => x.id);
if (members.length == 0) return m.reply('Data empty.')
let txt = `Are you sure you want to kick all participants group "${meta.subject}" ?
Timeout *60* detik.\n\nketik *(Y/N)*`.trim()
let { key } = await anya.reply(m.chat, txt, m, {expiration: m.expiration})
database[m.sender] = {
sender: m.sender,
from: from,
key: m.key,
members: members,
timeout: setTimeout(() => {
m.reply('Timeout.');
anya.sendMessage(m.chat, { delete: key });
delete database[m.sender];
}, 60 * 1000)
}
},
main: async (m, { func, anya }) => {
if (m.isBot) return
if (!(m.sender in database)) return
if (!m.budy) return
let { sender, from, key, members, timeout } = database[m.sender]
if (m.id === key.id) return
if (func.somematch(['n', 'no'], m.budy.toLowerCase())) {
clearTimeout(timeout)
delete database[sender]
return m.reply('Kick all successfully cancelled.')
}
if (func.somematch(['y', 'yes'], m.budy.toLowerCase())) {
try {
clearTimeout(timeout)
m.reply(`Wait is kicking ${members.length} participants...`)
for (let i of members) {
await func.delay(1500)
await anya.groupParticipantsUpdate(from, [i], 'remove')
count++
}
delete database[sender]
m.reply(`Succes kick all *${count}* participants.`)
} catch (err) {
m.reply(`Failed to kick all participants.`)
}
}
},
owner: true
}