function isAlreadyResponList(key, _db) {
    let found = _db.find(x => x.name === key)
    return found ? true : false;
}

function delResponList(key, _db) {
    let index = _db.findIndex(x => x.name === key)
    if (index !== -1) {
        _db.splice(index, 1)
    }
}

exports.run = {
    usage: [
        'addlist',
        'dellist',
        'list',
        'clearlist',
    ],
    use: 'reply sticker or text',
    category: 'admin tools',
    async: async (m, {
        func,
        anya,
        groups,
        quoted
    }) => {
        switch (m.command) {
            case 'addlist': {
                if (!m.isGc) return m.reply(global.mess.group);
                if (!(m.isAdmin || m.isOwner)) return m.reply(global.mess.admin);
                if (/webp|audio/.test(quoted.mime)) {
                    if (!m.text) return m.reply('Masukkan nama list-nya!')
                    let name = m.text.trim().toLowerCase();
                    if (isAlreadyResponList(name, groups.list)) return m.reply('Nama tersebut sudah ada di database!')
                    let media = await quoted.download();
                    let catbox = await func.catbox(media);
                    if (!catbox.status || !/https:\/\/files\.catbox\.moe\/[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)$/.test(catbox.url)) return m.reply('Failed to upload stickers, please try again.')
                    groups.list.push({
                        name: name,
                        type: /webp/.test(quoted.mime) ? 'sticker' : /audio/.test(quoted.mime) ? 'audio' : 'video',
                        content: catbox.url,
                    })
                    await m.reply(`Sukses menambahkan list dengan nama *${name}* ke dalam database!`)
                } else if (m.quoted && m.quoted.text) {
                    if (!m.text) return m.reply('Masukkan nama list-nya!')
                    let name = m.text.trim().toLowerCase();
                    if (isAlreadyResponList(name, groups.list)) return m.reply('Nama tersebut sudah ada di database!')
                    groups.list.push({
                        name: name,
                        type: 'text',
                        content: m.quoted.text,
                    })
                    await m.reply(`Successfully added list with name *${name}* to database!`)
                } else m.reply(`Reply stiker atau text dengan caption ${m.cmd} <nama list>`);
            }
            break
            case 'dellist': {
                if (!m.isGc) return m.reply(global.mess.group);
                if (!(m.isAdmin || m.isOwner)) return m.reply(global.mess.admin);
                if (!m.text) return m.reply(func.example(m.cmd, 'test'))
                let name = m.text.trim().toLowerCase();
                if (!isAlreadyResponList(name, groups.list)) return m.reply('Nama tersebut tidak ada di database!')
                delResponList(name, groups.list);
                await m.reply(`Successfully deleted list with name *${name}* from database!`)
            }
            break
            case 'list': {
                if (!m.isGc) return m.reply(global.mess.group);
                const data = groups.list;
                if (data.length == 0) return m.reply('Belum ada list message di database.')
                let caption = '*L I S T - R E S P O N S E*\n\n'
                caption += data.sort((a, b) => a.name.localeCompare(b.name)).map((item, index) => (index + 1) + '. ' + item.name + '\n- Type: ' + item.type).join('\n\n');
                anya.reply(m.chat, caption, m, {
                    expiration: m.expiration
                })
            }
            break
            case 'clearlist': {
                if (!m.isGc) return m.reply(global.mess.group);
                if (!(m.isAdmin || m.isOwner)) return m.reply(global.mess.admin);
                const data = groups.list
                if (data.length == 0) return m.reply('Empty data.');
                groups.list = [];
                m.reply('Successfully clear all list.');
            }
            break
        }
    },
    main: async (m, {
        anya,
        groups
    }) => {
        /* FUNCTION LIST BY ZIDAN */
        let response = m.budy && m.budy.trim().toLowerCase();
        if (m.isGc && m.budy && isAlreadyResponList(response, groups.list) && !m.isPrefix) {
            let data = groups.list.find(item => item.name === response);
            if (data.type === 'sticker') {
                anya.sendMessage(m.chat, {
                    sticker: {
                        url: data.content
                    },
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
            } else if (data.type === 'audio') {
                anya.sendMessage(m.chat, {
                    audio: {
                        url: data.content
                    },
                    mimetype: 'audio/mpeg',
                    ptt: false
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
            } else if (data.type === 'text') {
                anya.sendMessage(m.chat, {
                    text: data.content,
                    mentions: anya.ments(data.content)
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
            }
        }
    },
    location: 'plugins/group/list.js'
}