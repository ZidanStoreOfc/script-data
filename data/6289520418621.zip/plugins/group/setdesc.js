exports.run = {
usage: ['setdesc'],
hidden: ['setdesk', 'setdeskripsi'],
use: 'text',
category: 'group',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'New Description'))
await anya.groupUpdateDescription(m.chat, m.text)
.then((res) => anya.sendReact(m.chat, '✅', m.key))
.catch((e) => anya.sendReact(m.chat, '❌', m.key))
},
group: true,
admin: true,
botAdmin: true
}