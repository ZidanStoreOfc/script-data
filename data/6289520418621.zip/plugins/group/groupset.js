exports.run = {
usage: ['groupset'],
hidden: ['grup', 'gc'],
use: 'open / close',
category: 'group',
async: async (m, { func, anya }) => {
if (m.args[0] === 'close'){
await anya.groupSettingUpdate(m.chat, 'announcement')
.then((res) => anya.sendMessage(m.chat, {react: {text: '✅', key: m.key}}))
.catch((err) => anya.sendReact(m.chat, '❌', m.key))
} else if (m.args[0] === 'open'){
await anya.groupSettingUpdate(m.chat, 'not_announcement')
.then((res) => anya.sendMessage(m.chat, {react: {text: '✅', key: m.key}}))
.catch((err) => anya.sendReact(m.chat, '❌', m.key))
} else m.reply(func.example(m.cmd, 'open / close'))
},
group: true,
admin: true,
botAdmin: true
}