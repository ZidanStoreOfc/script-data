exports.run = {
usage: ['bbc'],
use: 'bbc',
category: 'admin tools',
async: async (m, { func, anya, groups }) => {
if (m.text && isNaN(m.text)) return m.reply(func.example(m.cmd, '50'))
let bbc = Number(m.args[0])
let data = groups.member.filter((v) => v.chat !== undefined && v.chat < bbc)
let member = data.filter(itemPertama => m.members.some(itemKedua => itemKedua.id === itemPertama.jid)).map(x => x.jid)
if (member.length == 0) return m.reply('Empty data.')
await m.reply(`wait is kicking ${member.length} member...`)
for (let jid of member) {
if (jid === m.bot) continue;
await anya.groupParticipantsUpdate(m.chat, [jid], 'remove')
await func.delay(3000)
}
m.reply(`success kick ${member.length} member dengan bbc kurang dari ${bbc}`)
},
group: true,
admin: true,
botAdmin: true
}