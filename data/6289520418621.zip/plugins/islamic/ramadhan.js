const moment = require('moment-timezone');

exports.run = {
    usage: ['ramadhan'],
    hidden: ['cekpuasa'],
    category: 'islamic',
    async: async (m, {
        func,
        anya
    }) => {

        function hitungMundurRamadhan() {
            // Mengatur timezone ke Asia/Jakarta
            const tanggalRamadhan = moment.tz('2025-02-28', 'Asia/Jakarta');
            const tanggalHariIni = moment.tz('Asia/Jakarta');
            const selisihHari = tanggalRamadhan.diff(tanggalHariIni, 'days');
            let pesan = '';

            if (selisihHari > 0) {
                pesan = `Tinggal ${selisihHari} hari menuju Ramadhan.`;
            } else if (selisihHari === 0) {
                pesan = `Hari ini adalah hari Ramadhan! Selamat menjalankan ibadah puasa.`;
            } else {
                pesan = `Ramadhan sudah berlalu. Semoga ibadah puasamu diterima.`;
            }

            return pesan;
        }

        hitungMundurRamadhan()

        const caption = hitungMundurRamadhan();
        anya.reply(m.chat, caption, m, {
            expiration: m.expiration
        })
    },
    location: 'plugins/islamic/ramadhan.js'
}