const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

const transcribe = async (audioPath) => {
    try {
        const formData = new FormData();
        const fileStream = fs.createReadStream(audioPath);
        const fileName = path.basename(audioPath);

        formData.append('file', fileStream, {
            filename: fileName,
            contentType: 'audio/mpeg'
        });
        const config = {
            headers: {
                ...formData.getHeaders(),
                'authority': 'api.talknotes.io',
                'accept': '*/*',
                'accept-encoding': 'gzip, deflate, br',
                'origin': 'https://talknotes.io',
                'referer': 'https://talknotes.io/',
                'User-Agent': 'Postify/1.0.0'
            },
            maxBodyLength: Infinity
        };
        const response = await axios.post('https://api.talknotes.io/tools/converter', formData, config);
        return response.data;
    } catch (error) {
        if (error.response) {
            throw new Error(`${error.response.status}: ${error.response.data}`);
        } else if (error.request) {
            throw new Error('Failed to convert audio to text');
        } else {
            throw new Error(error.message);
        }
    }
}

exports.run = {
    usage: 'whisper2',
    hidden: 'transcribe',
    use: 'reply audio',
    category: 'convert',
    async: async (m, {
        func,
        anya,
        quoted
    }) => {
        if (!m.quoted) return m.reply(`Reply audio dengan perintah ${m.cmd}`)
        if (!/audio/.test(quoted.mime)) return m.reply(`Reply audio dengan perintah ${m.cmd}`)
        anya.sendReact(m.chat, '🕒', m.key)
        try {
            let media = await anya.downloadAndSaveMediaMessage(m)
            let result = await transcribe(media);
            anya.sendMessage(m.chat, {
                text: result.text
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
        } catch (error) {
            console.error("Error in main function:", error);
            return anya.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    premium: true,
    vvip: true
}