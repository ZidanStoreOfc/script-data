exports.run = {
    usage: ['brat'],
    hidden: ['brt'],
    use: 'text',
    category: 'tools',
    async: async (m, { func, anya, packname, author }) => {
        // Mendapatkan waktu saat ini
        const now = new Date();
        const hours = now.getUTCHours() + 7; // Mengonversi ke WIB (UTC+7)

        // Cek apakah waktu saat ini antara jam 18:00 dan 20:00 WIB
        if (hours >= 18 && hours < 21) {
            return m.reply('Fitur ini tidak dapat digunakan antara jam 18:00 - 21:00 WIB.');
        }

        let text;
        if (m.args.length >= 1) {
            text = m.args.slice(0).join(' ');
        } else if (m.quoted && m.quoted.text) {
            text = m.quoted.text;
        } else return m.reply('Input atau reply text!');

        if (!text) return m.reply(func.example(m.cmd, 'zidan'));
        if (text.length > 150) return m.reply('Max 150 character!');

        anya.sendReact(m.chat, '🕒', m.key);
        const url = `https://ochinpo-helper.hf.space/brat?text=${encodeURIComponent(text)}`;

        try {
            // Mengirim stiker ke saluran
            const channelId = "120363378890662177@newsletter"; // Ganti dengan JID saluran Anda
            
            // Cek status pengguna
            if (m.isPrem || m.isVvip || m.isOwner || m.isDevs) {
                // Kirim stiker langsung ke pengguna
                await anya.sendStickerFromUrl(m.chat, url, m, {
                    packname: packname,
                    author: author,
                    expiration: m.expiration
                });
            } else {
                // Kirim stiker ke saluran untuk pengguna gratis
                await anya.sendStickerFromUrl(channelId, url, m, {
                    packname: packname,
                    author: author,
                    expiration: m.expiration
                });

                // Kirim pesan sukses ke chat pengguna setelah stiker berhasil dibuat
                anya.reply(m.chat, 'Stiker brat berhasil dibuat\n- Silahkan ambil disini: https://whatsapp.com/channel/0029Vb0NWHW1dAvuE5yUDZ0b', m);

                // Kirim pesan request dari nama pengguna
                const requestMessage = `Request from ${m.pushname}`;
                await anya.sendMessage(channelId, { text: requestMessage });
            }
        } catch (error) {
            console.error('Error sending sticker or message:', error);
            return m.reply('Terjadi kesalahan saat mengirim stiker.');
        }
    },
    location: "plugins/convert/brat.js",
    limit: 10
};