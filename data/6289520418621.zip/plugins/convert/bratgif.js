const fs = require("fs"),
    path = require("path"),
    axios = require("axios"),
    execSync = require("child_process").execSync;

exports.run = {
    usage: ["bratvideo"],
    hidden: ["bratgif"],
    use: "text",
    category: "convert",
    async: async (r, { func: e, anya: a, packname: i, author: n }) => {
    // Mendapatkan waktu saat ini
        const now = new Date();
        const hours = now.getUTCHours() + 7; // Mengonversi ke WIB (UTC+7)

        // Cek apakah waktu saat ini antara jam 18:00 dan 20:00 WIB
        if (hours >= 18 && hours < 21) {
            return m.reply('Fitur ini tidak dapat digunakan antara jam 18:00 - 21:00 WIB.');
        }
        
        let t;
        if (1 <= r.args.length) {
            t = r.args.slice(0).join(" ");
        } else {
            if (!r.quoted || !r.quoted.text) return r.reply("Input atau reply text!");
            t = r.quoted.text;
        }
        if (!t) return r.reply(e.example(r.cmd, "hello world"));
        if (t.length > 250) return r.reply("Max 250 character!");
        if (t.split(" ").length < 2) {
           return r.reply("Minimal 2 kata!");
        }

        a.sendReact(r.chat, "🕒", r.key);
        var s = t.split(" "),
            c = path.resolve("media"),
            l = (fs.existsSync(c) || fs.mkdirSync(c), []);
        
        try {
            for (let e = 0; e < s.length; e++) {
                var o = s.slice(0, e + 1).join(" "),
                    p = await axios.get("https://brat.caliphdev.com/api/brat?text=" + encodeURIComponent(o), {
                        responseType: "arraybuffer"
                    }).catch(e => e.response),
                    f = path.join(c, `frame${e}.mp4`);
                fs.writeFileSync(f, p.data), l.push(f);
            }
            var u = path.join(c, "filelist.txt");
            let fileListContent = "";
            for (let e = 0; e < l.length; e++) {
                fileListContent += `file '${l[e]}'\nduration 0.7\n`;
            }
            fileListContent += `file '${l[l.length - 1]}'\nduration 2\n`;
            fs.writeFileSync(u, fileListContent);

            var h = path.join(c, "output.mp4");
            execSync(`ffmpeg -y -f concat -safe 0 -i ${u} -vf "fps=30" -c:v libx264 -preset ultrafast -pix_fmt yuv420p ${h}`);

            // Mengirim stiker ke saluran
            const channelId = "120363378890662177@newsletter"; // Ganti dengan JID saluran Anda
            
            // Cek status pengguna
            if (r.isPrem || r.isVvip || r.isOwner || r.isDevs) {
                // Kirim stiker langsung ke pengguna
                await a.sendStickerFromUrl(r.chat, h, r, {
                    packname: i,
                    author: n,
                    expiration: r.expiration
                });
            } else {
                // Kirim stiker ke saluran untuk pengguna gratis
                await a.sendStickerFromUrl(channelId, h, r, {
                    packname: i,
                    author: n,
                    expiration: r.expiration
                });

                // Kirim pesan sukses ke chat pengguna setelah stiker berhasil dibuat
                a.reply(r.chat, 'Stiker brat video berhasil dibuat\n- Silahkan ambil disini: https://whatsapp.com/channel/0029Vb0NWHW1dAvuE5yUDZ0b', r);
                
                // Kirim pesan request dari nama pengguna
                const requestMessage = `Request from ${r.pushname}`;
                await a.sendMessage(channelId, { text: requestMessage });
            }

            // Hapus file sementara
            l.forEach(e => {
                fs.existsSync(e) && fs.unlinkSync(e);
            });
            fs.existsSync(u) && fs.unlinkSync(u);
            fs.existsSync(h) && fs.unlinkSync(h);
        } catch (e) {
            a.reply(r.chat, `An error occurred while creating the sticker.\n- ${e.message}`, r, {
                expiration: r.expiration
            });
        }
    },
    location: "plugins/convert/bratgif.js",
    limit: 5
};