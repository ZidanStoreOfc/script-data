const axios = require('axios');
const { fromBuffer } = require('file-type');
exports.run = {
usage: ['stickermeme'],
hidden: ['smeme'],
use: 'text atas | bawah',
category: 'convert',
async: async (m, { func, anya, quoted, packname, author }) => {
let [atas, bawah] = m.text.includes('|') ? m.text.split('|').map(v => v.trim()) : [m.text, ''];
if (!m.text) return m.reply(func.example(m.cmd, 'beliau | awikawok'));
if (m.text.length > 75) return m.reply('Textnya kepanjangan.');
if (/image\/(jpe?g|png|webp)/.test(quoted.mime)) {
if (/webp/.test(quoted.mime) && m.quoted.isAnimated) return m.reply('Not support gif stickers.');
anya.sendReact(m.chat, '🕒', m.key);
try {
const media = await anya.downloadAndSaveMediaMessage(quoted);
const uploadResult = await func.UploadFileUgu(media);
if (!uploadResult.url) throw new Error('Upload failed');
let meme_url = `https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${uploadResult.url}`;
anya.sendSticker(m.chat, meme_url, m, { packname, author, expiration: m.expiration });
anya.sendReact(m.chat, '✅', m.key);
} catch (error) {
anya.sendReact(m.chat, '❌', m.key);
m.reply('Terjadi kesalahan saat memproses gambar.');
}
} else m.reply(`Kirim/Reply gambar dengan caption ${m.cmd} text atas | text bawah`);
},
restrict: true,
limit: 5
}