const axios = require('axios');
const cheerio = require('cheerio');

async function hentaiS(hentai) {
  try {
    const ress = await axios.get(`https://nhentai.net/search/?q=${encodeURIComponent(hentai)}`);
    const $ = cheerio.load(ress.data);
    const results = [];

    $('.gallery').each((index, element) => {
      const title = $(element).find('.caption').last().text().trim();
      const imgSrc = $(element).find('img.lazyload').data('src');
      const link = $(element).find('a.cover').attr('href');
      
      results.push({
        title,
        imgSrc,
        link: `https://nhentai.net${link}`
      });
    });

    return results;
  } catch (error) {
    console.error('Error fetching data from NHentai:', error.message);
    throw error;
  }
}

exports.run = {
  usage: ['hentai'],
  category: 'nsfw',
  async: async (m, { func, anya }) => {
    const keyword = m.text;
    if (!keyword) {
      return m.reply('Tolong berikan kata kunci untuk pencarian hentai!');
    }

    try {
      const results = await hentaiS(keyword);
      if (results.length === 0) {
        return m.reply('Tidak ada hasil yang ditemukan!');
      }

      // Kirim hasil pencarian
      let response = 'Hasil pencarian:\n';
      results.forEach((result, index) => {
        response += `${index + 1}. ${result.title}\n${result.link}\n${result.imgSrc}\n\n`;
      });

      m.reply(response);
    } catch (error) {
      m.reply('Terjadi kesalahan saat mencari hentai.');
    }
  }
};