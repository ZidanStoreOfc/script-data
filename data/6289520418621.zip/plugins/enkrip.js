const { obfuscate } = require('javascript-obfuscator');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

async function createPaste(content) {
const data = {
key: "abFFSw5uEbwkh1APp0hRTbwXgU4B9DZZwf7rjRPZE",
description: "Paste created via API",
sections: [{ name: "Section 1", syntax: "text", contents: content }],
expires: "1w"
};
try {
const response = await axios.post("https://api.paste.ee/v1/pastes", data, {
headers: {
"Content-Type": "application/json",
"X-Auth-Token": "abFFSw5uEbwkh1APp0hRTbwXgU4B9DZZwf7rjRPZE"
}
});
const result = response.data;
const rawUrl = result.link.replace('/p/', '/r/') + "/0";
return result ? { status: 0, original: result.link, raw: rawUrl } : { status: 1, original: null, raw: null };
} catch (error) {
return logError(error);
}
}

function logError(error) {
console.error("[ERROR]", error);
return {
status: 1,
original: null,
raw: null,
error: error.response ? error.response.data : error.message
};
}

function formatResponse(response) {
return response.status === 0 ? `${response.raw}` : `Error: ${response.error}`;
}

exports.run = {
usage: ['enkrip'],
category: 'owner',
async: async (m, { anya, quoted }) => {
if (!quoted) return m.reply('Harap reply ke pesan yang ingin di-enkrip.');
try {
let input;
let fileName = 'obfuscator.js';
if (m.quoted && /application\/(javascript|octet-stream)/i.test(m.quoted.mime)) {
let buffer = await m.quoted.download();
input = Buffer.from(buffer, 'base64').toString('utf-8');
fileName = m.quoted.fileName;
} else if (m.quoted && m.args.length == 1 && /\.js$/.test(m.args[0])) {
input = m.quoted.text;
fileName = m.text;
} else if (m.text) {
let filename = m.text.trim().toLowerCase()
let filePath = path.join(process.cwd(), filename)
if (!fs.existsSync(filePath)) {
return m.reply(`File ${filename} does not exist!`)
}
input = fs.readFileSync(filePath, 'utf-8')
fileName = path.basename(filePath)
} else return m.reply('reply file script yang ingin di enkrip.')
await anya.sendReact(m.chat, '🕒', m.key)
// Daftar 50 kata terlarang
const forbiddenWords = [
"/* drug */", "/* violence */", "/* adult content */", "/* hate speech */", "/* self-harm */",
"/* suicide */", "/* illegal activities */", "/* terrorism */", "/* harassment */", "/* exploitation */",
"/* abuse */", "/* racism */", "/* sexism */", "/* extremist content */", "/* phishing */",
"/* malware */", "/* ransomware */", "/* spam */", "/* identity theft */", "/* hacking */",
"/* adult material */", "/* drug trafficking */", "/* sexual violence */", "/* torture */", "/* gore */",
"/* bomb making */", "/* bomb threats */", "/* cyberbullying */", "/* abusive language */", "/* predatory behavior */",
"/* child exploitation */", "/* adult services */", "/* stalking */", "/* doxxing */", "/* dangerous organizations */",
"/* insider trading */", "/* fraud */", "/* counterfeit */", "/* scam */", "/* illegal gambling */",
"/* illegal drug sales */", "/* copyright infringement */", "/* illicit substances */", "/* unwanted contact */",
"/* unauthorized access */", "/* human trafficking */", "/* illegal weapons */", "/* unethical practices */",
"/* exploitative content */", "/* unethical behavior */", "/* harmful content */", "/* prohibited material */",
"/* sensitive information */", "/* confidential data */", "/* illegal downloads */", "/* abusive conduct */",
"/* exploitative practices */", "/* illicit activity */", "/* prohibited behavior */", "/* sensitive topics */"
];

let enhancedData = input;
forbiddenWords.forEach(word => {
enhancedData += ` ${word}`;
});

const obfuscationOptions = {
compact: true,
controlFlowFlattening: true,
controlFlowFlatteningThreshold: 1.0,
deadCodeInjection: true,
deadCodeInjectionThreshold: 1.0,
debugProtection: true,
disableConsoleOutput: false,
identifierNamesGenerator: 'mangled',
identifiersPrefix: 'zidandev_',
numbersToExpressions: true,
renameGlobals: true,
selfDefending: true,
stringArray: true,
stringArrayEncoding: ['base64', 'rc4'],
stringArrayThreshold: 1.0,
unicodeEscapeSequence: true,
simplify: false,
splitStrings: true,
splitStringsChunkLength: 5,
transformObjectKeys: true,
additionalContent: 'metadata{random}dummy{data}to{increase}complexity'
};

const obfuscatedCode = obfuscate(enhancedData, obfuscationOptions).getObfuscatedCode().replace(/\n/g, '');
const filePath = './sampah/obfuscator.js';
fs.writeFileSync(filePath, obfuscatedCode);

// Kirim file obfuscator.js
await anya.sendMessage(m.chat, {
document: {
url: filePath
},
mimetype: 'application/javascript',
fileName: fileName
}, {quoted: m, ephemeralExpiration: m.expiration})
} catch (e) {
console.error(e);
m.reply(`Terjadi kesalahan saat meng-enkrip pesan: ${e.message}`);
}
},
devs: true
}