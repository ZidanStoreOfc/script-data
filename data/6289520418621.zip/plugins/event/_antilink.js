exports.run = {
    main: async (m, {
        func,
        anya,
        groups,
        errorMessage
    }) => {
        try {
            // remove link then kick when antilink is turned on
            if (m.budy && groups.antilink && !m.isAdmin && !m.isOwner) {
                if (m.budy.match(/(chat.whatsapp.com)/gi) && !['https://chat.whatsapp.com/FqVsOBT29wd0jcD7g6GN8A', 'https://chat.whatsapp.com/' + await anya.groupInviteCode(m.chat)].includes(m.budy)) return anya.sendMessage(m.chat, {
                        delete: {
                            remoteJid: m.chat,
                            fromMe: false,
                            id: m.key.id,
                            participant: m.sender
                        }
                    })
                    .then(() => anya.sendMessage(m.chat, {
                        text: `Sorry @${m.sender.split('@')[0]} you will be removed from this group.`,
                        mentions: [m.sender]
                    }, {
                        quoted: func.fstatus('Anti Tautan Grup Lain'),
                        ephemeralExpiration: m.expiration
                    }))
                    .then(() => anya.groupParticipantsUpdate(m.chat, [m.sender], 'remove'))
            }

            if (m.budy && groups.antilinkall && !m.isAdmin && !m.isOwner) {
                const linkRegex = /https?:\/\/[^\s]+/g;

                if (linkRegex.test(m.budy)) {
                    await anya.sendMessage(m.chat, {
                        delete: {
                            remoteJid: m.chat,
                            fromMe: false,
                            id: m.key.id,
                            participant: m.sender
                        }
                    });

                    await anya.sendMessage(m.chat, {
                        text: `Detected @${m.sender.split('@')[0]} has sent *HTTP* Link. Sorry, your message will be deleted by the bot.`,
                        mentions: [m.sender]
                    }, {
                       quoted: func.fstatus('Anti Link All'),
                       ephemeralExpiration: m.expiration
                   });
                    await anya.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
                }
            }
            
            if (m.budy && groups.antilinkallnokick && !m.isAdmin && !m.isOwner) {
                const linkRegex = /https?:\/\/[^\s]+/g;

                if (linkRegex.test(m.budy)) {
                    await anya.sendMessage(m.chat, {
                        delete: {
                            remoteJid: m.chat,
                            fromMe: false,
                            id: m.key.id,
                            participant: m.sender
                        }
                    });

                    await anya.sendMessage(m.chat, {
                        text: `Detected @${m.sender.split('@')[0]} has sent *HTTP* Link. Sorry, your message will be deleted by the bot.`,
                        mentions: [m.sender]
                    }, {
                       quoted: func.fstatus('Anti Link All No Kick'),
                       ephemeralExpiration: m.expiration
                   });
                }
            }

            if (m.budy && m.budy.match(/(whatsapp.com\/channel)/gi) && !m.isAdmin && !m.isOwner) {
                return await anya.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.key.id,
                        participant: m.sender
                    }
                })
            } else {
                const newsletterMessage = m.msg?.contextInfo?.forwardedNewsletterMessageInfo;
                if (newsletterMessage && !m.isAdmin && !m.isOwner) {
                    if (['120363375037255604@newsletter'].includes(newsletterMessage.newsletterJid)) return false;
                    let text = `*Newsletter Message Detected*

- Jid: ${newsletterMessage.newsletterJid}
- Name: ${newsletterMessage.newsletterName}`
                    anya.reply(m.chat, text, m, {
                        expiration: m.expiration
                    })
                    return await anya.sendMessage(m.chat, {
                        delete: {
                            remoteJid: m.chat,
                            fromMe: false,
                            id: m.key.id,
                            participant: m.sender
                        }
                    })
                }
            }
        } catch (error) {
            return errorMessage(error)
        }
    },
    group: true,
    botAdmin: true,
    location: 'plugins/event/_antilink.js'
}