exports.run = {
main: async (m, { func, anya, groups }) => {
if (groups.antiviewonce && m.msg && m.msg.viewOnce && !m.fromMe) {
let caption = `乂  *ANTI VIEWONCE*\n\n◦  From: ${m.pushname}${m.budy ? '\n◦  Caption: ' + m.budy : ''}`
let buffer = await anya.downloadMediaMessage(m.msg)
if (/image/.test(m.mtype)) {
await anya.sendMessage(m.chat, {image: buffer, caption: caption, mentions: anya.ments(caption)}, {quoted: m, ephemeralExpiration: m.expiration})
} else if (/video/.test(m.mtype)) {
await anya.sendMessage(m.chat, {video: buffer, caption: caption, mimetype: 'video/mp4', mentions: anya.ments(caption)}, {quoted: m, ephemeralExpiration: m.expiration})
}
}
},
group: true
}