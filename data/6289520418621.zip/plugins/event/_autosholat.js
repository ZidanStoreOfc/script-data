exports.run = {
    main: async (m, {
        func,
        anya,
        setting
    }) => {
        anya.autosholat = anya.autosholat ? anya.autosholat : {};
        let chatId = m.chat;
        if (chatId in anya.autosholat) {
            return false;
        }
        // jadwal sholat wilayah jakarta dan sekitarnya
        let jadwalSholat = {
            Subuh: '04:34',
            Dhuhur: '12:06',
            Ashar: '15:26',
            Maghrib: '18:17',
            Isya: '19:30',
        };
        let thumb = {
            'Subuh': 'https://telegra.ph/file/b666be3c20c68d9bd0139.jpg',
            'Dhuhur': 'https://telegra.ph/file/5295095dad53783b9cd64.jpg',
            'Ashar': 'https://telegra.ph/file/c0e1948ad75a2cba22845.jpg',
            'Maghrib': 'https://telegra.ph/file/0082ad9c0e924323e08a6.jpg',
            'Isya': 'https://telegra.ph/file/fd141833a983afa0a8412.jpg',
        };
        let date = new Date(new Date().toLocaleString('en-US', {
            timeZone: 'Asia/Jakarta'
        }));
        let hours = date.getHours();
        let minutes = date.getMinutes();
        let timeNow = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
        for (let [sholat, waktu] of Object.entries(jadwalSholat)) {
            if (timeNow === waktu) {
                // let txt = `Selamat menunaikan ibadah sholat ${sholat}`;
                anya.autosholat[chatId] = [
                    anya.sendMessage(m.chat, {
                        audio: {
                            url: 'https://files.catbox.moe/0nj6pp.mp3'
                        },
                        mimetype: 'audio/mpeg',
                        contextInfo: {
                            mentionedJchatId: [m.sender],
                            externalAdReply: {
                                title: `Waktu ${sholat} telah tiba, ambilah air wudhu dan segeralah sholat.`,
                                body: `${waktu} untuk wilayah Jakarta dan sekitarnya`,
                                mediaType: 1,
                                previewType: 'PHOTO',
                                sourceUrl: '',
                                // thumbnail: await func.fetchBuffer(thumb[sholat]),
                                thumbnailUrl: thumb[sholat],
                                renderLargerThumbnail: true
                            }
                        }
                    }, {
                        quoted: func.fverified,
                        ephemeralExpiration: m.expiration
                    }),
                    setTimeout(() => {
                        delete anya.autosholat[chatId];
                    }, 1000 * 60 * 10)
                ];
            }
        }
    },
    location: 'plugins/event/_autosholat.js'
}