exports.run = {
    main: async (m, {
        func,
        anya,
        setting
    }) => {
        const chatId = m.chat;
        const groupData = global.db.groups[chatId];
        const timerSpam = 60000;
        let limitSpam = 5;

        if (m.isPrem) {
            limitSpam = 10;
        } else if (m.isOwner || m.isDevs) {
            limitSpam = Infinity;
        }

        if (m.isBotAdmin && !groupData.hasOwnProperty('antispam')) {
            groupData.antispam = true;
        }

        if (groupData.antispam) {
            const now = Date.now();
            const userId = m.sender;

            if (!groupData.spamData) {
                groupData.spamData = {};
            }

            if (!groupData.spamData[userId]) {
                groupData.spamData[userId] = [];
            }

            // Handle text message spam
            if (/conversation|extendedTextMessage/.test(m.mtype) && !m.isPrefix) {
                const message = m.budy;
                const userMessages = groupData.spamData[userId];
                const recentMessages = userMessages.filter(msg => now - msg.timestamp < timerSpam);

                if (recentMessages && recentMessages.some(item => item.text === message)) {
                    userMessages.push({
                        text: message,
                        timestamp: now
                    });
                    if (userMessages.filter(msg => msg.text === message).length >= limitSpam) {
                        await anya.reply(chatId, `@${userId.replace(/@.+/, '')} Anda telah mengirim pesan yang sama lebih dari ${limitSpam} kali dan akan dikeluarkan dari grup.`, m, {
                            expiration: m.expiration
                        }).then(async () => {
                            await anya.groupParticipantsUpdate(chatId, [userId], 'remove');
                        })
                        return;
                    }
                    await anya.reply(chatId, `Peringatan: Anda telah mengirim pesan yang sama beberapa kali. Pesan Anda akan dihapus jika terus berlanjut.`, m, {
                        expiration: m.expiration
                    })
                    await anya.sendMessage(chatId, {
                        delete: {
                            remoteJid: chatId,
                            fromMe: false,
                            id: m.key.id,
                            participant: userId
                        }
                    });
                } else {
                    userMessages.push({
                        text: message,
                        timestamp: now
                    });
                    if (userMessages.length > limitSpam) {
                        userMessages.shift(); // Remove the earliest message
                    }
                }
            } else if (/stickerMessage/.test(m.mtype)) {
                const message = m.message.stickerMessage.fileSha256.toString('base64');
                const userMessages = groupData.spamData[userId];
                const recentMessages = userMessages.filter(msg => now - msg.timestamp < timerSpam);

                if (recentMessages && recentMessages.some(item => item.sticker === message)) {
                    userMessages.push({
                        sticker: message,
                        timestamp: now
                    });
                    if (userMessages.filter(msg => msg.sticker === message).length >= limitSpam) {
                        await anya.reply(chatId, `@${userId.replace(/@.+/, '')} Anda telah mengirim sticker yang sama lebih dari ${limitSpam} kali dan telah dikeluarkan dari grup.`, m, {
                            expiration: m.expiration
                        }).then(async () => {
                            await anya.groupParticipantsUpdate(chatId, [userId], 'remove');
                        })
                        return;
                    }
                    await anya.reply(chatId, `Peringatan: Anda telah mengirim sticker yang sama beberapa kali. Pesan Anda akan dihapus jika terus berlanjut.`, m, {
                        expiration: m.expiration
                    })
                    await anya.sendMessage(chatId, {
                        delete: {
                            remoteJid: chatId,
                            fromMe: false,
                            id: m.key.id,
                            participant: userId
                        }
                    });
                } else {
                    userMessages.push({
                        sticker: message,
                        timestamp: now
                    });
                    if (userMessages.length > limitSpam) {
                        userMessages.shift(); // Remove the earliest message
                    }
                }
            }
        }
    },
    group: true,
    botAdmin: true
};