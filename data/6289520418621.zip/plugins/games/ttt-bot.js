exports.run = {
    usage: ['tbot'],
    hidden: ['ttt-bot'],
    use: 'mention or reply',
    category: 'games',
    async: async (m, {
        func,
        anya
    }) => {
        anya.tictactoe = anya.tictactoe || {};
        if (m.sender in anya.tictactoe) return anya.reply(m.chat, 'Masih ada game yang belum selesai', anya.tictactoe[m.sender].key, {
            expiration: m.expiration
        })
        if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
        let hadiah = func.randomNomor(3000, 5000);
        let id = 'tictactoe_' + Date.now();
        let key = await anya.reply(m.chat, `@${m.sender.split('@')[0]} menantang bot untuk bermain TicTacToe\n\n*Game akan dimulai*.\n\nHadiah : ${hadiah} balance`, m, {
            expiration: m.expiration
        })
        let TicTacToe = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];
        anya.tictactoe[m.sender] = {
            id: m.sender,
            key: key,
            keyId: [],
            status: true, // Pemain memulai lebih dulu
            hadiah: hadiah,
            penantang: m.sender,
            ditantang: m.bot, // Bot is the opponent
            TicTacToe: TicTacToe
        }
        await delay(2000);
        let room = anya.tictactoe[m.sender];
        await anya.reply(m.chat, `@${room.penantang.split('@')[0]} = ❌
@${room.ditantang.split('@')[0]} = ⭕

${displayBoard(room.TicTacToe)}

Giliran @${room.penantang.split('@')[0]}`, m, {
            edit: key,
            expiration: m.expiration
        })
        room.keyId.push(key.key);
    },
    main: async (m, {
        anya,
        func
    }) => {
        anya.tictactoe = anya.tictactoe || {};
        const isTicTacToe = (from, _dir) => {
            let status = false
            Object.keys(_dir).forEach((i) => {
                if (_dir[i].id === from) {
                    status = true
                }
            })
            return status
        }

        const getPosTic = (from, _dir) => {
            let position = null
            Object.keys(_dir).forEach((i) => {
                if (_dir[i].id === from) {
                    position = i
                }
            })
            if (position !== null) {
                return position
            }
        }

        const KeisiSemua = (tic) => {
            let status = true
            for (let i of tic) {
                if (i !== '❌' && i !== '⭕') {
                    status = false
                }
            }
            return status
        }

        const cekIsi = (nomor, tic) => {
            let status = false
            if (tic[nomor] === '❌' || tic[nomor] === '⭕') {
                status = true
            }
            return status
        }

        const cekTicTac = (tic) => {
            let status = false
            if (tic[0] === '❌' && tic[1] === '❌' && tic[2] === '❌' || tic[0] === '⭕' && tic[1] === '⭕' && tic[2] === '⭕') {
                status = true
            } else if (tic[3] === '❌' && tic[4] === '❌' && tic[5] === '❌' || tic[3] === '⭕' && tic[4] === '⭕' && tic[5] === '⭕') {
                status = true
            } else if (tic[6] === '❌' && tic[7] === '❌' && tic[8] === '❌' || tic[6] === '⭕' && tic[7] === '⭕' && tic[8] === '⭕') {
                status = true
            } else if (tic[0] === '❌' && tic[3] === '❌' && tic[6] === '❌' || tic[0] === '⭕' && tic[3] === '⭕' && tic[6] === '⭕') {
                status = true
            } else if (tic[1] === '❌' && tic[4] === '❌' && tic[7] === '❌' || tic[1] === '⭕' && tic[4] === '⭕' && tic[7] === '⭕') {
                status = true
            } else if (tic[2] === '❌' && tic[5] === '❌' && tic[8] === '❌' || tic[2] === '⭕' && tic[5] === '⭕' && tic[8] === '⭕') {
                status = true
            } else if (tic[0] === '❌' && tic[4] === '❌' && tic[8] === '❌' || tic[0] === '⭕' && tic[4] === '⭕' && tic[8] === '⭕') {
                status = true
            } else if (tic[2] === '❌' && tic[4] === '❌' && tic[6] === '❌' || tic[2] === '⭕' && tic[4] === '⭕' && tic[6] === '⭕') {
                status = true
            }
            return status
        }

        async function deleteMessage(itemArray, botJid) {
            // Jika elemen ditemukan, hapus elemen tersebut dari array
            if (Array.isArray(itemArray) && itemArray.length > 0) {
                for (let [index, key] of itemArray.entries()) {
                    await new Promise(resolve => setTimeout(resolve, 500));
                    try {
                        await anya.sendMessage(key.remoteJid, {
                            delete: key
                        })
                    } catch (error) {
                        console.log(error);
                    }
                    itemArray.splice(index, 1);
                }
            }
        }
        async function botTurn(m, anya) {
            const room = anya.tictactoe[m.sender];
            const anu = room.TicTacToe;

            // Simple Bot logic:
            // 1. Check for winning move
            // 2. Check for blocking move
            // 3. Choose center if available
            // 4. Choose a random empty spot

            let botMove = getWinningMove(anu, '⭕'); // Check for bot win
            if (botMove === -1) {
                botMove = getWinningMove(anu, '❌'); // Check for player block
            }
            if (botMove === -1 && anu[4] !== '❌' && anu[4] !== '⭕') {
                botMove = 4;
            }
            if (botMove === -1) {
                const emptySpots = anu.map((val, idx) => (val !== '❌' && val !== '⭕') ? idx : -1).filter(val => val !== -1);
                botMove = emptySpots[Math.floor(Math.random() * emptySpots.length)];
            }

            if (botMove !== -1) {
                anya.tictactoe[m.sender].TicTacToe[botMove] = '⭕';
                if (cekTicTac(anya.tictactoe[m.sender].TicTacToe)) {
                    anya.reply(m.chat, `Bot Menang!

@${room.penantang.split('@')[0]} = ❌
@${room.ditantang.split('@')[0]} = ⭕

${displayBoard(anu)}`, func.fverified, {
                        expiration: m.expiration
                    });
                    delete anya.tictactoe[m.sender];
                } else if (KeisiSemua(anu)) {
                    anya.reply(m.chat, `Hasil Seri!

@${room.penantang.split('@')[0]} = ❌
@${room.ditantang.split('@')[0]} = ⭕

${displayBoard(anu)}`, func.fverified, {
                        expiration: m.expiration
                    });
                    delete anya.tictactoe[m.sender];
                } else {
                    let key = await anya.reply(m.chat, `Bot telah mengisi

@${room.penantang.split('@')[0]} = ❌
@${room.ditantang.split('@')[0]} = ⭕

${displayBoard(anu)}

Giliran @${room.penantang.split('@')[0]}`, func.fverified, {
                        expiration: m.expiration
                    });
                    room.key = key;
                    room.status = true;
                    room.keyId.push(key.key);
                }

            }
        }
        // TicTacToe logic
        if (isTicTacToe(m.sender, anya.tictactoe)) {
            try {
                let nomor = [1, 2, 3, 4, 5, 6, 7, 8, 9]
                let room = anya.tictactoe[m.sender];
                let anu = room.TicTacToe
                if (room.status === true) {
                    if (m.sender === room.penantang) {
                        for (let i of nomor) {
                            if (Number(m.budy) === i) {
                                if (cekIsi(Number(m.budy) - 1, anu)) return m.reply(`Nomor tersebut sudah terisi`)
                                anya.tictactoe[m.sender].TicTacToe[Number(m.budy) - 1] = '❌'
                                const itemArray = room.keyId;
                                console.log(itemArray);
                                await deleteMessage(itemArray, room.ditantang);
                                if (cekTicTac(anya.tictactoe[m.sender].TicTacToe)) {
                                    anya.reply(m.chat, `@${room.penantang.split('@')[0]} Menang

@${room.penantang.split('@')[0]} = ❌
@${room.ditantang.split('@')[0]} = ⭕

${displayBoard(anu)}

Hadiah : ${room.hadiah} balance`, m, {
                                        expiration: m.expiration
                                    })
                                    await anya.sendReact(m.chat, '🎉', m.key);
                                    global.db.users[room.penantang].balance += room.hadiah;
                                    global.db.users[room.penantang].game.tictactoe += 1;
                                    delete anya.tictactoe[m.sender];
                                } else if (KeisiSemua(anu)) {
                                    await anya.reply(m.chat, `Hasil Seri!

@${room.penantang.split('@')[0]} = ❌
@${room.ditantang.split('@')[0]} = ⭕

${displayBoard(anu)}`, null, {
                                        expiration: m.expiration
                                    })
                                    delete anya.tictactoe[m.sender];
                                } else {
                                    let key = await anya.reply(m.chat, `@${room.penantang.split('@')[0]} telah mengisi

@${room.penantang.split('@')[0]} = ❌
@${room.ditantang.split('@')[0]} = ⭕

${displayBoard(anu)}

Giliran @${room.ditantang.split('@')[0]}`, m, {
                                        expiration: m.expiration
                                    })
                                    room.keyId.push(key.key);
                                    room.status = false;
                                    if (room.status == false) {
                                        await delay(2000) // slight delay for bot's turn
                                        await botTurn(m, anya)
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (error) {
                console.log(error)
                anya.reply(m.chat, error.message, m, {
                    expiration: m.expiration
                })
            }
        }
    },
    location: 'plugins/games/ttt-bot.js'
}

function getWinningMove(board, player) {
    const winPatterns = [
        [0, 1, 2],
        [3, 4, 5],
        [6, 7, 8], // rows
        [0, 3, 6],
        [1, 4, 7],
        [2, 5, 8], // cols
        [0, 4, 8],
        [2, 4, 6] // diagonals
    ];

    for (const pattern of winPatterns) {
        let count = 0;
        let emptyIndex = -1;
        for (const index of pattern) {
            if (board[index] === player) {
                count++;
            } else if (board[index] !== '❌' && board[index] !== '⭕') {
                emptyIndex = index;
            }
        }
        if (count === 2 && emptyIndex !== -1) {
            return emptyIndex;
        }
    }
    return -1;
}

function displayBoard(board) {
    let space = '    ';
    return `${space + board[0] + board[1] + board[2]}\n${space + board[3] + board[4] + board[5]}\n${space + board[6] + board[7] + board[8]}`;
}

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}