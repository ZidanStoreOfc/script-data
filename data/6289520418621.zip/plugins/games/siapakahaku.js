const similarity = require('similarity');
const gamesUrl = 'https://raw.githubusercontent.com/ZidanStoreOfc/Database/main/games/siapakahaku.json';
const sensitive = 0.75;
let alreadyAnswered = new Set();

exports.run = {
    usage: ['siapakahaku'],
    hidden: ['sa'],
    category: 'games',
    async: async (m, {
        func,
        anya,
        setting,
        users
    }) => {
        anya.siapakahaku = anya.siapakahaku || {};
        if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
        if (m.chat in anya.siapakahaku) return anya.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', anya.siapakahaku[m.chat].msg, {
            expiration: m.expiration
        });
        let data = await fetch(gamesUrl).then(response => response.json());
        let {
            soal,
            jawaban
        } = data.result.random();
        let hadiah = func.hadiah(setting.hadiah);
        let id = Date.now();
        alreadyAnswered.clear();
        let caption = `乂 *GAMES SIAPAKAH AKU*\n\n${func.texted('monospace', soal)}\n${users.premium ? '\nPetunjuk: ' + func.createClue(jawaban) : ''}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`
        let msg = await anya.reply(m.chat, caption, m, {
            expiration: m.expiration
        });
        anya.siapakahaku[m.chat] = {
            id: id,
            soal: soal,
            jawaban: jawaban.toLowerCase(),
            hadiah: hadiah,
            nextQuestion: 1,
            timeout: setTimeout(async function() {
                let gameData = anya.siapakahaku[m.chat];
                if (gameData.id == id) {
                    anya.reply(m.chat, `Waktu habis!\n\nJawabannya adalah: ${func.texted('monospace', jawaban)}`, gameData.msg, {
                        expiration: m.expiration
                    }).then(async () => {
                        if (gameData.msg) {
                            await func.delay(1500).then(async () => await anya.sendMessage(m.chat, {
                                delete: gameData.msg.key
                            }))
                        }
                    })
                    delete anya.siapakahaku[m.chat];
                }
            }, setting.gamewaktu * 1000),
            msg: msg ? {
                key: msg.key,
                message: msg.message
            } : null
        }
    },
    main: async (m, {
        func,
        anya,
        setting,
        users
    }) => {
        // Games Siapakah Aku By ZidanDev
        anya.siapakahaku = anya.siapakahaku || {};
        if ((m.chat in anya.siapakahaku) && !m.fromMe && !m.isPrefix) {
            let gameData = anya.siapakahaku[m.chat];
            if (similarity(gameData.jawaban, m.budy.toLowerCase()) >= sensitive) {
                if (alreadyAnswered.has(gameData.jawaban)) return anya.sendReact(m.chat, '🥴', m.key);
                alreadyAnswered.add(gameData.jawaban);
                console.log(Array.from(alreadyAnswered));
                // await anya.sendReact(m.chat, '✅', m.key)
                users.balance += gameData.hadiah;
                users.game.siapakahaku++;
                gameData.nextQuestion++;
                if (gameData.timeout) clearTimeout(gameData.timeout);
                let key;
                if (users.limit < 1) {
                    let price = setting.limit.price;
                    if (users.balance > price) {
                        users.balance -= price;
                        key = await anya.reply(m.chat, `Sistem otomatis mengambil \`${price} balance\` kamu sebagai pengganti limit.`, m, {
                            expiration: m.expiration
                        })
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    } else {
                        delete anya.susunkata[m.chat];
                        return await anya.reply(m.chat, 'Soal dihentikan karena limit & balance kamu sudah habis.', m, {
                            expiration: m.expiration
                        })
                    }
                } else {
                    users.limit -= 1;
                    /*if (gameData.msg) await anya.sendMessage(m.chat, {
                        delete: gameData.msg.key
                    })
                    await new Promise(resolve => setTimeout(resolve, 1500));*/
                }
                    let data = await fetch(gamesUrl).then(response => response.json());
                    let result = data.result.random();
                    let hadiah = func.hadiah(setting.hadiah);
                    let id = Date.now();
                    alreadyAnswered.clear();
                    let caption = `*LANJUT SOAL KE-${gameData.nextQuestion}*\n\n${func.texted('monospace', result.soal)}\n${users.premium ? '\nPetunjuk: ' + func.createClue(result.jawaban) : ''}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`
                    let msg = await anya.reply(m.chat, caption, m, {
                        /*...(key ? {
                            edit: key
                        } : {}),*/
                        expiration: m.expiration
                    });
                    Object.assign(gameData, {
                        id: id,
                        soal: result.soal,
                        jawaban: result.jawaban.toLowerCase(),
                        hadiah: hadiah,
                        timeout: setTimeout(function() {
                            if (gameData.id == id) {
                                anya.reply(m.chat, `Waktu habis!\n\nJawabannya adalah: ${func.texted('monospace', result.jawaban)}`, gameData.msg, {
                                    expiration: m.expiration
                                }).then(async () => {
                                    if (gameData.msg) {
                                        await func.delay(1500).then(async () => await anya.sendMessage(m.chat, {
                                            delete: gameData.msg.key
                                        }))
                                    }
                                })
                                delete anya.siapakahaku[m.chat];
                            }
                        }, setting.gamewaktu * 1000),
                        msg: msg ? {
                            key: msg.key,
                            message: msg.message
                        } : null
                    })
                    if (anya.siapakahaku[m.chat]) return false;
            } else if (/conversation|extendedTextMessage/.test(m.mtype) && setting.incorrect) {
                await anya.sendReact(m.chat, '❌', m.key)
            }
        }
    },
    location: 'plugins/games/siapakahaku.js'
}