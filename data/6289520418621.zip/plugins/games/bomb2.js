exports.run = {
usage: ['bomb2'],
hidden: ['tebakbom2'],
use: 'enter number',
category: 'games',
async: async (m, { func, anya }) => {
if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
anya.bomb2 = anya.bomb2 ? anya.bomb2 : {};
let id = m.sender,
timeout = 180000;
if (id in anya.bomb2) return anya.reply(m.chat, '*^ sesi ini belum selesai!*', anya.bomb2[id].msg);
const bom = ['💥', '✅', '✅', '✅', '✅', '✅', '✅', '✅', '✅'].sort(() => Math.random() - 0.5);
const number = ['1️⃣', '2️⃣', '3️⃣', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣'];
const array = bom.map((v, i) => ({
emot: v,
number: number[i],
position: i + 1,
state: false
}));
let txt = `乂  *B O M B*\n\nKirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :\n\n`;
for (let i = 0; i < array.length; i += 3) txt += array.slice(i, i + 3).map(v => v.state ? v.emot : v.number).join('') + '\n';
txt += `\nTimeout : *${((timeout / 1000) / 60)} menit*\nApabila mendapat kotak yang berisi bom maka point akan di kurangi.`;
let msg = await anya.reply(m.chat, txt, m);

let v;
anya.bomb2[id] = {
msg: msg,
array: array,
time: setTimeout(() => {
v = array.find(v => v.emot == '💥');
if (anya.bomb2[id]) anya.reply(m.chat, `*Waktu habis!*, Bom berada di kotak nomor ${v.number}.`, anya.bomb2[id].msg);
delete anya.bomb2[id];
}, timeout)
};

},
main: async (m, { func, anya, setting }) => {
try {
let id = m.sender;
let timeout = 180000;
let hadiah = func.hadiah(setting.hadiah);
let users = global.db.users[m.sender];
anya.bomb2 = anya.bomb2 ? anya.bomb2 : {};

let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.budy);
if (anya.bomb2[id] && isSurrender) {
await anya.reply(m.chat, 'Menyerah', m);
clearTimeout(anya.bomb2[id].time);
delete anya.bomb2[id];
}

if ((id in anya.bomb2) && !isNaN(m.budy)) {
let json = anya.bomb2[id].array.find(v => v.position == m.budy);
if (!json) return anya.reply(m.chat, `Untuk membuka kotak Kirim angka 1 - 9`, m);

if (json.emot == '💥') {
json.state = true;
let bomb = anya.bomb2[id].array;
let txt = `乂  *B O M B*\n\n`;
txt += bomb.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n';
txt += bomb.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n';
txt += bomb.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n';
txt += `Timeout : *${((timeout / 1000) / 60)} menit*\n`;
txt += `*Permainan selesai!*, kotak berisi bom terbuka: (- *$${func.formatNumber(hadiah)}* money)`;

anya.reply(m.chat, txt.trim(), m).then(() => {
users.money < hadiah ? users.money = 0 : users.money -= hadiah;
clearTimeout(anya.bomb2[id].time);
delete anya.bomb2[id];
});
} else if (json.state) {
return anya.reply(m.chat, `Kotak ${json.number} sudah di buka silahkan pilih kotak yang lain.`, m);
} else {
json.state = true;
let changes = anya.bomb2[id].array;
let open = changes.filter(v => v.state && v.emot != '💥').length;

if (open >= 8) {
let txt = `乂  *B O M B*\n\n`;
txt += `Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :\n\n`;
txt += changes.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n';
txt += changes.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n';
txt += changes.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n';
txt += `Timeout : *${((timeout / 1000) / 60)} menit*\n`;
txt += `*Permainan selesai!* kotak berisi bom tidak terbuka: (+ *$${func.formatNumber(hadiah)}* money)`;
anya.reply(m.chat, txt.trim(), m).then(() => {
users.money += hadiah;
clearTimeout(anya.bomb2[id].time);
delete anya.bomb2[id];
});
} else {
let txt = `乂  *B O M B*\n\n`;
txt += `Kirim angka *1* - *9* untuk membuka *9* kotak nomor di bawah ini :\n\n`;
txt += changes.slice(0, 3).map(v => v.state ? v.emot : v.number).join('') + '\n';
txt += changes.slice(3, 6).map(v => v.state ? v.emot : v.number).join('') + '\n';
txt += changes.slice(6).map(v => v.state ? v.emot : v.number).join('') + '\n\n';
txt += `Timeout : *${((timeout / 1000) / 60)} menit*\n`;
txt += `Kotak berisi bom tidak terbuka : (+ *$${func.formatNumber(hadiah)}* money)`;
anya.reply(m.chat, txt.trim(), m).then(() => {
users.money += hadiah;
});
}
}
}
} catch (e) {
return anya.reply(m.chat, func.jsonFormat(e), m);
}
return !0;
}
}