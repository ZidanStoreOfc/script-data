const fetch = require('node-fetch');
const util = require('util');
const gamesUrl = 'https://raw.githubusercontent.com/ZidanStoreOfc/Database/main/games/kbbi.json';
const random = (list) => list[Math.floor(Math.random() * list.length)];

exports.run = {
usage: ['sambungkata'],
hidden: ['sk'],
use: 'options',
category: 'games',
async: async (m, {
func,
anya
}) => {
anya.skata2 = anya.skata2 ? anya.skata2 : {};
try {
const help = `*Sambung Kata Help*

1. Permainan harus dimainkan minimal 2 pemain
2. Saat permainan dimulai bot akan memberikan 1 kata
3. Kemudian, player harus membuat 1 kata dari suku kata terakhir dari kata sebelumnya
4. Contohnya: *Teknologi*, maka jawabannya *Gigih* atau *Girang*
5. Permainan akan terus diulang sampai ada yang kalah
6. Tiap pemain diberi waktu 30 detik untuk menjawab
7. Tiap pemain diberi 3 kesempatan untuk menjawab
8. Kata yang dijawab harus terdaftar dalam KBBI dan belum pernah dijawab
9. Apabila benar, akan diberikan balance sesuai jumlah huruf kata yang dijawab dikali 100
10. Apabila 3 kesempatan atau waktu telah habis, player akan diberikan minus(-) balance dari kalkulasi jumlah balance yang telah diberikan pada permainan.`.trim();
const id = m.chat;
const caption = `Kirim perintah :

- ${m.cmd} help
- ${m.cmd} join
- ${m.cmd} start
- ${m.cmd} exit
- ${m.cmd} delete
- ${m.cmd} player

Minimal 2 orang`.trim();

if (!(id in anya.skata2)) {
let kata = await genKata();
anya.skata2[id] = {
owner: m.sender,
player: [],
status: 'wait',
basi: [],
point: 0,
chance: 0,
index: 0,
current: '',
kata,
genKata,
cekKata,
filter,
chat: false,
timer: 20,
timeout: false
};
};
let value = (m.args[0] || '').toLowerCase();
if (!value && anya.skata2[id]) anya.skata2[id].chat = await anya.reply(id, caption, m, {
expiration: m.expiration
});
let room = anya.skata2[id];
switch (value) {
case 'help':
case 'rules':
case 'menu':
anya.reply(id, help, m, {
expiration: m.expiration
})
break;
case 'join':
if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit);
if (room.player.find(v => v.id == m.sender)) return m.reply('kamu sudah berada didalam list');
anya.skata2[id].player.push({
id: m.sender,
chance: 3
});
m.reply(`Berhasil masuk\nJumlah pemain: ${room.player.length}`.trim());
break;
case 'exit':
if (!room) return m.reply('Tidak ada sesi permainan');
if (!room.player.find(v => v.id == m.sender)) return m.reply('Kamu tidak dalam sesi permainan.');
if (room.status == 'play') return m.reply('Permainan sudah dimulai, kamu tidak bisa keluar');
let index = room.player.findIndex(x => x.id === m.sender)
room.player.splice(index, 1);
m.reply(`@${m.sender.split('@')[0]} keluar dari permainan.`);
break;
case 'delete':
if (!room) return m.reply('Tidak ada sesi permainan.');
if (room.owner !== m.sender && room.status == 'play') return m.reply(`Hanya @${room.owner.split('@')[0]} yang dapat menghapus sesi permainan ini.`);
anya.reply(id, 'Sesi permainan berhasil dihapus.', m, {
expiration: m.expiration
})
if (room.timeout) clearTimeout(room.timeout);
delete anya.skata2[id];
break;
case 'player':
if (!room) return m.reply('Tidak ada sesi permainan.');
if (!room.player.find(v => v.id == m.sender)) return m.reply('Kamu tidak dalam sesi permainan.');
if (room.player.length == 0) return m.reply('Sesi permainan belum memiliki player.');
var text = '*S A M B U N G - K A T A*\n\nLIST PLAYER:\n';
text += room.player.map((item, index) => `${index + 1}. @${item.id.split('@')[0]}`).join('\n')
anya.reply(id, text.trim(), m, {
expiration: m.expiration
});
break;
case 'start':
if (room.player.length < 2) return m.reply('Minimal 2 player.');
if (room.status !== 'wait') {
anya.reply(id, 'Room sambungkata ini belum selesai', room.chat, {
expiration: m.expiration
});
return false;
};
room.current = room.player[0].id;
room.index = 0;
room.status = 'play';
for (let i of room.player) {
let user = global.db.users[i.id];
if (!user.game) user.game = {};
if (!user.game.hasOwnProperty('sambungkata')) user.game.sambungkata = 0;
}
var text = `Giliran @${room.current.split('@')[0]}
Kata : *${room.kata}*
Waktu: ${room.timer}s
Kesempatan: ${room.player[room.index].chance}
		
Carilah kata yang berawalan *${room.filter(room.kata)}*`;
room.chat = await anya.reply(id, text.trim(), null, {
mentions: [room.current],
expiration: m.expiration
});
room.point = room.kata.length * 100;
const timeout = () => setTimeout(async () => {
anya.reply(id, `Waktu habis @${room.current.split('@')[0]} tereliminasi.\nHadiah: -${room.point} balance`, room.chat, {
mentions: [room.current],
expiration: m.expiration
});
global.db.users[room.current].balance -= room.point;
let index = room.index
room.player.splice(room.index, 1);
room.current = room.player.length > 1 ? room.player[index]?.id : room.player[0]?.id;
console.log('room skata1:', room);
if (room.player.length == 1 && room.status == 'play') {
global.db.users[room.current].game.sambungkata += 1
global.db.users[room.current].balance += room.point;
anya.reply(m.chat, `@${room.current.split('@')[0]} Menang\nHadiah: $${room.point} balance`, room.chat, {
mentions: [room.current],
expiration: m.expiration
})
delete anya.skata2[id];
return false;
}
room.kata = await room.genKata();
let caption = `Lanjut Giliran @${room.current.split('@')[0]}
Kata: *${room.kata}*
Waktu: ${room.timer}s
Kesempatan: ${room.player[room.index].chance}

Carilah kata yang berawalan *${room.filter(room.kata)}*`.trim();
room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});
room.point = room.kata.length * 100;
room.timeout = timeout();
}, room.timer * 1000);
room.timeout = timeout();
return room;
break;
};
} catch (error) {
console.log(error);
anya.reply(m.chat, error.message, m, {
expiration: m.expiration
})
}
},
main: async (m, { func, anya }) => { // main adalah function response
anya.skata2 = anya.skata2 ? anya.skata2 : {};
if ((m.chat in anya.skata2) && m.budy) {
const id = m.chat;
if (!anya.skata2[id]) return;
let room = anya.skata2[id];
if (room.status !== 'play' || room.current !== m.sender) return;
let answer = (m.budy.toLowerCase().split(' ')[0]).trim().replace(/[^a-z]/gi, '');
let check = await room.cekKata(answer);
let bonus = answer.length * 100;
if (answer.startsWith(room.filter(room.kata))) {
if ((room.filter(room.kata)) == answer) {
let caption = 'Jawaban kamu sama dengan soal\n';
if (room.player[room.index].chance <= 1 || room.player[room.index].chance == 0) {
global.db.users[room.curret].balance -= bonus;
// Setelah pemain tereliminasi
if (room.player.length > 1) {
// Menghapus pemain yang tereliminasi
room.player.splice(room.index, 1);

// Mengatur giliran pemain berikutnya
if (room.index >= room.player.length) {
room.index = 0; // Jika index lebih besar dari panjang pemain, reset ke 0
}
room.current = room.player[room.index].id;

// Menghasilkan kata baru untuk pemain berikutnya
room.kata = await room.genKata();

caption = `Lanjut Giliran @${room.current.split('@')[0]}
Kata: *${room.kata}*
Waktu: ${room.timer}s
Kesempatan: ${room.player[room.index].chance}

Carilah kata yang berawalan *${room.filter(room.kata)}*`.trim();

room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});

const timeout = () => setTimeout(async () => {
anya.reply(id, `Waktu habis @${room.current.split('@')[0]} tereliminasi.\nHadiah: -${room.point} balance`, room.chat, {
mentions: [room.current],
expiration: m.expiration
});
global.db.users[room.current].balance -= room.point;
let index = room.index
room.player.splice(room.index, 1);
room.current = room.player.length > 1 ? room.player[index]?.id : room.player[0]?.id;
console.log('room skata1:', room);
if (room.player.length == 1 && room.status == 'play') {
global.db.users[room.current].game.sambungkata += 1
global.db.users[room.current].balance += room.point;
anya.reply(m.chat, `@${room.current.split('@')[0]} Menang\nHadiah: $${room.point} balance`, room.chat, {
mentions: [room.current],
expiration: m.expiration
})
delete anya.skata2[id];
return false;
}
room.kata = await room.genKata();
caption = `Lanjut Giliran @${room.current.split('@')[0]}
Kata: *${room.kata}*
Waktu: ${room.timer}s
Kesempatan: ${room.player[room.index].chance}

Carilah kata yang berawalan *${room.filter(room.kata)}*`.trim();
room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});
room.point = room.kata.length * 100;
room.timeout = timeout();
}, room.timer * 1000);
room.timeout = timeout();
} else if (room.player.length == 1) {
// Jika hanya ada satu pemain yang tersisa
room.current = room.player[0].id;
global.db.users[room.current].balance += room.kata.length * 100;
global.db.users[room.current].game.sambungkata += 1;

caption = `Pemenang: @${room.current.split('@')[0]}
Hadiah: ${room.kata.length * 100} balance
Game Berakhir!`.trim();

if (room.timeout) clearTimeout(room.timeout);
room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});
delete anya.skata2[id];
return !0;
}
};
room.player[room.index].chance -= 1;
return m.reply(caption + `Sisa kesempatan: ${room.player[room.index].chance}`);
} else if (room.basi.includes(answer)) {
let caption = `*${m.budy.toLowerCase()}* sudah pernah digunakan\n`;
if (room.player[room.index].chance <= 1 || room.player[room.index].chance == 0) {
global.db.users[room.current].balance -= bonus;
caption = caption + `@${room.current.split('@')[0]} tereliminasi.\nHadiah: -${bonus} balance`;
// Setelah pemain tereliminasi
if (room.player.length > 1) {
// Menghapus pemain yang tereliminasi
room.player.splice(room.index, 1);

// Mengatur giliran pemain berikutnya
if (room.index >= room.player.length) {
room.index = 0; // Jika index lebih besar dari panjang pemain, reset ke 0
}
room.current = room.player[room.index].id;

// Menghasilkan kata baru untuk pemain berikutnya
room.kata = await room.genKata();

caption = `Lanjut Giliran @${room.current.split('@')[0]}
Kata: *${room.kata}*
Waktu: ${room.timer}s
Kesempatan: ${room.player[room.index].chance}

Carilah kata yang berawalan *${room.filter(room.kata)}*`.trim();

room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});

const timeout = () => setTimeout(async () => {
anya.reply(id, `Waktu habis @${room.current.split('@')[0]} tereliminasi.\nHadiah: -${room.point} balance`, room.chat, {
mentions: [room.current],
expiration: m.expiration
});
global.db.users[room.current].balance -= room.point;
let index = room.index
room.player.splice(room.index, 1);
room.current = room.player.length > 1 ? room.player[index]?.id : room.player[0]?.id;
console.log('room skata1:', room);
if (room.player.length == 1 && room.status == 'play') {
global.db.users[room.current].game.sambungkata += 1
global.db.users[room.current].balance += room.point;
anya.reply(m.chat, `@${room.current.split('@')[0]} Menang\nHadiah: $${room.point} balance`, room.chat, {
mentions: [room.current],
expiration: m.expiration
})
delete anya.skata2[id];
return false;
}
room.kata = await room.genKata();
caption = `Lanjut Giliran @${room.current.split('@')[0]}
Kata: *${room.kata}*
Waktu: ${room.timer}s
Kesempatan: ${room.player[room.index].chance}

Carilah kata yang berawalan *${room.filter(room.kata)}*`.trim();
room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});
room.point = room.kata.length * 100;
room.timeout = timeout();
}, room.timer * 1000);
room.timeout = timeout();
} else if (room.player.length == 1) {
// Jika hanya ada satu pemain yang tersisa
room.current = room.player[0].id;
global.db.users[room.current].balance += room.kata.length * 100;
global.db.users[room.current].game.sambungkata += 1;

caption = `Pemenang: @${room.current.split('@')[0]}
Hadiah: ${room.kata.length * 100} balance
Game Berakhir!`.trim();

if (room.timeout) clearTimeout(room.timeout);
room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});
delete anya.skata2[id];
return !0;
}
};
room.player[room.index].chance -= 1;
return m.reply(`${caption}Sisa kesempatan: ${room.player[room.index].chance}`);
} else if (!check) {
let caption = `*${m.budy.toLowerCase()}* tidak terdaftar di KBBI\n`;
if (room.player[room.index].chance <= 1 || room.player[room.index].chance == 0) {
global.db.users[room.current].balance -= bonus;
// Setelah pemain tereliminasi
if (room.player.length > 1) {
// Menghapus pemain yang tereliminasi
room.player.splice(room.index, 1);

// Mengatur giliran pemain berikutnya
if (room.index >= room.player.length) {
room.index = 0; // Jika index lebih besar dari panjang pemain, reset ke 0
}
room.current = room.player[room.index].id;

// Menghasilkan kata baru untuk pemain berikutnya
room.kata = await room.genKata();

caption = `Lanjut Giliran @${room.current.split('@')[0]}
Kata: *${room.kata}*
Waktu: ${room.timer}s
Kesempatan: ${room.player[room.index].chance}

Carilah kata yang berawalan *${room.filter(room.kata)}*`.trim();

room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});

const timeout = () => setTimeout(async () => {
anya.reply(id, `Waktu habis @${room.current.split('@')[0]} tereliminasi.\nHadiah: -${room.point} balance`, room.chat, {
mentions: [room.current],
expiration: m.expiration
});
global.db.users[room.current].balance -= room.point;
let index = room.index
room.player.splice(room.index, 1);
room.current = room.player.length > 1 ? room.player[index]?.id : room.player[0]?.id;
console.log('room skata1:', room);
if (room.player.length == 1 && room.status == 'play') {
global.db.users[room.current].game.sambungkata += 1
global.db.users[room.current].balance += room.point;
anya.reply(m.chat, `@${room.current.split('@')[0]} Menang\nHadiah: $${room.point} balance`, room.chat, {
mentions: [room.current],
expiration: m.expiration
})
delete anya.skata2[id];
return false;
}
room.kata = await room.genKata();
caption = `Lanjut Giliran @${room.current.split('@')[0]}
Kata: *${room.kata}*
Waktu: ${room.timer}s
Kesempatan: ${room.player[room.index].chance}

Carilah kata yang berawalan *${room.filter(room.kata)}*`.trim();
room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});
room.point = room.kata.length * 100;
room.timeout = timeout();
}, room.timer * 1000);
room.timeout = timeout();
} else if (room.player.length == 1) {
// Jika hanya ada satu pemain yang tersisa
room.current = room.player[0].id;
global.db.users[room.current].balance += room.kata.length * 100;
global.db.users[room.current].game.sambungkata += 1;

caption = `Pemenang: @${room.current.split('@')[0]}
Hadiah: ${room.kata.length * 100} balance
Game Berakhir!`.trim();

if (room.timeout) clearTimeout(room.timeout);
room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});
delete anya.skata2[id];
return !0;
}
};
room.player[room.index].chance -= 1;
return m.reply(`${caption}Sisa kesempatan: ${room.player[room.index].chance}`);
};
clearTimeout(room.timeout);
global.db.users[room.current].balance += bonus;
global.db.users[room.current].game.sambungkata += 1;
room.basi.push(answer);
let index = room.index;
console.log('INDEX CURRENT: ', index);
console.log('OLD CURRENT: ', room.current);
room.current = room.player[index + 1]?.id
console.log('NEW CURRENT: ', room.current)
if (room.current) room.index = index + 1;
if ((index + 1) >= room.player.length) {
anya.logger.warn(`\ncurrent: ${room.index + 1}\nplayer length: ${room.player.length}\nPlayer: ${util.format(room.player)}`);
room.current = room.player[0].id;
room.index = 0;
};
room.kata = answer;
let caption = `*Jawaban benar!*
Hadiah: ${bonus} balance
Giliran: @${room.current.split('@')[0]}
Kata: *${room.kata}*
Waktu: ${room.timer}s
Kesempatan: ${room.player[room.index].chance}

Carilah kata yang berawalan *${room.filter(room.kata)}*`.trim()
room.chat = await m.reply(caption, null, {
mentions: [room.current],
expiration: m.expiration
});
const timeout = () => setTimeout(async () => {
anya.reply(id, `Waktu habis @${room.current.split('@')[0]} tereliminasi.\nHadiah: -${room.point} balance`, room.chat, {
mentions: [room.current],
expiration: m.expiration
});
global.db.users[room.current].balance -= room.point;
let index = room.index
room.player.splice(room.index, 1);
room.current = room.player.length > 1 ? room.player[index]?.id : room.player[0]?.id;
console.log('room skata1:', room);
if (room.player.length == 1 && room.status == 'play') {
global.db.users[room.current].game.sambungkata += 1
global.db.users[room.current].balance += room.point;
anya.reply(m.chat, `@${room.current.split('@')[0]} Menang\nHadiah: $${room.point} balance`, room.chat, {
mentions: [room.current],
expiration: m.expiration
})
delete anya.skata2[id];
return false;
}
room.kata = await room.genKata();
caption = `Lanjut Giliran @${room.current.split('@')[0]}
Kata: *${room.kata}*
Waktu: ${room.timer}s
Kesempatan: ${room.player[room.index].chance}

Carilah kata yang berawalan *${room.filter(room.kata)}*`.trim();
room.chat = await anya.reply(m.chat, caption, null, {
mentions: [room.current],
expiration: m.expiration
});
room.point = room.kata.length * 100;
room.timeout = timeout();
}, room.timer * 1000);
room.timeout = timeout();
return room;
}
}
},
group: true,
location: 'plugins/games/sambungkata.js'
}

// eslint-disable-next-line no-unused-vars
function rwd(min, max) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
};


async function genKata() {
return new Promise(async (resolve) => {
const kbbi = await fetch(gamesUrl).then(response => response.json())
const huruf = random(['a', 'b', 'c', 'd', 'e', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'p', 'r', 's', 't', 'u', 'w']);
const data = kbbi.filter(v => v.startsWith(huruf));
let kata = random(data);
while (kata.length < 3) {
kata = random(data);
};
resolve(kata);
});
};

async function cekKata(kata = '') {
return new Promise(async (resolve) => {
const kbbi = await fetch(gamesUrl).then(response => response.json())
if (!kbbi.find(v => v == kata.toLowerCase())) {
resolve(false);
} else {
resolve(true);
};
});
};

function filter(text) {
const mati = ['q', 'w', 'r', 't', 'y', 'p', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm'];
if (/[aiueo][aiueo]([qwrtypsdfghjklzxcvbnm])?$/i.test(text)) return text.substring(text.length - 1);
const res = Array.from(text).filter(v => mati.includes(v));
let resu = res[res.length - 1];
for (let huruf of mati) {
if (text.endsWith(huruf)) {
resu = res[res.length - 2];
};
};
let misah = text.split(resu);
return resu + misah[misah.length - 1];
};