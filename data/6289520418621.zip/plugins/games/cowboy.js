exports.run = {
usage: ['cowboy'],
hidden: ['coboy'],
use: 'options',
category: 'games',
async: async (m, { func, anya }) => {
anya.cowboy = anya.cowboy ? anya.cowboy : {
musuh: [],
shoot: []
}
if (/left/i.test(m.text)) {
let left = [
["🤠", "・", "・", "・", "・"],
["・", "🤠", "・", "・", "・"],
["・", "・", "🤠", "・", "・"],
["・", "・", "・", "🤠", "・"],
["・", "・", "・", "・", "🤠"]
]
if (anya.cowboy.shoot.indexOf("🤠") == 0) {
anya.cowboy.shoot = left[0]
} else if (anya.cowboy.shoot.indexOf("🤠") == 1) {
anya.cowboy.shoot = left[0]
} else if (anya.cowboy.shoot.indexOf("🤠") == 2) {
anya.cowboy.shoot = left[1]
} else if (anya.cowboy.shoot.indexOf("🤠") == 3) {
anya.cowboy.shoot = left[2]
} else if (anya.cowboy.shoot.indexOf("🤠") == 4) {
anya.cowboy.shoot = left[3]
}
let teks = `🤠 Cowboy Chasing Criminals 🥷\n\n`
teks += `Your territory:\n${anya.cowboy.shoot.join(" ")}\n`
teks += `Criminals terriroty:\n${anya.cowboy.musuh.join(" ")}\n`
teks += `Example : ${m.cmd} right or ${m.cmd} left for move to right/left and ${m.cmd} shoot to shoot`
if (anya.cowboy.musuh.indexOf("🥷") === anya.cowboy.shoot.indexOf("🤠")) return m.reply(teks)
return m.reply(teks)
} else if (/right/i.test(m.text)) {
let right = [
["🤠", "・", "・", "・", "・"],
["・", "🤠", "・", "・", "・"],
["・", "・", "🤠", "・", "・"],
["・", "・", "・", "🤠", "・"],
["・", "・", "・", "・", "🤠"]
]
if (anya.cowboy.shoot.indexOf("🤠") == 0) {
anya.cowboy.shoot = right[1]
} else if (anya.cowboy.shoot.indexOf("🤠") == 1) {
anya.cowboy.shoot = right[2]
} else if (anya.cowboy.shoot.indexOf("🤠") == 2) {
anya.cowboy.shoot = right[3]
} else if (anya.cowboy.shoot.indexOf("🤠") == 3) {
anya.cowboy.shoot = right[4]
} else if (anya.cowboy.shoot.indexOf("🤠") == 4) {
anya.cowboy.shoot = right[4]
}
let teks = `🤠 Cowboy Chacing Criminals 🥷\n\n`
teks += `Your territory:\n${anya.cowboy.shoot.join(" ")}\n`
teks += `Criminals terriroty:\n${anya.cowboy.musuh.join(" ")}\n`
teks += `Example : ${m.cmd} right or ${m.cmd} left for move to right/left and ${m.cmd} shoot to shoot`
if (anya.cowboy.musuh.indexOf("🥷") === anya.cowboy.shoot.indexOf("🤠")) return m.reply(teks)
return m.reply(teks)
} else if (/shoot/i.test(m.text)) {
if (anya.cowboy.shoot.indexOf("🤠") == anya.cowboy.musuh.indexOf("🥷")) {
anya.cowboy = {}
m.reply(`🎉 Congratulations! you succeeded in chasing the criminals! 🎉`)
}
} else {
let randMusuh = [
["🥷", "・", "・", "・", "・"],
["・", "🥷", "・", "・", "・"],
["・", "・", "🥷", "・", "・"],
["・", "・", "・", "🥷", "・"],
["・", "・", "・", "・", "🥷"]
]
let randAku = [
["🤠", "・", "・", "・", "・"],
["・", "🤠", "・", "・", "・"],
["・", "・", "🤠", "・", "・"],
["・", "・", "・", "🤠", "・"],
["・", "・", "・", "・", "🤠"]
]
let musuh = func.pickRandom(randMusuh)
let aku = func.pickRandom(randAku)
anya.cowboy.musuh = musuh
anya.cowboy.shoot = aku
let teks = `🤠 Cowboy Chasing Criminals 🥷\n\n`
teks += `Your territory:\n${anya.cowboy.shoot.join(" ")}\n`
teks += `Criminals terriroty:\n${anya.cowboy.musuh.join(" ")}\n`
teks += `Example : ${m.cmd} right or ${m.cmd} left for move to right/left and ${m.cmd} shoot to shoot`
if (anya.cowboy.musuh.indexOf("🥷") === anya.cowboy.shoot.indexOf("🤠")) return m.reply(teks)
return m.reply(teks)
}
},
limit: true
}