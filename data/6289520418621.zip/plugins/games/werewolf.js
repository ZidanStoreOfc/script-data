const toMs = require('ms')
const jimp = require('jimp')
const {
    getAggregateVotesInPollMessage,
    normalizeMessageContent,
    getKeyAuthor,
    decryptPollVote,
    jidNormalizedUser
} = require('@whiskeysockets/baileys');

const findObject = (obj, key, value) => {
    const result = [];
    const recursiveSearch = (obj) => {
        if (!obj || typeof obj !== "object") return;
        if (obj[key] === value) result.push(obj);
        Object.values(obj).forEach(recursiveSearch);
    };
    recursiveSearch(obj);
    return result;
};

// Sesi
const sesi = (from, wwdata) => wwdata[from] || false;

// Memastikan player tidak dalam sesi game apapun
const playerOnGame = (sender, wwdata) => findObject(wwdata, "id", sender).length > 0;

// cek apakah player sudah dalam room
const playerOnRoom = (sender, from, wwdata) => findObject(wwdata, "id", sender).some(player => player.sesi === from);

// get data player
const dataPlayer = (sender, wwdata) => findObject(wwdata, "id", sender).find(player => player.id === sender) || false;

// get data player by id
const dataPlayerById = (id, wwdata, from) => {
    const room = sesi(from, wwdata);
    return room ? room.player.find(player => player.number === id) : false
}

// voting
const alreadyVote = (from, sender, wwdata) => {
    const room = sesi(from, wwdata);
    if (!room) return;
    const senderPlayer = dataPlayer(sender, wwdata)
    // if (!senderPlayer) return
    // const targetPlayer = dataPlayerById(id, wwdata, from)
    // if (!targetPlayer) return
    if (senderPlayer && !senderPlayer.isvote) senderPlayer.isvote = true;
    // targetPlayer.vote += 1;
};

exports.run = {
    usage: ['werewolf'],
    hidden: ['ww', 'w'],
    use: 'options',
    category: 'games',
    async: async (m, {
        func,
        anya,
        setting
    }) => {
        try {
            anya.werewolf = anya.werewolf || {};
            const werewolf = anya.werewolf;
            const werewolfData = werewolf[m.chat];
            const timeout = setting.gamewaktu;
            const time_vote = timeout / 2;
            const value = m.args && (m.args[0] || '').toLowerCase();
            const target = m.args && (m.args[1] || '').replace(/[^0-9]/g, '');

            // [ Thumbnail ]
            let thumb = "https://user-images.githubusercontent.com/72728486/235316834-f9f84ba0-8df3-4444-81d8-db5270995e6d.jpg";
            let thumb1 = "https://user-images.githubusercontent.com/72728486/235344562-4677d2ad-48ee-419d-883f-e0ca9ba1c7b8.jpg";
            let thumb2 = "https://user-images.githubusercontent.com/72728486/235344861-acdba7d1-8fce-41b8-adf6-337c818cda2b.jpg";
            let thumb3 = "https://user-images.githubusercontent.com/72728486/235316834-f9f84ba0-8df3-4444-81d8-db5270995e6d.jpg";
            let thumb4 = "https://user-images.githubusercontent.com/72728486/235354619-6ad1cabd-216c-4c7c-b7c2-3a564836653a.jpg";
            let thumb5 = "https://user-images.githubusercontent.com/72728486/235365156-cfab66ce-38b2-4bc7-90d7-7756fc320e06.jpg";
            let thumb6 = "https://user-images.githubusercontent.com/72728486/235365148-35b8def7-c1a2-451d-a2f2-6b6a911b37db.jpg";

            var textnya;
            var idnya;
            var room;

            const resize = async (image, width, height) => {
                const read = await jimp.read(image);
                return read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
            };

            const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

            const emoji_role = (role) => {
                const roles = {
                    warga: "👩🏻‍🦳",
                    seer: "👳🏻‍♀️",
                    guardian: "👼🏻",
                    sorcerer: "🔮",
                    werewolf: "🐺"
                };
                return roles[role] || "";
            };

            // keluar game
            const playerExit = (from, id, wwdata) => {
                const room = sesi(from, wwdata);
                if (!room) return;
                const indexPlayer = room.player.findIndex(i => i.id === id);
                if (indexPlayer > -1) {
                    room.player.splice(indexPlayer, 1);
                    room.player.forEach((player, index) => player.number = index + 1);
                }
            };

            // get player id
            const getPlayerById = (from, id, wwdata) => {
                const room = sesi(from, wwdata);
                if (!room) return false;
                const indexPlayer = room.player.findIndex(i => i.number === id);
                if (indexPlayer === -1) return false;
                return {
                    index: indexPlayer,
                    sesi: room.player[indexPlayer].sesi,
                    db: room.player[indexPlayer],
                };
            };

            // get player id 2
            const getPlayerById2 = (sender, id, wwdata) => {
                let result = findObject(wwdata, "id", sender);
                if (result.length > 0 && result[0].id === sender) {
                    let from = result[0].sesi;
                    room = sesi(from, wwdata);
                    if (!room) return false;
                    const indexPlayer = room.player.findIndex(i => i.number === id);
                    if (indexPlayer === -1) return false;
                    return {
                        index: indexPlayer,
                        sesi: room.player[indexPlayer].sesi,
                        db: room.player[indexPlayer],
                    };
                }
            };

            // werewolf kill
            const killWerewolf = (sender, id, wwdata) => {
                let player = dataPlayer(sender, wwdata)
                if (!player) return false;
                let targetPlayer = dataPlayerById(id, wwdata, player.sesi)
                if (!targetPlayer) return false
                let room = sesi(player.sesi, wwdata)
                if (targetPlayer.effect.includes("guardian")) {
                    room.guardian.push(parseInt(id));
                    room.dead.push(parseInt(id));
                } else {
                    console.log(room.player[id]);
                    room.dead.push(parseInt(id));
                }
            };

            // seer dreamy
            const dreamySeer = (sender, id, wwdata) => {
                let player = dataPlayer(sender, wwdata)
                if (!player) return false;
                let targetPlayer = dataPlayerById(id, wwdata, player.sesi)
                if (!targetPlayer) return false

                let room = sesi(player.sesi, wwdata)

                if (targetPlayer.role === "werewolf") {
                    room.seer = true;
                }
                return targetPlayer.role;
            };

            // seer dreamy
            const sorcerer = (sender, id, wwdata) => {
                let player = dataPlayer(sender, wwdata)
                if (!player) return false;
                let targetPlayer = dataPlayerById(id, wwdata, player.sesi)
                if (!targetPlayer) return false
                return targetPlayer.role;
            };

            // get data dead player
            const getDeadPlayer = (sender, id, wwdata) => {
                let player = dataPlayer(sender, wwdata)
                if (!player) return false;

                let room = sesi(player.sesi, wwdata)
                return room.dead.some(v => v == id);
            };

            // guardian protect
            const protectGuardian = (sender, id, wwdata) => {
                let player = dataPlayer(sender, wwdata)
                if (!player) return false;
                let targetPlayer = dataPlayerById(id, wwdata, player.sesi)
                if (!targetPlayer) return false

                targetPlayer.effect.push("guardian");
            };

            // pengacakan role
            const roleShuffle = (array) => {
                for (let i = array.length - 1; i > 0; i--) {
                    const j = Math.floor(Math.random() * (i + 1));
                    [array[i], array[j]] = [array[j], array[i]];
                }
                return array;
            };

            // memberikan role ke player
            const roleChanger = (from, id, role, wwdata) => {
                const room = sesi(from, wwdata);
                if (!room) return;
                const index = room.player.findIndex(i => i.id === id);
                if (index > -1) room.player[index].role = role;
            };

            // memberikan peran ke semua player
            const roleAmount = (playerCount) => { // Simplified role assignment based on player count
                if (playerCount < 4 || playerCount > 15) {
                    return false; // Invalid player count
                } else if (playerCount == 4) {
                    return {
                        werewolf: 1,
                        seer: 1,
                        guardian: 1,
                        warga: 1,
                        sorcerer: 0,
                    };
                } else if (playerCount == 5) {
                    return {
                        werewolf: 1,
                        seer: 1,
                        guardian: 1,
                        warga: 3,
                        sorcerer: 0,
                    };
                } else if (playerCount == 6) {
                    return {
                        werewolf: 2,
                        seer: 1,
                        guardian: 1,
                        warga: 2,
                        sorcerer: 0,
                    };
                } else if (playerCount == 7) {
                    return {
                        werewolf: 2,
                        seer: 1,
                        guardian: 1,
                        warga: 3,
                        sorcerer: 0,
                    };
                } else if (playerCount == 8) {
                    return {
                        werewolf: 2,
                        seer: 1,
                        guardian: 1,
                        warga: 4,
                        sorcerer: 0,
                    };
                } else if (playerCount == 9) {
                    return {
                        werewolf: 2,
                        seer: 1,
                        guardian: 1,
                        warga: 4,
                        sorcerer: 1,
                    };
                } else if (playerCount == 10) {
                    return {
                        werewolf: 2,
                        seer: 1,
                        guardian: 1,
                        warga: 5,
                        sorcerer: 1,
                    };
                } else if (playerCount == 11) {
                    return {
                        werewolf: 2,
                        seer: 1,
                        guardian: 2,
                        warga: 5,
                        sorcerer: 1,
                    };
                } else if (playerCount == 12) {
                    return {
                        werewolf: 2,
                        seer: 1,
                        guardian: 2,
                        warga: 6,
                        sorcerer: 1,
                    };
                } else if (playerCount == 13) {
                    return {
                        werewolf: 2,
                        seer: 1,
                        guardian: 1,
                        warga: 7,
                        sorcerer: 1,
                    };
                } else if (playerCount == 14) {
                    return {
                        werewolf: 2,
                        seer: 2,
                        guardian: 2,
                        warga: 7,
                        sorcerer: 1,
                    };
                } else if (playerCount == 15) {
                    return {
                        werewolf: 3,
                        seer: 2,
                        guardian: 3,
                        warga: 6,
                        sorcerer: 1,
                    };
                }
            };

            const roleGenerator = (from, wwdata) => {
                const room = sesi(from, wwdata);
                if (!room) return;

                const roles = roleAmount(room.player.length);
                if (!roles) return; // Handle invalid player count

                const assignRole = (roleName, count) => {
                    for (let i = 0; i < count; i++) {
                        const availablePlayers = room.player.filter(x => !x.role);
                        if (availablePlayers.length === 0) return;
                        const randomPlayer = roleShuffle(availablePlayers)[0];
                        roleChanger(from, randomPlayer.id, roleName, wwdata);
                    }
                };

                assignRole("werewolf", roles.werewolf);
                assignRole("seer", roles.seer);
                assignRole("guardian", roles.guardian);
                assignRole("warga", roles.warga);
                assignRole("sorcerer", roles.sorcerer);

                sortPlayer(from, wwdata);
            };

            // add cooldown
            const addTimer = (from, wwdata) => {
                const room = sesi(from, wwdata);
                if (room) room.cooldown = Date.now() + toMs(timeout + "s");
            };

            // merubah status room, dalam permainan
            const startGame = (from, wwdata) => {
                const room = sesi(from, wwdata);
                if (room) room.status = true;
            };

            // rubah hari
            const changeDay = (from, wwdata) => {
                const room = sesi(from, wwdata);
                if (!room) return;
                switch (room.time) {
                    case 'pagi':
                        room.time = 'voting';
                        break;
                    case 'malem':
                        room.time = 'pagi';
                        room.day += 1;
                        break;
                    case 'voting':
                        room.time = 'malem';
                        break;
                }
            };

            // hari voting
            const dayVoting = (from, wwdata) => {
                const room = sesi(from, wwdata);
                if (room && (room.time === "malem" || room.time === "pagi")) {
                    room.time = "voting";
                }
            };

            // hasil voting
            const voteResult = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.player.sort((a, b) => (a.vote < b.vote ? 1 : -1));
                if (room.player[0].vote === 0) return 0;
                if (room.player[0].vote === room.player[1].vote) return 1;
                return room.player[0];
            };

            // vote killing
            const voteKill = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.player.sort((a, b) => (a.vote < b.vote ? 1 : -1));
                if (room.player[0].vote === 0) return 0;
                if (room.player[0].vote === room.player[1].vote) return 1;
                room.player[0].isdead = true;
            };

            // voting reset
            const resetVote = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.player.forEach(item => {
                    item.vote = 0;
                });
                return true;
            };

            const voteDone = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.voting = false;
            };

            const voteStart = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.voting = true;
            };

            // clear vote
            const clearAllVote = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.player.forEach(item => {
                    item.vote = 0;
                    item.isvote = false;
                });
                return true;
            };

            // clearAll
            const clearAll = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.dead = [];
                room.seer = false;
                room.guardian = [];
                room.voting = false;
            };

            // clear all status player
            const clearAllStatus = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.player.forEach(item => {
                    item.effect = []
                });
                return true;
            };

            const skillOn = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.player.forEach(item => {
                    item.status = false;
                });
                return true;
            };

            const skillOff = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.player.forEach(item => {
                    item.status = true;
                });
                return true;
            };

            const playerHidup = (wwdata) => {
                const hasil = wwdata.player.filter(x => x.isdead === false);
                return hasil.length;
            };

            const playerMati = (wwdata) => {
                const hasil = wwdata.player.filter(x => x.isdead === true);
                return hasil.length;
            };

            // get player win
            const getWinner = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                var ww = 0;
                var orangbaik = 0;
                for (let i = 0; i < room.player.length; i++) {
                    if (room.player[i].isdead === false) {
                        if (room.player[i].role === "werewolf" || room.player[i].role === "sorcerer") {
                            ww += 1;
                        } else if (room.player[i].role === "warga" || room.player[i].role === "guardian" || room.player[i].role === "seer") {
                            orangbaik += 1;
                        }
                    }
                }
                if (room.voting) {
                    let voteData = voteResult(from, wwdata);
                    if (voteData != 0 && voteData != 1) {
                        if (voteData.role === "werewolf" || voteData.role === "sorcerer") {
                            ww -= 1;
                        } else if (voteData.role === "warga" || voteData.role === "seer" || voteData.role === "guardian") {
                            orangbaik -= 1;
                        }
                    }
                }
                if (ww === 0) {
                    room.iswin = true;
                    return {
                        voting: room.voting,
                        status: true
                    };
                } else if (ww === orangbaik) {
                    room.iswin = false;
                    return {
                        voting: room.voting,
                        status: false
                    };
                } else if (orangbaik === 0) {
                    room.iswin = false;
                    return {
                        voting: room.voting,
                        status: false
                    };
                } else {
                    return {
                        voting: room.voting,
                        status: null
                    };
                }
            };

            // sorted player
            const sortPlayer = (from, wwdata) => {
                room = sesi(from, wwdata);
                if (!room) return false;
                room.player.sort((a, b) => a.number - b.number);
            };

            // werewolf killing
            const killww = (wwdata) => {
                console.log('killww_data:', wwdata);
                for (let id of wwdata.dead) {
                    let index = wwdata.player.findIndex(x => x.number === id);
                    console.log('killww_player:', wwdata.player[index]);
                    if (wwdata.player[index].effect.includes("guardian")) continue;
                    wwdata.player[index].isdead = true;
                }
            };

            const pagii = (wwdata) => {
                if (wwdata.dead.length < 1) {
                    return `*W E R E W O L F - G A M E*\n\nMentari telah terbit, tidak ada korban berjatuhan malam ini, warga kembali melakukan aktifitasnya seperti biasa.\n${time_vote} detik tersisa sebelum waktu penentuan, para warga dipersilahkan untuk berdiskusi\n*Hari ke ${wwdata.day}*`;
                } else {
                    let hasDied = '';
                    let protectedByGuardian = '';
                    let guardianProtectedData = [];
                    let deathData = []
                    for (let i = 0; i < wwdata.dead.length; i++) {
                        let index = wwdata.player.findIndex(x => x.number === wwdata.dead[i]);
                        if (wwdata.player[index].effect.includes("guardian")) {
                            guardianProtectedData.push(wwdata.player[index].id);
                        } else {
                            deathData.push(wwdata.player[index].id);
                        }
                    }
                    for (let i = 0; i < deathData.length; i++) {
                        if (i === deathData.length - 1) {
                            if (deathData.length > 1) {
                                hasDied += ` dan @${deathData[i].split('@')[0]}`;
                            } else {
                                hasDied += `@${deathData[i].split('@')[0]}`;
                            }
                        } else if (i === deathData.length - 2) {
                            hasDied += `@${deathData[i].split('@')[0]}`;
                        } else {
                            hasDied += `@${deathData[i].split('@')[0]}, `;
                        }
                    }
                    for (let i = 0; i < guardianProtectedData.length; i++) {
                        if (i === guardianProtectedData.length - 1) {
                            if (guardianProtectedData.length > 1) {
                                protectedByGuardian += ` dan @${guardianProtectedData[i].split('@')[0]}`;
                            } else {
                                protectedByGuardian += `@${guardianProtectedData[i].split('@')[0]}`;
                            }
                        } else if (i === guardianProtectedData.length - 2) {
                            protectedByGuardian += `@${guardianProtectedData[i].split('@')[0]}`;
                        } else {
                            protectedByGuardian += `@${guardianProtectedData[i].split('@')[0]}, `;
                        }
                    }
                    return `*W E R E W O L F - G A M E*\n\nPagi telah tiba, warga desa menemukan ${wwdata.dead.length > 1 ? 'beberapa' : '1'} mayat di tumpukan puing dan darah berceceran. ${hasDied ? hasDied + " telah mati! " : ""}${protectedByGuardian.length > 1 ? protectedByGuardian + ' hampir dibunuh, namun *Guardian Angel* berhasil melindunginya.' : ""}\n\nTak terasa hari sudah siang, matahari tepat di atas kepala, terik panas matahari membuat suasana menjadi riuh, warga desa mempunyai ${time_vote} detik untuk berdiskusi\n*Hari ke ${wwdata.day}*`;
                }
            };

            async function pagi(item, wwdata) {
                skillOff(item.room, wwdata)
                let ment = item.player.map(x => x.id);
                sortPlayer(item.room, wwdata);
                killww(item);
                sortPlayer(item.room, wwdata);
                changeDay(item.room, wwdata);
                return await anya.sendMessage(item.room, {
                    text: pagii(item),
                    contextInfo: setting.fakereply ? {
                        mentionedJid: ment,
                        externalAdReply: {
                            title: 'WEREWOLF - GAME',
                            body: global.header,
                            mediaType: 1,
                            renderLargerThumbnail: false,
                            thumbnail: await resize(thumb1, 300, 175),
                            sourceUrl: setting.link,
                            mediaUrl: thumb1
                        }
                    } : {
                        mentionedJid: ment
                    }
                }, {
                    ephemeralExpiration: m.expiration
                });
            }

            async function voting(item, wwdata) {
                let mention = [];
                let values = item.player.map((p, index) => (!p.isdead ? `vote player ${index + 1}` : null)).filter(Boolean);
                voteStart(item.room, wwdata);
                textnya = `*W E R E W O L F - G A M E*\n\nSenja telah tiba. Seluruh warga berkumpul di balai desa untuk memilih siapa yang akan dieksekusi. Sebagian warga terlihat sibuk menyiapkan alat penyiksaan untuk malam ini. Kalian mempunyai waktu selama ${timeout} detik untuk memilih! Hati-hati, ada penghianat diantara kalian!\n\n*L I S T - P L A Y E R*:\n`;
                sortPlayer(item.room, wwdata);
                for (let player of item.player) {
                    textnya += `(${player.number}) @${player.id.split('@')[0]} ${player.isdead === true ? '☠️' : ''}\n`;
                    mention.push(player.id);
                }
                dayVoting(item.room, wwdata);
                clearAll(item.room, wwdata);
                clearAllStatus(item.room, wwdata);
                await anya.sendMessage(item.room, {
                    text: textnya,
                    contextInfo: setting.fakereply ? {
                        mentionedJid: mention,
                        externalAdReply: {
                            title: 'WEREWOLF - GAME',
                            body: global.header,
                            mediaType: 1,
                            renderLargerThumbnail: false,
                            thumbnail: await resize(thumb2, 300, 175),
                            sourceUrl: setting.link,
                            mediaUrl: thumb2
                        }
                    } : {
                        mentionedJid: mention
                    }
                }, {
                    ephemeralExpiration: m.expiration
                }).then(async (message) => {
                    let {
                        key
                    } = await anya.sendMessage(item.room, {
                        poll: {
                            name: 'Silahkan vote nomor player dibawah untuk menentukan siapa werewolf nya.',
                            values: values,
                            selectableCount: true
                        }
                    }, {
                        quoted: message,
                        ephemeralExpiration: m.expiration
                    })
                    anya.voting[item.room] = {
                        chatId: item.room,
                        key,
                        voters: [],
                        timeout: setTimeout(async function() {
                            const chatId = item.room;
                            await anya.sendMessage(chatId, {
                                delete: key
                            });
                            let voting = anya.voting[chatId];
                            if (voting && voting.voters.length > 0) {
                                const resultArray = getVoteResult(voting.voters);
                                for (let item of resultArray) {
                                    console.log('item:', item);
                                    const id = parseInt(item.candidate.replace(/[^0-9]/g, ''));
                                    const targetPlayer = dataPlayerById(id, wwdata, chatId)
                                    if (!targetPlayer) continue;
                                    targetPlayer.vote = item.count;
                                    console.log('targetPlayer:', targetPlayer);
                                }
                            }
                            delete anya.voting[chatId];
                        }, time_vote * 1000 - 500)
                    }
                })
            }

            async function malam(item, wwdata) {
                var hasil_vote = voteResult(item.room, wwdata);
                if (hasil_vote === 0) {
                    textnya = `*W E R E W O L F - G A M E*\n\nTerlalu bimbang menentukan pilihan. Warga pun pulang ke rumah masing-masing, tidak ada yang dieksekusi hari ini. Bulan bersinar terang, malam yang mencekam telah datang. Semoga tidak ada yang mati malam ini. Pemain malam hari: kalian punya ${timeout} detik untuk beraksi!`;
                    return anya.sendMessage(item.room, {
                        text: textnya,
                        contextInfo: setting.fakereply ? {
                            externalAdReply: {
                                title: 'WEREWOLF - GAME',
                                body: global.header,
                                mediaType: 1,
                                renderLargerThumbnail: false,
                                thumbnail: await resize(thumb3, 300, 175),
                                sourceUrl: setting.link,
                                mediaUrl: thumb3
                            }
                        } : {}
                    }, {
                        ephemeralExpiration: m.expiration
                    }).then(() => {
                        changeDay(item.room, wwdata);
                        voteDone(item.room, wwdata);
                        resetVote(item.room, wwdata);
                        clearAllVote(item.room, wwdata);
                        if (getWinner(item.room, wwdata).status != null)
                            return winPlayer(item, wwdata);
                    });
                } else if (hasil_vote === 1) {
                    textnya = `*W E R E W O L F - G A M E*\n\nWarga desa telah memilih, namun hasilnya seri.\n\nBintang memancarkan cahaya indah malam ini, warga desa beristirahat di kediaman masing masing. Pemain malam hari: kalian punya ${timeout} detik untuk beraksi!`;
                    return anya.sendMessage(item.room, {
                        text: textnya,
                        contextInfo: setting.fakereply ? {
                            externalAdReply: {
                                title: 'WEREWOLF - GAME',
                                body: global.header,
                                mediaType: 1,
                                renderLargerThumbnail: false,
                                thumbnail: await resize(thumb3, 300, 175),
                                sourceUrl: setting.link,
                                mediaUrl: thumb3
                            }
                        } : {}
                    }, {
                        ephemeralExpiration: m.expiration
                    }).then(() => {
                        changeDay(item.room, wwdata);
                        voteDone(item.room, wwdata);
                        resetVote(item.room, wwdata);
                        clearAllVote(item.room, wwdata);
                        if (getWinner(item.room, wwdata).status != null)
                            return winPlayer(item, wwdata);
                    });
                } else if (hasil_vote != 0 && hasil_vote != 1) {
                    if (hasil_vote.role === "werewolf") {
                        textnya = `*W E R E W O L F - G A M E*\n\nWarga desa telah memilih dan sepakat @${hasil_vote.id.split('@')[0]} dieksekusi mati.

@${hasil_vote.id.split('@')[0]} adalah ${hasil_vote.role} ${emoji_role(hasil_vote.role)}`;
                        voteKill(item.room, wwdata);
                        let ment = [];
                        ment.push(hasil_vote.id);
                        return await anya.sendMessage(item.room, {
                            text: textnya,
                            contextInfo: setting.fakereply ? {
                                mentionedJid: ment,
                                externalAdReply: {
                                    title: 'WEREWOLF - GAME',
                                    body: global.header,
                                    mediaType: 1,
                                    renderLargerThumbnail: false,
                                    thumbnail: await resize(thumb4, 300, 175),
                                    sourceUrl: setting.link,
                                    mediaUrl: thumb4
                                }
                            } : {
                                mentionedJid: ment
                            }
                        }, {
                            ephemeralExpiration: m.expiration
                        }).then(() => {
                            changeDay(item.room, wwdata);
                            voteDone(item.room, wwdata);
                            resetVote(item.room, wwdata);
                            clearAllVote(item.room, wwdata);
                            if (getWinner(item.room, wwdata).status != null)
                                return winPlayer(item, wwdata);
                        });
                    } else {
                        textnya = `*W E R E W O L F - G A M E*\n\nWarga desa telah memilih dan sepakat @${hasil_vote.id.split('@')[0]} dieksekusi mati.

@${hasil_vote.id.split('@')[0]} adalah ${hasil_vote.role} ${emoji_role(hasil_vote.role)}

Bulan bersinar terang malam ini, warga desa beristirahat di kediaman masing masing. Pemain malam hari: kalian punya ${timeout} detik untuk beraksi!`;
                        voteKill(item.room, wwdata);
                        let ment = [];
                        ment.push(hasil_vote.id);
                        return await anya.sendMessage(item.room, {
                            text: textnya,
                            contextInfo: setting.fakereply ? {
                                mentionedJid: ment,
                                externalAdReply: {
                                    title: 'WEREWOLF - GAME',
                                    body: global.header,
                                    mediaType: 1,
                                    renderLargerThumbnail: false,
                                    thumbnail: await resize(thumb4, 300, 175),
                                    sourceUrl: setting.link,
                                    mediaUrl: thumb4
                                }
                            } : {
                                mentionedJid: ment
                            }
                        }, {
                            ephemeralExpiration: m.expiration
                        }).then(() => {
                            changeDay(item.room, wwdata);
                            voteDone(item.room, wwdata);
                            resetVote(item.room, wwdata);
                            clearAllVote(item.room, wwdata);
                            if (getWinner(item.room, wwdata).status != null)
                                return winPlayer(item, wwdata);
                        });
                    }
                }
            }

            async function skillPlayer(item, wwdata) {
                skillOn(item.room, wwdata)
                if (getWinner(item.room, wwdata).status != null || item.win != null) {
                    return await winPlayer(item, wwdata);
                } else {
                    if (!item) return;
                    if (!item.player) return;
                    if (item.win != null) return;
                    let tok1 = '';
                    let tok2 = '';
                    let membernya = [];
                    sortPlayer(item.room, wwdata);
                    let votes = item.player.filter(p => !p.isdead).map(x => x);
                    let polling = [];
                    // item.player.map((p, index) => (!p.isdead ? `ww value ${p.number}` : null)).filter(Boolean);
                    // item.player.filter(p => !p.isdead).map(v => `ww value ${v.number}`);
                    item.player.forEach(player => {
                        tok1 += `(${player.number}) @${player.id.split('@')[0]}${player.isdead === true ? ' ☠️' : ''}\n`;
                        // tok2 += `(${player.number}) @${player.id.split('@')[0]} ${player.role === 'werewolf' || player.role === 'sorcerer' ? (player.isdead === true ? '☠️' : player.role) : ''}\n`;
                        membernya.push(player.id);
                    })
                    for (let player of item.player) {
                        if (player.role === "werewolf") {
                            if (player.isdead != true) {
                                polling = votes.filter(x => x.role != 'werewolf' || x.role != 'sorcerer' && x.id != player.id).map(v => `ww kill ${v.number}`);
                                textnya = `Silahkan pilih salah satu orang yang ingin kamu makan pada malam hari ini\n\n*LIST PLAYER*:\n${tok1}`;
                                await anya.sendMessage(player.id, {
                                    text: textnya,
                                    mentions: membernya
                                }, {
                                    ephemeralExpiration: m.expiration
                                }).then(async () => {
                                    await anya.sendPoll(player.id, '*SILAHKAN VOTE PLAYER DIBAWAH*', polling)
                                });
                            }
                        } else if (player.role === "warga") {
                            if (!player.isdead) {
                                textnya = `Sebagai seorang warga berhati-hatilah, mungkin kamu adalah target selanjutnya.\n\n*LIST PLAYER*:\n${tok1}`;
                                await anya.sendMessage(player.id, {
                                    text: textnya,
                                    mentions: membernya
                                }, {
                                    ephemeralExpiration: m.expiration
                                });
                            }
                        } else if (player.role === "seer") {
                            if (!player.isdead) {
                                polling = votes.filter(x => x.id != player.id).map(v => `ww dreamy ${v.number}`);
                                textnya = `Baiklah, siapa yang ingin kamu lihat peran nya kali ini.\n\n*LIST PLAYER*:\n${tok1}`;
                                await anya.sendMessage(player.id, {
                                    text: textnya,
                                    mentions: membernya
                                }, {
                                    ephemeralExpiration: m.expiration
                                }).then(async () => {
                                    await anya.sendPoll(player.id, '*SILAHKAN VOTE PLAYER DIBAWAH*', polling)
                                });
                            }
                        } else if (player.role === "guardian") {
                            if (!player.isdead) {
                                polling = votes.filter(x => x.role != 'guardian' && x.id != player.id).map(v => `ww deff ${v.number}`);
                                textnya = `Kamu adalah seorang *Guardian*, lindungi para warga, silahkan pilih salah 1 player yang ingin kamu lindungi\n\n*LIST PLAYER*:\n${tok1}`;
                                await anya.sendMessage(player.id, {
                                    text: textnya,
                                    mentions: membernya
                                }, {
                                    ephemeralExpiration: m.expiration
                                }).then(async () => {
                                    await anya.sendPoll(player.id, '*SILAHKAN VOTE PLAYER DIBAWAH*', polling)
                                });
                            }
                        } else if (player.role === "sorcerer") {
                            if (!player.isdead) {
                                polling = votes.filter(x => x.role != 'werewolf' || x.role != 'sorcerer' && x.id != player.id).map(v => `ww sorcerer ${v.number}`);
                                textnya = `Baiklah, lihat apa yang bisa kamu buat, silakan pilih 1 orang yang ingin kamu buka identitasnya\n\n*LIST PLAYER*:\n${tok1}`;
                                await anya.sendMessage(player.id, {
                                    text: textnya,
                                    mentions: membernya
                                }, {
                                    ephemeralExpiration: m.expiration
                                }).then(async () => {
                                    await anya.sendPoll(player.id, '*SILAHKAN VOTE PLAYER DIBAWAH*', polling)
                                });
                            }
                        }
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    }
                }
            }

            async function winPlayer(item, wwdata) {
                const sesinya = item.room;
                if (getWinner(item.room, wwdata).status === false || item.iswin === false) {
                    textnya = `*W E R E W O L F - W I N*\n\nTEAM WEREWOLF\n`;
                    let ment = [];
                    let hadiah = func.randomNomor(10000, 20000)
                    for (let player of item.player) {
                        if (player.role === "sorcerer" || player.role === "werewolf") {
                            textnya += `${player.number}) @${player.id.split('@')[0]}\n *Role* : ${player.role}\n\n`;
                            global.db.users[player.id].balance += parseInt(hadiah);
                            global.db.users[player.id].game.werewolf += 1;
                            ment.push(player.id);
                        }
                    }
                    textnya += `Hadiah: $${hadiah} balance`
                    return await anya.sendMessage(sesinya, {
                        text: textnya,
                        contextInfo: setting.fakereply ? {
                            mentionedJid: ment,
                            externalAdReply: {
                                title: 'WEREWOLF - GAME',
                                body: global.header,
                                mediaType: 1,
                                renderLargerThumbnail: false,
                                thumbnail: await resize(thumb5, 300, 175),
                                sourceUrl: setting.link,
                                mediaUrl: thumb5
                            }
                        } : {
                            mentionedJid: ment
                        }
                    }, {
                        ephemeralExpiration: m.expiration
                    }).then(() => {
                        delete wwdata[item.room];
                    });
                } else if (getWinner(item.room, wwdata).status === true) {
                    textnya = `*T E A M - W A R G A - W I N*\n\nTEAM WARGA\n`;
                    let ment = [];
                    let hadiah = func.randomNomor(10000, 15000)
                    for (let player of item.player) {
                        if (player.role === "warga" || player.role === "guardian" || player.role === "seer") {
                            textnya += `${player.number}) @${player.id.split('@')[0]}\n *Role* : ${player.role}\n\n`;
                            global.db.users[player.id].balance += parseInt(hadiah);
                            global.db.users[player.id].game.werewolf += 1;
                            ment.push(player.id);
                        }
                    }
                    textnya += `Hadiah: $${hadiah} balance`
                    return await anya.sendMessage(sesinya, {
                        text: textnya,
                        contextInfo: setting.fakereply ? {
                            mentionedJid: ment,
                            externalAdReply: {
                                title: 'WEREWOLF - GAME',
                                body: global.header,
                                mediaType: 1,
                                renderLargerThumbnail: false,
                                thumbnail: await resize(thumb5, 300, 175),
                                sourceUrl: setting.link,
                                mediaUrl: thumb5
                            }
                        } : {
                            mentionedJid: ment
                        }
                    }, {
                        ephemeralExpiration: m.expiration
                    }).then(() => {
                        delete wwdata[item.room];
                    });
                }
            }

            // playing
            async function startGameWerewolf(id, wwdata) {
                while (getWinner(id, wwdata).status === null) {
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(timeout * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await pagi(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(time_vote * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await voting(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(time_vote * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await malam(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await skillPlayer(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) break;
                }
                await winPlayer(sesi(id, wwdata), wwdata);
            }

            async function runVote(id, wwdata) {
                while (getWinner(id, wwdata).status === null) {
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await voting(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(timeout * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await malam(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await skillPlayer(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(timeout * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await pagi(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(timeout * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) break;
                }
                await winPlayer(sesi(id, wwdata), wwdata);
            }

            async function runMalam(id, wwdata) {
                while (getWinner(id, wwdata).status === null) {
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await skillPlayer(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(timeout * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await pagi(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(time_vote * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await voting(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(timeout * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await malam(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) break;
                }
                await winPlayer(sesi(id, wwdata), wwdata);
            }

            async function runPagi(id, wwdata) {
                while (getWinner(id, wwdata).status === null) {
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await pagi(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(time_vote * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await voting(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(timeout * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await malam(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await skillPlayer(sesi(id, wwdata), wwdata);
                    }
                    if (getWinner(id, wwdata).status != null) {
                        winPlayer(getWinner(id, wwdata), wwdata);
                        break;
                    } else {
                        await delay(timeout * 1000);
                    }
                    if (getWinner(id, wwdata).status != null) break;
                }
                await winPlayer(sesi(id, wwdata), wwdata);
            }

            if (m.isGc) {
                // [ Membuat Room ]
                if (value === "create") {
                    if (m.chat in werewolf) return m.reply("Group masih dalam sesi permainan");
                    if (playerOnGame(m.sender, werewolf) === true) return m.reply("Kamu masih dalam sesi game");
                    werewolf[m.chat] = {
                        room: m.chat,
                        owner: m.sender,
                        status: false,
                        iswin: null,
                        cooldown: null,
                        day: 0,
                        time: "malem",
                        player: [],
                        dead: [],
                        voting: false,
                        seer: false,
                        guardian: [],
                    };
                    anya.sendbut(m.chat, '*W E R E W O L F - G A M E*\n\n' + 'Room berhasil dibuat, klik button dibawah untuk join', 'Jumlah player minimal adalah 5 dan maximal 15', [
                        ['werewolf join', `${m.prefix}ww join`]
                    ], m, {
                        expiration: m.expiration
                    })
                    // [ Join sesi permainan ]
                } else if (value === "join") {
                    if (!werewolf[m.chat]) return m.reply("Belum ada sesi permainan");
                    if (werewolf[m.chat].status === true) return m.reply("Sesi permainan sudah dimulai");
                    if (werewolf[m.chat].player.length >= 15) return m.reply("Maaf jumlah player telah penuh");
                    if (playerOnRoom(m.sender, m.chat, werewolf) === true) return m.reply("Kamu sudah join dalam room ini");
                    if (playerOnGame(m.sender, werewolf) === true) return m.reply("Kamu masih dalam sesi game");
                    if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
                    let playerdata = {
                        id: m.sender,
                        number: werewolf[m.chat].player.length + 1,
                        sesi: m.chat,
                        status: false,
                        role: false,
                        effect: [],
                        vote: 0,
                        isdead: false,
                        isvote: false,
                    };
                    werewolf[m.chat].player.push(playerdata);
                    let caption = werewolf[m.chat].player.map((item, index) => `${item.number}) ${global.db.users[item.id]?.name || anya.getName(item.id)}`).join('\n');
                    let player = [];
                    for (let i = 0; i < werewolf[m.chat].player.length; i++) {
                        player.push(werewolf[m.chat].player[i].id);
                    }
                    anya.sendbut(m.chat, '*W E R E W O L F - P L A Y E R*\n\n' + caption, 'Jumlah player minimal adalah 5 dan maximal 15', [
                        [`${player.length == 5 || player.length >= 15 ? 'werewolf start' : 'werewolf join'}`, `${m.prefix}ww ${player.length == 5 || player.length >= 15 ? 'start' : 'join'}`]
                    ], m, {
                        mentions: player,
                        expiration: m.expiration
                    })
                    // [ Game Play ]
                } else if (value === "start") {
                    if (!werewolf[m.chat]) return m.reply("Belum ada sesi permainan");
                    if (werewolf[m.chat].player?.length === 0) return m.reply("Room belum memiliki player");
                    if (werewolf[m.chat].player?.length < 5) return m.reply("Maaf jumlah player belum memenuhi syarat");
                    if (playerOnRoom(m.sender, m.chat, werewolf) === false) return m.reply("Kamu belum join dalam room ini");
                    if (werewolf[m.chat].cooldown > 0) {
                        if (werewolf[m.chat].time === "voting") {
                            clearAllVote(m.chat, werewolf);
                            addTimer(m.chat, werewolf);
                            return await runVote(m.chat, werewolf);
                        } else if (werewolf[m.chat].time === "malem") {
                            clearAllVote(m.chat, werewolf);
                            addTimer(m.chat, werewolf);
                            return await runMalam(m.chat, werewolf);
                        } else if (werewolf[m.chat].time === "pagi") {
                            clearAllVote(m.chat, werewolf);
                            addTimer(m.chat, werewolf);
                            return await runPagi(m.chat, werewolf);
                        }
                    }
                    if (werewolf[m.chat].status === true) return m.reply("Sesi permainan telah dimulai");
                    if (werewolf[m.chat].owner !== m.sender) return m.reply(`Hanya @${werewolf[m.chat].owner.split("@")[0]} yang dapat memulai permainan`);
                    let list1 = '';
                    let list2 = '';
                    let player = [];
                    let polling = [];
                    roleGenerator(m.chat, werewolf);
                    addTimer(m.chat, werewolf);
                    startGame(m.chat, werewolf);
                    for (let i = 0; i < werewolf[m.chat].player.length; i++) {
                        list1 += `(${werewolf[m.chat].player[i].number}) @${werewolf[m.chat].player[i].id.split('@')[0]}\n`;
                        list2 += `(${werewolf[m.chat].player[i].number}) @${werewolf[m.chat].player[i].id.split('@')[0]} ${werewolf[m.chat].player[i].role === 'werewolf' || werewolf[m.chat].player[i].role === 'sorcerer' ? '[' + werewolf[m.chat].player[i].role + ']' : ''}\n`;
                        player.push(werewolf[m.chat].player[i].id);
                        polling.push(`ww value ${i + 1}`);
                    }
                    for (let i = 0; i < werewolf[m.chat].player.length; i++) {
                        // [ Werewolf ]
                        if (werewolf[m.chat].player[i].role === "werewolf") {
                            if (werewolf[m.chat].player[i].isdead != true) {
                                let text = `Hai ${anya.getName(werewolf[m.chat].player[i].id)}, Kamu telah dipilih untuk memerankan *Werewolf* ${emoji_role("werewolf")} pada permainan kali ini, silahkan pilih salah satu player yang ingin kamu makan pada malam hari ini\n\n*LIST PLAYER*:\n${list2}`;
                                await anya.sendMessage(werewolf[m.chat].player[i].id, {
                                    text: text,
                                    mentions: player
                                }).then(async () => {
                                    await anya.sendPoll(werewolf[m.chat].player[i].id, '*SILAHKAN VOTE PLAYER DIBAWAH*', polling.map(v => v.replace('value', 'kill')))
                                });
                            }

                            // [ Villager ]
                        } else if (werewolf[m.chat].player[i].role === "warga") {
                            if (werewolf[m.chat].player[i].isdead != true) {
                                let text = `Hai ${anya.getName(werewolf[m.chat].player[i].id)} Peran kamu adalah *Warga Desa* ${emoji_role("warga")}, tetap waspada, mungkin *Werewolf* akan memakanmu malam ini, silakan masuk kerumah masing masing.\n\n*LIST PLAYER*:\n${list1}`;
                                await anya.sendMessage(werewolf[m.chat].player[i].id, {
                                    text: text,
                                    mentions: player
                                });
                            }

                            // [ Penerawangan ]
                        } else if (werewolf[m.chat].player[i].role === "seer") {
                            if (werewolf[m.chat].player[i].isdead != true) {
                                let text = `Hai ${anya.getName(werewolf[m.chat].player[i].id)} Kamu telah terpilih untuk menjadi *Penerawang* ${emoji_role("seer")}. Dengan sihir yang kamu punya, kamu bisa mengetahui peran pemain pilihanmu.\n\n*LIST PLAYER*:\n${list1}`;
                                await anya.sendMessage(werewolf[m.chat].player[i].id, {
                                    text: text,
                                    mentions: player
                                }).then(async () => {
                                    await anya.sendPoll(werewolf[m.chat].player[i].id, '*SILAHKAN VOTE PLAYER DIBAWAH*', polling.map(v => v.replace('value', 'dreamy')))
                                });
                            }

                            // [ Guardian ]
                        } else if (werewolf[m.chat].player[i].role === "guardian") {
                            if (werewolf[m.chat].player[i].isdead != true) {
                                let text = `Hai ${anya.getName(werewolf[m.chat].player[i].id)} Kamu terpilih untuk memerankan *Malaikat Pelindung* ${emoji_role('guardian')}, dengan kekuatan yang kamu miliki, kamu bisa melindungi para warga, silahkan pilih salah 1 player yang ingin kamu lindungi\n\n*LIST PLAYER*:\n${list1}`;
                                await anya.sendMessage(werewolf[m.chat].player[i].id, {
                                    text: text,
                                    mentions: player
                                }).then(async () => {
                                    await anya.sendPoll(werewolf[m.chat].player[i].id, '*SILAHKAN VOTE PLAYER DIBAWAH*', polling.map(v => v.replace('value', 'deff')))
                                });
                            }

                            // [ Sorcerer ]
                        } else if (werewolf[m.chat].player[i].role === "sorcerer") {
                            if (werewolf[m.chat].player[i].isdead != true) {
                                let text = `Hai ${anya.getName(werewolf[m.chat].player[i].id)} Kamu terpilih sebagai Penyihir ${emoji_role('sorcerer')}, dengan kekuasaan yang kamu punya, kamu bisa membuka identitas para player, silakan pilih 1 orang yang ingin kamu buka identitasnya\n\n*LIST PLAYER*:\n${list2}`;
                                await anya.sendMessage(werewolf[m.chat].player[i].id, {
                                    text: text,
                                    mentions: player
                                }).then(async () => {
                                    await anya.sendPoll(werewolf[m.chat].player[i].id, '*SILAHKAN VOTE PLAYER DIBAWAH*', polling.map(v => v.replace('value', 'sorcerer')))
                                });
                            }
                        }
                    }
                    await anya.sendMessage(m.chat, {
                        text: "*W E R E W O L F - G A M E*\n\nGame telah dimulai, para player akan memerankan perannya masing masing, silahkan cek chat pribadi untuk melihat role kalian. Berhati-hatilah para warga, mungkin malam ini adalah malah terakhir untukmu",
                        contextInfo: setting.fakereply ? {
                            mentionedJid: player,
                            externalAdReply: {
                                title: 'WEREWOLF - GAME',
                                body: global.header,
                                mediaType: 1,
                                renderLargerThumbnail: false,
                                thumbnail: await resize(thumb, 300, 175),
                                sourceUrl: setting.link,
                                mediaUrl: thumb
                            }
                        } : {
                            mentionedJid: player
                        }
                    }, {
                        ephemeralExpiration: m.expiration
                    });
                    await startGameWerewolf(m.chat, werewolf);
                } else if (value === "exit") {
                    if (!werewolf[m.chat]) return m.reply("Tidak ada sesi permainan");
                    if (playerOnRoom(m.sender, m.chat, werewolf) === false) return m.reply("Kamu tidak dalam sesi permainan");
                    if (werewolf[m.chat].status === true) return m.reply("Permainan sudah dimulai, kamu tidak bisa keluar");
                    playerExit(m.chat, m.sender, werewolf);
                    m.reply(`@${m.sender.split("@")[0]} Keluar dari permainan`);
                } else if (value === "delete") {
                    if (!werewolf[m.chat]) return m.reply("Tidak ada sesi permainan");
                    if (werewolf[m.chat].owner !== m.sender) return m.reply(`Hanya @${werewolf[m.chat].owner.split('@')[0]} yang dapat menghapus sesi permainan ini`);
                    anya.sendMessage(m.chat, {
                        text: "Sesi permainan berhasil dihapus"
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    }).then(() => {
                        delete werewolf[m.chat];
                    });
                } else if (value === "player") {
                    if (!werewolf[m.chat]) return m.reply("Tidak ada sesi permainan");
                    if (playerOnRoom(m.sender, m.chat, werewolf) === false) return m.reply("Kamu tidak dalam sesi permainan");
                    if (werewolf[m.chat].player.length === 0) return m.reply("Sesi permainan belum memiliki player");
                    let player = [];
                    let text = "*W E R E W O L F - G A M E*\n\nLIST PLAYER:\n";
                    for (let i = 0; i < werewolf[m.chat].player.length; i++) {
                        text += `(${werewolf[m.chat].player[i].number}) @${werewolf[m.chat].player[i].id.split('@')[0]} ${werewolf[m.chat].player[i].isdead === true ? '☠️ ' + werewolf[m.chat].player[i].role : ''}\n`;
                        player.push(werewolf[m.chat].player[i].id);
                    }
                    anya.sendMessage(m.chat, {
                        text: text,
                        contextInfo: setting.fakereply ? {
                            mentionedJid: player,
                            externalAdReply: {
                                title: 'WEREWOLF - GAME',
                                body: global.header,
                                mediaType: 1,
                                renderLargerThumbnail: false,
                                thumbnail: await resize(thumb, 300, 175),
                                sourceUrl: setting.link,
                                mediaUrl: thumb
                            }
                        } : {
                            mentionedJid: player
                        }
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    });
                } else {
                    let text = `\n*W E R E W O L F - G A M E*\n\nPermainan Sosial Yang Berlangsung Dalam Beberapa Putaran/ronde. Para Pemain Dituntut Untuk Mencari Seorang Penjahat Yang Ada Dipermainan. Para Pemain Diberi Waktu, Peran, Serta Kemampuannya Masing-masing Untuk Bermain Permainan Ini\n\n*⌂ C O M M A N D*\n`;
                    text += `${m.prefix + m.command} create\n`;
                    text += `${m.prefix + m.command} join\n`;
                    text += `${m.prefix + m.command} start\n`;
                    text += `${m.prefix + m.command} exit\n`;
                    text += `${m.prefix + m.command} delete\n`;
                    text += `${m.prefix + m.command} player\n`;
                    text += `\nPermainan ini dapat dimainkan oleh 5 sampai 15 orang.`;
                    anya.sendMessage(m.chat, {
                        text: text.trim(),
                        contextInfo: setting.fakereply ? {
                            externalAdReply: {
                                title: 'WEREWOLF - GAME',
                                body: global.header,
                                mediaType: 1,
                                renderLargerThumbnail: false,
                                thumbnail: await resize(thumb, 300, 175),
                                sourceUrl: setting.link,
                                mediaUrl: thumb
                            }
                        } : {}
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    });
                }
            } else if (m.isPc) {
                if (playerOnGame(m.sender, werewolf) === false) return m.reply("Kamu tidak dalam sesi game");
                if (dataPlayer(m.sender, werewolf).status === true) return m.reply("Skill telah digunakan, skill hanya bisa digunakan sekali setiap malam");
                if (dataPlayer(m.sender, werewolf).isdead === true) return m.reply("Kamu sudah mati");
                if (!target || target.length < 1) return m.reply("Masukan nomor player");
                if (isNaN(target)) return m.reply("Gunakan hanya nomor");
                let byId = getPlayerById2(m.sender, parseInt(target), werewolf);
                if (byId === false) return m.reply("Player tidak terdaftar");
                if (byId.db.isdead == true) return m.reply("Player sudah mati");
                if (byId.db.id === m.sender) return m.reply("Tidak bisa menggunakan skill untuk diri sendiri");
                if (value === "kill") {
                    if (dataPlayer(m.sender, werewolf).role !== "werewolf") return m.reply("Peran ini bukan untuk kamu");
                    if (byId.db.role === "sorcerer") return m.reply("Tidak bisa menggunakan skill untuk teman");
                    if (getDeadPlayer(m.sender, parseInt(target), werewolf)) return m.reply("Player sudah di bunuh werewolf lain");
                    await anya.reply(m.chat, `Berhasil membunuh player ${parseInt(target)}`, m, {
                        expiration: m.expiration
                    })
                    dataPlayer(m.sender, werewolf).status = true;
                    killWerewolf(m.sender, parseInt(target), werewolf);
                } else if (value === "dreamy") {
                    if (dataPlayer(m.sender, werewolf).role !== "seer") return m.reply("Peran ini bukan untuk kamu");
                    let dreamy = dreamySeer(m.sender, parseInt(target), werewolf);
                    await anya.reply(m.chat, `Berhasil membuka identitas player ${target} adalah ${dreamy}`, m, {
                        expiration: m.expiration
                    })
                    dataPlayer(m.sender, werewolf).status = true;
                } else if (value === "deff") {
                    if (dataPlayer(m.sender, werewolf).role !== "guardian") return m.reply("Peran ini bukan untuk kamu");
                    await anya.reply(m.chat, `Berhasil melindungi player ${target}`, m, {
                        expiration: m.expiration
                    })
                    protectGuardian(m.sender, parseInt(target), werewolf);
                    dataPlayer(m.sender, werewolf).status = true;
                } else if (value === "sorcerer") {
                    if (dataPlayer(m.sender, werewolf).role !== "sorcerer") return m.reply("Peran ini bukan untuk kamu");
                    if (byId.db.role === "werewolf") return m.reply("Tidak bisa menggunakan skill untuk teman");
                    let sorker = sorcerer(m.sender, parseInt(target), werewolf);
                    await anya.reply(m.chat, `Berhasil membuka identitas player ${target} adalah ${sorker}`, m, {
                        expiration: m.expiration
                    })
                    dataPlayer(m.sender, werewolf).status = true;
                }
            }
        } catch (error) {
            delete werewolfData;
            return await anya.reply(m.chat, `Terjadi kesalahan pada sesi game ini dan sesi game werewolf telah dihapus otomatis.\n\n${error.message}\n- silahkan mulai ulang game werewolf.`, m, {
                expiration: m.expiration
            })
        }
    },
    main: async (m, {
        func,
        anya,
        store
    }) => {
        anya.voting = anya.voting || {};
        anya.werewolf = anya.werewolf || {};
        if (/^\d.*(@g\.us)$/.test(m.chat)) {
            if (typeof anya.voting[m.chat] !== 'undefined' && typeof anya.werewolf[m.chat] !== 'undefined') {
                const werewolf = anya.werewolf;
                let votingData = anya.voting[m.chat];
                if (m.message?.pollUpdateMessage && m.message?.pollUpdateMessage?.pollCreationMessageKey?.id === votingData.key.id && anya.werewolf[m.chat]) {
                    let werewolfData = anya.werewolf[m.chat];
                    if (werewolfData.player.map(item => item.id).includes(m.sender)) {
                        if (werewolfData.status === false) return false
                        if (werewolfData.time !== 'voting') return false
                        if (playerOnRoom(m.sender, m.chat, werewolf) === false) return console.log('voting not player from:', m.sender);
                        if (dataPlayer(m.sender, werewolf).isdead === true) return console.log('voting player isdead from:', m.sender);
                        console.log('voting player from:', m.sender);
                        const messageCtx = normalizeMessageContent(m.message);
                        const key = messageCtx.pollUpdateMessage.pollCreationMessageKey;
                        const msg = store.messages[m.chat]?.array?.find(x => key.id === x.key.id);
                        if (!msg) return false
                        const message = msg.message;
                        const botJid = jidNormalizedUser(anya.authState.creds.me.id);
                        const voterJid = getKeyAuthor(m.key, botJid);
                        const pollCreatorJid = getKeyAuthor(key, botJid);
                        const pollEncKey = message.messageContextInfo?.messageSecret;
                        const vote = decryptPollVote(messageCtx.pollUpdateMessage.vote, {
                            pollEncKey: pollEncKey,
                            pollCreatorJid: pollCreatorJid,
                            pollMsgId: key.id,
                            voterJid: voterJid
                        });
                        if (!vote) return false
                        const pollCreation = [{
                            key: key,
                            update: {
                                pollUpdates: [{
                                    pollUpdateMessageKey: m.key,
                                    vote: vote,
                                    senderTimestampMs: m.messageTimestamp
                                }]
                            }
                        }];
                        const pollUpdate = await getAggregateVotesInPollMessage({
                            message: message,
                            pollUpdates: pollCreation[0]?.update.pollUpdates
                        });
                        if (!pollUpdate) return false;
                        const voteName = pollUpdate?.find(v => v.voters.length !== 0)?.name;
                        let votersData = votingData.voters.find(x => x.jid === m.sender);
                        let name = voteName.replace('vote', '')?.trim();
                        if (!votersData) {
                            votingData.voters.push({
                                jid: m.sender,
                                vote: name
                            })
                            alreadyVote(m.chat, m.sender, werewolf);
                        } else {
                            votersData.vote = name;
                        }
                    }
                }
            }
        }
    }
}

function getVoteResult(votes) {
    const voteCount = {};

    // Hitung jumlah vote untuk setiap pilihan
    votes.forEach(vote => {
        if (voteCount[vote.vote]) {
            voteCount[vote.vote]++;
        } else {
            voteCount[vote.vote] = 1;
        }
    });

    // Buat array hasil vote
    const resultArray = Object.entries(voteCount).map(([candidate, count]) => ({
        candidate,
        count
    }));

    // Kembalikan hasil
    return resultArray
}