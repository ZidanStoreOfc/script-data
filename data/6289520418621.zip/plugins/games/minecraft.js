const cooldownTime = 5000; // Waktu cooldown dalam milidetik (5 detik)
let lastActionTime = {};

exports.run = {
    usage: [
        'teleport',
        'fightboss',
        'mining',
    ],
    use: 'parameter',
    category: 'games',
    async: async (m, {
        func,
        anya,
        fkon,
        setting
    }) => {
        let user = global.db.users[m.sender];

        if (!user.hasOwnProperty('currentWorld')) {
            user.currentWorld = 'Overworld';
        }
        if (!user.hasOwnProperty('inventory')) {
            user.inventory = {
                katalis_sculk: 0,
                nether_star: 0,
                ender_egg: 0,
                obsidian: 0,
                coal: 0,
                iron: 0,
                gold: 0,
                copper: 0,
                redstone: 0,
                lapis_lazuli: 0,
                diamond: 0,
                emerald: 0,
                quartz: 0,
                gold_nugget: 0,
                ancient_debris: 0,
            }
        }

        async function loadingTeleport(worldnya) {
            const key = await anya.reply(m.chat, 'Sedang Teleport..\n《█▒▒▒▒▒▒▒▒▒▒▒▒▒》10%', fkon, {
                expiration: m.expiration
            })
            const arr = [{
                    text: "Sedang Teleport...\n《█▒▒▒▒▒▒▒▒▒▒▒▒▒》20%",
                    timeout: 1454
                },
                {
                    text: "Sedang Teleport...\n《████▒▒▒▒▒▒▒▒▒▒》30%",
                    timeout: 1454
                },
                {
                    text: "Sedang Teleport...\n《██████▒▒▒▒▒▒▒▒》40%",
                    timeout: 1454
                },
                {
                    text: "Sedang Teleport...\n《████████▒▒▒▒▒▒》50%",
                    timeout: 1454
                },
                {
                    text: "Sedang Teleport...\n《█████████▒▒▒▒▒》60%",
                    timeout: 1454
                },
                {
                    text: "Sedang Teleport...\n《███████████▒▒▒》70%",
                    timeout: 1454
                },
                {
                    text: "Sedang Teleport...\n《████████████▒▒》80%",
                    timeout: 1454
                },
                {
                    text: "Sedang Teleport...\n《█████████████▒》90%",
                    timeout: 1454
                },
                {
                    text: "Sedang Teleport...\n《██████████████》100%",
                    timeout: 1454
                },
                {
                    text: "Sedang Teleport...\nᴄᴏᴍᴘʟᴇᴛᴇ",
                    timeout: 1454
                },
                {
                    text: `Sukses Teleport Ke ${worldnya}!`,
                    timeout: 1454
                },
            ];

            for (let i = 0; i < arr.length; i++) {
                await new Promise(resolve => setTimeout(resolve, arr[i].timeout));
                await anya.relayMessage(m.chat, {
                    protocolMessage: {
                        key: key,
                        type: 14,
                        editedMessage: {
                            conversation: arr[i].text
                        }
                    }
                }, {
                    quoted: fkon,
                    ephemeralExpiration: m.expiration
                });
            }
        }

        async function loadingFightBoss(bossName, fightText) {
            let caption = `Entering Boss Dungeon..⚔️ Melawan ${bossName}! Bersiaplah untuk bertempur!`
            const key = await anya.reply(m.chat, `${caption}\n《█▒▒▒▒▒▒▒▒▒▒▒▒▒》10%`, fkon, {
                expiration: m.expiration
            })
            const arr = [{
                    text: `${caption}\n《█▒▒▒▒▒▒▒▒▒▒▒▒▒》20%`,
                    timeout: 1454
                },
                {
                    text: `${caption}\n《████▒▒▒▒▒▒▒▒▒▒》30%`,
                    timeout: 1454
                },
                {
                    text: `${caption}\n《██████▒▒▒▒▒▒▒▒》40%`,
                    timeout: 1454
                },
                {
                    text: `${caption}\n《████████▒▒▒▒▒▒》50%`,
                    timeout: 1454
                },
                {
                    text: `${caption}\n《█████████▒▒▒▒▒》60%`,
                    timeout: 1454
                },
                {
                    text: `${caption}\n《███████████▒▒▒》70%`,
                    timeout: 1454
                },
                {
                    text: `${caption}\n《████████████▒▒》80%`,
                    timeout: 1454
                },
                {
                    text: `${caption}\n《█████████████▒》90%`,
                    timeout: 1454
                },
                {
                    text: `${caption}\n《██████████████》100%`,
                    timeout: 1454
                },
                {
                    text: `${caption}\nᴄᴏᴍᴘʟᴇᴛᴇ`,
                    timeout: 1454
                },
                {
                    text: fightText,
                    timeout: 1454
                },
            ];

            for (let i = 0; i < arr.length; i++) {
                await new Promise(resolve => setTimeout(resolve, arr[i].timeout));
                await anya.relayMessage(m.chat, {
                    protocolMessage: {
                        key: key,
                        type: 14,
                        editedMessage: {
                            conversation: arr[i].text
                        }
                    }
                }, {
                    quoted: fkon,
                    ephemeralExpiration: m.expiration
                });
            }
        }

        class Character {
            constructor(name, health) {
                this.name = name;
                this.health = health;
            }

            isAlive() {
                return this.health > 0;
            }

            takeDamage(amount) {
                this.health -= amount;
                if (this.health < 0) this.health = 0;
            }

            heal(amount) {
                this.health += amount;
            }
        }

        switch (m.command) {
            case 'teleport': {
                if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit);
                if (user.inventory.obsidian < 1) return m.reply(`Teleport gagal. Pastikan kamu memiliki *obsidian block* untuk membuat portal.\n- craft obsidian block dengan ketik \`${m.prefix}craft obsidian 1\``)
                if (user.inventory.obsidian < 14) return m.reply(`Teleport gagal. Pastikan *obsidian block* kamu cukup untuk membuat portal.\n- craft obsidian block dengan ketik \`${m.prefix}craft obsidian 1\``)
                if (!m.text) return m.reply(`Mau teleport kemana?\n${func.example(m.cmd, 'overworld')}\n\n*List World*:\n- Overworld\n- Netherworld\n- EndWorld`)
                let worldnya;
                if (/^overworld$/i.test(m.text)) {
                    worldnya = 'Overworld';
                } else if (/^netherworld$/i.test(m.text)) {
                    worldnya = 'Netherworld';
                } else if (/^endworld$/i.test(m.text)) {
                    worldnya = 'Endworld';
                } else {
                    let caption = `World yang kamu input tidak valid!\n\n*List World*:\n- Overworld\n- Netherworld\n- EndWorld`
                    return anya.reply(m.chat, caption, m, {
                        expiration: m.expiration
                    })
                }
                if (user.currentWorld === worldnya) return m.reply(`Anda sudah berada di \`${worldnya}\`.`);
                if (user.level < 120 && worldnya === 'Netherworld') {
                    return m.reply('Level tidak cukup untuk teleport ke Netherworld.');
                } else if (user.level < 250 && worldnya === 'Endworld') {
                    return m.reply('Level tidak cukup untuk teleport ke The End.');
                }
                user.currentWorld = worldnya;
                user.inventory.obsidian -= 14;
                if (user.inventory.obsidian < 0) user.inventory.obsidian = 0;
                return await loadingTeleport(worldnya);
            }
            break
            case 'mining': {
                if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit);
                const cooldown = 900000;
                let timers = (cooldown - (new Date - user.lastmining))
                // if (user.health < 80) return m.reply(`Butuh minimal *❤️ 80 Health* untuk ${m.command}!\n\nKetik *${m.prefix}heal* untuk menambah health.\nAtau *${m.prefix}use potion* untuk menggunakan potion.`)
                if (new Date - user.lastmining <= cooldown) return m.reply(`Kamu sudah menambang, mohon tunggu *${func.clockString(timers)}*`)
                if (user.currentWorld === 'Overworld') {
                    if (!m.text) return m.reply(`Mau mining di kedalaman berapa?\n${func.example(m.cmd, '100')}`)
                    let depth = parseInt(m.args[0]);
                    if (depth <= 100 && depth >= -128) {
                        if (depth <= 100 && depth >= -64) {
                            // Overworld (Kedalaman 100 hingga -64)
                            let coal = ranNumb(10, 40) // 40%
                            let iron = ranNumb(10, 25) // 25%
                            let gold = ranNumb(1, 10) // 10%
                            let copper = ranNumb(5, 15) // 15%
                            let redstone = ranNumb(5, 15) // 5%
                            let lapislazuli = pickRandom([0, 1, 0, 1, 0, 1, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8, 0]) // 3%
                            let diamond = pickRandom([0, 1, 0, 1, 0, 1, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 7, 0, 8, 0]) // 1%
                            let emerald = pickRandom([0, 1, 0, 1, 0, 1, 2, 0, 3, 0, 4, 0, 5, 0, 6, 0, 0, 0]) // 1%
                            // menambahkan item hasil mining kedalam inventory user
                            user.inventory.coal += parseInt(coal);
                            user.inventory.iron += parseInt(iron);
                            user.inventory.gold += parseInt(gold);
                            user.inventory.copper += parseInt(copper);
                            user.inventory.redstone += parseInt(redstone);
                            user.inventory.lapis_lazuli += parseInt(lapislazuli);
                            user.inventory.diamond += parseInt(diamond);
                            user.inventory.emerald += parseInt(emerald);
                            let caption = `Hasil mining di \`${user.currentWorld}\` pada kedalaman *${depth}*

Anda menemukan:
- Coal: ${coal}
- Iron: ${iron}
- Copper: ${copper}
- Gold: ${gold}
- Redstone: ${redstone}
- Lapis Lazuli: ${lapislazuli}
- Diamond: ${diamond}
- Emerald: ${emerald}`;
                            anya.reply(m.chat, `_Sedang mining di \`${user.currentWorld}\` pada kedalaman ${depth}..._`, m, {
                                expiration: m.expiration
                            })
                            user.lastmining = new Date * 1;
                            setTimeout(() => {
                                anya.reply(m.chat, caption, m, {
                                    expiration: m.expiration
                                });
                            }, setting.gamewaktu * 1000)
                        } else if (depth < -64 && depth >= -128) {
                            // Deepslate Variants (Kedalaman -64 hingga -128)
                            let coal = ranNumb(10, 35) // 35%
                            let iron = ranNumb(10, 25) // 25%
                            let gold = ranNumb(1, 15) // 15%
                            let redstone = ranNumb(5, 10) // 10%
                            let diamond = pickRandom([0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 3, 4, 5, 6, 7, 8, ]) // 10%
                            let emerald = pickRandom([0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 2, 3, 4, 5]) // 5%
                            // menambahkan item hasil mining kedalam inventory user
                            user.inventory.coal += parseInt(coal);
                            user.inventory.iron += parseInt(iron);
                            user.inventory.gold += parseInt(gold);
                            user.inventory.redstone += parseInt(redstone);
                            user.inventory.diamond += parseInt(diamond);
                            user.inventory.emerald += parseInt(emerald);
                            let caption = `Hasil mining di \`${user.currentWorld}\` *(Deepslate Variants)* pada kedalaman *${depth}*

Anda menemukan:
- Coal (Deepslate): ${coal}
- Iron (Deepslate): ${iron}
- Gold (Deepslate): ${gold}
- Redstone (Deepslate): ${redstone}
- Diamond (Deepslate): ${diamond}
- Emerald (Deepslate): ${emerald}`;
                            anya.reply(m.chat, `_Sedang mining di \`${user.currentWorld}\` *(Deepslate Variants)* pada kedalaman ${depth}..._`, m, {
                                expiration: m.expiration
                            })
                            user.lastmining = new Date * 1;
                            setTimeout(() => {
                                anya.reply(m.chat, caption, m, {
                                    expiration: m.expiration
                                });
                            }, setting.gamewaktu * 1000)
                        }
                    } else {
                        return m.reply('Kedalaman tidak valid! Pilih antara 100 dan -128.');
                    }
                } else if (user.currentWorld === 'Netherworld') {
                    let depth = ranNumb(0, 117); // random kedalaman
                    let quartz = ranNumb(10, 50) // 50%
                    let goldnugget = ranNumb(10, 30) // 30%
                    let ancientdebris = ranNumb(5, 20) // 20%
                    // menambahkan item hasil mining kedalam inventory user
                    user.inventory.quartz += parseInt(quartz);
                    user.inventory.gold_nugget += parseInt(goldnugget);
                    user.inventory.ancient_debris += parseInt(ancientdebris);
                    let caption = `Hasil mining di \`${user.currentWorld}\` pada kedalaman *${depth}*

Anda menemukan:
- Quartz: ${quartz}
- Gold Nugget: ${goldnugget}
- Ancient Debris: ${ancientdebris}`
                    anya.reply(m.chat, `_Sedang mining di \`${user.currentWorld}\` pada kedalaman ${depth}..._`, m, {
                        expiration: m.expiration
                    })
                    user.lastmining = new Date * 1;
                    setTimeout(() => {
                        anya.reply(m.chat, caption, m, {
                            expiration: m.expiration
                        });
                    }, setting.gamewaktu * 1000)
                } else {
                    return m.reply(`Tidak bisa mining di The End!\n- silahkan teleport terlebih dahulu ke \`Overworld\` atau \`Netherworld\``);
                }
            }
            break
            case 'fightboss': {
                anya.fightboss = anya.fightboss || {};
                if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit);
                if (!anya.fightboss[m.sender]) {
                    const bossName = user.currentWorld === 'Overworld' ? 'Warden' : user.currentWorld === 'Netherworld' ? 'Wither' : user.currentWorld === 'Endworld' ? 'Ender Dragon' : false;
                    if (!bossName) return m.reply('Tidak ada boss yang bisa dilawan di sini!');
                    const itemSpecial = user.currentWorld === 'Overworld' ? 'katalis_sculk' : user.currentWorld === 'Netherworld' ? 'nether_star' : user.currentWorld === 'Endworld' ? 'ender_egg' : false;
                    const users = new Character(user.name, 100);
                    const boss = new Character(bossName, 100);
                    let fightText = `⚔️ Melawan Boss ${bossName}! HP Anda: ${users.health}, HP Boss: ${boss.health}.
1. Attack
2. Defend
3. Use Item\n
Pilih aksi (1/2/3):`;
                    anya.fightboss[m.sender] = {
                        userId: m.sender,
                        fighting: false,
                        currentWorld: user.currentWorld,
                        bossName: bossName,
                        itemSpecial: itemSpecial,
                        user: users,
                        boss: boss,
                        hitBoss: 0,
                    }
                    await loadingFightBoss(bossName, fightText)
                    anya.fightboss[m.sender].fighting = true;
                } else if (anya.fightboss[m.sender] && anya.fightboss[m.sender].fighting) {
                    return anya.reply(m.chat, 'Masih ada pertempuran yang belum di selesaikan.', m, {
                        expiration: m.expiration
                    })
                }
            }
            break
        }
    },
    main: async (m, {
        func,
        anya,
        fkon
    }) => {
        anya.fightboss = anya.fightboss || {};

        if (m.budy && anya.fightboss[m.sender] && anya.fightboss[m.sender].fighting) {
            const action = m.budy.trim();
            const chatId = m.chat;
            const userId = m.sender;
            if (!/^(1|2|3)$/.test(action)) return

            async function gameLoop(action, chatId, userId) {
                let {
                    currentWorld,
                    bossName,
                    itemSpecial,
                    user,
                    boss,
                    hitBoss,
                } = anya.fightboss[userId];
                const currentTime = Date.now();

                // Cek apakah pemain masih dalam cooldown
                if (lastActionTime[userId] && (currentTime - lastActionTime[userId] < cooldownTime)) {
                    return anya.reply(chatId, `Tunggu beberapa saat sebelum melakukan aksi lagi!`, m, {
                        expiration: m.expiration,
                    });
                }

                // Update waktu aksi terakhir
                lastActionTime[userId] = currentTime;
                // Tambahkan variabel untuk mengontrol aksi
                let actionProcessed = false;

                if (user.isAlive() && boss.isAlive()) {
                    switch (action) {
                        case '1':
                            if (!actionProcessed) {
                                actionProcessed = true;
                                var key = await anya.reply(chatId, `${user.name} memilih \`Attack\``, m, {
                                    expiration: m.expiration
                                });
                                let damageToBoss = Math.floor(Math.random() * 21) + 5; // Damage acak antara 5 dan 25
                                boss.takeDamage(damageToBoss);
                                await func.delay(2000);
                                anya.sendMessage(chatId, {
                                    text: `${boss.name} menerima damage ${damageToBoss}. HP Boss sekarang: ${boss.health}`,
                                    ...(key ? {
                                        edit: key
                                    } : {})
                                }, {
                                    quoted: m,
                                    ephemeralExpiration: m.expiration
                                });
                            }
                            break;
                        case '2':
                            if (!actionProcessed) {
                                actionProcessed = true;
                                var key = await anya.reply(chatId, `${user.name} memilih \`Defend\``, m, {
                                    expiration: m.expiration
                                });
                                let bossDamage = Math.floor(Math.random() * 11) + 5; // Damage acak antara 5 dan 15
                                let reducedDamage = Math.floor(bossDamage / 2);
                                user.takeDamage(reducedDamage);
                                hitBoss += reducedDamage;
                                await func.delay(2000);
                                anya.sendMessage(chatId, {
                                    text: `${boss.name} menyerang. Damage berkurang menjadi ${reducedDamage}. HP Anda sekarang: ${user.health}`,
                                    ...(key ? {
                                        edit: key
                                    } : {})
                                }, {
                                    quoted: m,
                                    ephemeralExpiration: m.expiration
                                });
                            }
                            break;
                        case '3':
                            if (!actionProcessed) {
                                actionProcessed = true;
                                var key = await anya.reply(chatId, `${user.name} memilih \`Use Item\``, m, {
                                    expiration: m.expiration
                                });
                                user.heal(20);
                                await func.delay(2000);
                                anya.sendMessage(chatId, {
                                    text: `${user.name} menggunakan item. HP Anda sekarang: ${user.health}`,
                                    expiration: m.expiration,
                                    ...(key ? {
                                        edit: key
                                    } : {})
                                }, {
                                    quoted: m,
                                    ephemeralExpiration: m.expiration
                                });
                            }
                            break;
                        default:
                            anya.reply(chatId, `Aksi tidak valid. Silakan pilih 1, 2, atau 3.`, m, {
                                expiration: m.expiration,
                            });
                            return; // Menghentikan eksekusi fungsi jika aksi tidak valid
                    }

                    // Setelah aksi pemain, jika boss masih hidup, boss menyerang
                    if (boss.isAlive() && actionProcessed) {
                        await func.delay(1000);
                        let key = await anya.reply(chatId, `${boss.name} menyerang kembali!`, null, {
                            expiration: m.expiration
                        });
                        let bossDamage = Math.floor(Math.random() * 15) + 10; // Damage acak antara 10 dan 25
                        user.takeDamage(bossDamage);
                        hitBoss += bossDamage;
                        await func.delay(2000);
                        anya.sendMessage(chatId, {
                            text: `${user.name} menerima damage ${bossDamage}. HP Anda sekarang: ${user.health}.
1. Attack
2. Defend
3. Use Item\n
Pilih aksi (1/2/3):`,
                            ...(key ? {
                                edit: key
                            } : {})
                        }, {
                            quoted: m,
                            ephemeralExpiration: m.expiration
                        });
                    }

                    // Cek kondisi kalah
                    if (!user.isAlive()) {
                        let userData = global.db.users[userId];
                        let itemList = ['sword', 'bow', 'armor'];
                        for (let item of itemList) {
                            if (userData.inventory[item] == undefined) continue;
                            if (userData.inventory[item] > 0) userData.inventory[item] -= 1;
                        }
                        userData.health -= hitBoss;
                        if (userData.health < 0) userData.health = 0;
                        let caption = `💀 Anda kalah dalam pertarungan melawan **${bossName}!...**
❌ Kerugian:
- 🩸 HP berkurang ${hitBoss}!
- 🎒 ${itemList.map(replaceItem).join(', ')} hilang dari inventori.
Cobalah lagi nanti dengan persiapan lebih baik!`;
                        setTimeout(() => {
                            anya.reply(chatId, caption, fkon, {
                                expiration: m.expiration,
                            });
                        }, cooldownTime);
                        delete anya.fightboss[userId];
                        return; // Menghentikan eksekusi fungsi jika kalah
                    }

                    // Cek kondisi menang
                    if (!boss.isAlive()) {
                        let userData = global.db.users[userId];
                        let specialItem = {
                            'katalis_sculk': 'Katalis Sculk',
                            'nether_star': 'Nether Star',
                            'ender_egg': 'Ender Egg'
                        } [itemSpecial];
                        let overworldList = [
                            'coal',
                            'iron',
                            'gold',
                            'copper',
                            'redstone',
                            'lapis_lazuli',
                            'diamond',
                            'emerald'
                        ];
                        let netherworldList = [
                            'quartz',
                            'gold_nugget',
                            'ancient_debris'
                        ];
                        let itemList = [];
                        let hadiah = 0;
                        let exp = 0;
                        if (currentWorld === 'Overworld') {
                            itemList = overworldList;
                            hadiah = ranNumb(70, 120);
                            exp = ranNumb(250, 500);
                        } else if (currentWorld === 'Netherworld') {
                            itemList = netherworldList;
                            hadiah = ranNumb(70, 120);
                            exp = ranNumb(250, 500);
                        } else if (currentWorld === 'Endworld') {
                            itemList = [...overworldList, ...netherworldList];
                            hadiah = ranNumb(100, 150);
                            exp = ranNumb(500, 1000);
                        }
                        for (let item of itemList) {
                            if (userData.inventory[item] == undefined) continue;
                            if (userData.inventory[item] > 0) userData.inventory[item] += parseInt(hadiah);
                        }
                        userData.inventory[itemSpecial] += 1;
                        userData.exp += exp;
                        let caption = `🎉 Anda berhasil mengalahkan **${bossName}!**
🎁 Hadiah:
- 🪨 ${itemList.map(replaceItem).join(', ')} Ore
- 🌟 ${specialItem}
- 💪 EXP bertambah ${exp}!
Boss akan muncul kembali dalam waktu 24 jam.`;
                        setTimeout(() => {
                            anya.reply(chatId, caption, fkon, {
                                expiration: m.expiration,
                            });
                        }, cooldownTime);
                        delete anya.fightboss[userId];
                        return; // Menghentikan eksekusi fungsi jika menang
                    }
                }
            }

            await gameLoop(action, chatId, userId);
        }

        async function performRaid(groupId, findGroups) {
            let members = findGroups.participants.filter(item => global.db.users[item.id] != undefined && global.db.users[item.id].register).map(item => item.id);
            let jid = members[Math.floor(Math.random() * members.length)]
            let user = global.db.users[jid];
            let kolam = ranNumb(10, 60)
            let kandang = ranNumb(5, 20)
            let amount = ranNumb(20000, 90000)
            // kandang list
            let kandangList = [
                'banteng',
                'harimau',
                'gajah',
                'kambing',
                'panda',
                'buaya',
                'kerbau',
                'sapi',
                'monyet',
                'babihutan',
                'babi',
                'ayam',
            ]
            // kolam list
            let kolamList = [
                'orca',
                'paus',
                'lumba',
                'hiu',
                'ikan',
                'lele',
                'bawal',
                'nila',
                'kepiting',
                'lobster',
                'gurita',
                'cumi',
                'udang',
            ]
            // mengurangi item user pada list kandang
            for (let item of kandangList) {
                if (user[item] == undefined) continue;
                if (user[item] > 0) user[item] -= kandang;
            }
            // mengurangi item user pada list kolam
            for (let item of kolamList) {
                if (user[item] == undefined) continue;
                if (user[item] > 0) user[item] -= kolam;
            }
            user.money -= amount;
            let itemList = [...kandangList, ...kolamList];
            let text1 = `> ⚔️ **RAID ALERT!** ⚔️
> Sekelompok pillager menyerbu *${user.name}* dan berhasil mencuri:
> - 💰 *Rp${func.formatNumber(amount)}*
> - 🎒 *${itemList.map(replaceItem).join(', ')}* dari inventori!
> Bersiaplah lebih baik untuk serangan berikutnya!`
            let text2 = `> 🔥 **Pillager Menyerang!** 🔥
> Mereka telah mencuri:
> - 💰 Rp${func.formatNumber(amount)}
> - 🎒 Barang: ${itemList.map(replaceItem).join(', ')}
> Waktunya balas dendam sebelum 24 jam lagi!`
            let text3 = `> 🏹 **Serangan Tiba-tiba!**
> Tanpa ampun, pillager mengambil dari inventori:
> - 💰 Rp${func.formatNumber(amount)}
> - 🎒 Barang: ${itemList.map(replaceItem).join(', ')}
> Semoga mereka tidak datang kembali segera!`
            let text4 = `> 💀 **RAID!** 💀
> ${user.name} kehilangan:
> - 💰 Rp${func.formatNumber(amount)}
> - 🎒 Barang: ${itemList.map(replaceItem).join(', ')}
> Mereka datang lagi 24 jam kemudian... Hati-hati!`
            const key = await anya.reply(groupId, text1, null, {
                expiration: m.expiration
            })
            const arr = [{
                    text: text2,
                    timeout: 1454
                },
                {
                    text: text3,
                    timeout: 1454
                },
                {
                    text: text4,
                    timeout: 1454
                }
            ]

            for (let i = 0; i < arr.length; i++) {
                await new Promise(resolve => setTimeout(resolve, arr[i].timeout));
                await anya.relayMessage(groupId, {
                    protocolMessage: {
                        key: key,
                        type: 14,
                        editedMessage: {
                            conversation: arr[i].text
                        }
                    }
                }, {
                    quoted: null,
                    ephemeralExpiration: 0
                });
            }
        }

        const checkAutoRaid = async () => {
            let now = Date.now();
            let duration = 24 * 60 * 60 * 1000;
            for (let [groupId, groupData] of Object.entries(global.db.groups)) {
                try {
                    // Cek apakah waktu sekarang sudah lebih dari 24 jam setelah raid terakhir
                    if (groupData.lastraid && groupData.lastraid != 0 && now >= groupData.lastraid + duration) {
                        const getGroups = Object.values(await anya.groupFetchAllParticipating());
                        const findGroups = getGroups.find(item => item.id === groupId);
                        if (findGroups) {
                            // Jalankan function raid
                            await performRaid(groupId, findGroups);
                        }
                        // Reset last raid time ke waktu sekarang
                        groupData.lastraid = now;
                    }
                } catch (error) {
                    console.log(error);
                    // Jika terjadi error, reset last raid time
                    groupData.lastraid = now;
                }
            }
        }
        // setInterval(checkAutoRaid, 30000)
    },
}

function pickRandom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function ranNumb(min, max = null) {
    if (max !== null) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    } else {
        return Math.floor(Math.random() * min) + 1
    }
}

function replaceItem(item) {
    return item.replace(/[_]/g, '')
}