const { areJidsSameUser } = require('@whiskeysockets/baileys');

exports.run = {
usage: ['topexp'],
category: 'games',
async: async (m, { func, anya }) => {
let uexp = Object.entries(global.db.users).map(([key, value]) => {return {...value, jid: key}})
let sortedbalance = uexp.map(func.toNumber('exp')).sort(func.sort('exp'))
let usersexp = sortedbalance.map(func.enumGetKey)
let txt = `Kamu Top *${usersexp.indexOf(m.sender) + 1}* Exp dari *${usersexp.length}* Users\n`
txt += sortedbalance.slice(0, 40).map(({ jid, exp }, i) => `${i + 1}. ${m.isGc && m.members.some(x => areJidsSameUser(jid, x.id)) ? (global.db.users[jid]?.name || anya.getName(jid)).replaceAll('\n', '\t') : '@' + jid.split('@')[0]} => $${func.rupiah(exp)}`).join('\n')
anya.reply(m.chat, txt, m, {
expiration: m.expiration
})
}
}