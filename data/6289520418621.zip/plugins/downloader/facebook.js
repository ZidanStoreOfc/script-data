exports.run = {
usage: ['facebook'],
hidden: ['fbdl'],
use: 'link facebook',
category: 'downloader',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(`Masukkan URL!\n\nContoh: *${m.cmd} https://www.facebook.com/watch/?v=1393572814172251*`)
if (!m.args[0].match(/(?:https?:\/\/(web\.|www\.|m\.)?(facebook|fb)\.(com|watch)\S+)?$/)) return m.reply(global.mess.error.url)
if (m.args[0].includes('https://l.facebook.com/l.php?u=')) return m.reply(global.mess.error.url)
anya.sendReact(m.chat, '🕒', m.key)
await fetch('https://apisku.biz.id/api/downloader/facebook', {
method: 'POST',
headers: {
'accept': '*/*',
'api_key': 'free',
'Content-Type': 'application/json'
},
body: JSON.stringify({ text: m.args[0] })
})
.then(response => response.json())
.then(async res => {
if (!res.status) return m.reply(global.mess.error.api)
await anya.sendMedia(m.chat, res.data.hd, m);
})
.catch(err => {
console.error(err);
m.reply(global.mess.error.api);
});
},
premium: true,
limit: true
}