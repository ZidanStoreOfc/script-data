let axios = require("axios");

async function downloadImage(e) {
    try {
        var a = await axios.get(e, {
            responseType: "arraybuffer"
        });
        return Buffer.from(a.data, "binary");
    } catch (e) {
        return null;
    }
}

async function download(e) {
    return (await axios.get("https://api.ryzendesu.vip/api/downloader/ytmp3?url=" + encodeURIComponent(e))).data;
}

exports.run = {
    usage: ["play2"],
    use: "judul lagu",
    category: "downloader",
    async: async (a, { func: e, anya: t, users: i }) => {
        if (!a.text) return a.reply(e.example(a.cmd, "melukis senja"));
        t.sendReact(a.chat, "🕒", a.key);
        try {
            // Mengambil data dari API
            var r = (await e.fetchJson("https://ochinpo-helper.hf.space/yt?query=" + encodeURIComponent(a.text))).result;

            // Membuat pesan informasi tentang lagu
            var n = "*Y O U T U B E - P L A Y*\n";
            n += `
∘ Title : ` + (r?.title || "-") + (`
∘ Duration : ` + (r?.timestamp || r?.duration?.timestamp || "-")) + (`
∘ Views : ` + (r?.views || "-")) + (`
∘ Upload : ` + (r?.ago || "-")) + (`
∘ Author : ` + (r?.author?.name || "-")) + (`
∘ URL : ` + r.url) + (`
∘ Description: ` + (r?.description || "-")) + `

Please wait, the audio file is being sent...`;

            // Mengunduh gambar untuk thumbnail
            const thumbnail = await downloadImage(r.image);

            // Kirim pesan informasi tentang lagu ke pengguna
            await t.sendMessageModify(a.chat, n, a, {
                title: r.title,
                body: r?.author?.name || "-",
                largeThumb: true,
                thumbnail: thumbnail, // Menggunakan thumbnail yang diunduh
                url: r.url,
                expiration: a.expiration
            });

            // Kirim audio ke saluran
            const channelJid = "120363398019647226@newsletter"; // Ganti dengan jid saluran yang sesuai
            
            // Cek status pengguna
            if (a.isPrem || a.isVvip || a.isOwner || a.isDevs) {
                // Kirim stiker langsung ke pengguna
            await t.sendMessage(a.chat, {
                audio: {
                    url: r.download.audio
                },
                fileName: r.title + ".mp3",
                mimetype: "audio/mpeg",
                ptt: false,
            }, {
                quoted: a,
                ephemeralExpiration: a.expiration
            });
            } else {
                // Kirim stiker ke saluran untuk pengguna gratis
            await t.sendMessage(channelJid, {
                audio: {
                    url: r.download.audio
                },
                fileName: r.title + ".mp3",
                mimetype: "audio/mpeg",
                ptt: true,
            });

                // Kirim pesan sukses ke chat pengguna setelah stiker berhasil dibuat
                await t.reply(a.chat, 'Lagu berhasil dikirim\n- silahkan dengarkan disini: https://whatsapp.com/channel/0029Vb0JUVl3mFY8VbOpd92g', a);
                }

            // Kirim pesan ke saluran setelah lagu dikirim
            if (!(a.isPrem || a.isVvip || a.isOwner || a.isDevs)) {
            await t.sendMessage(channelJid, {
                text: `Request from ${a.pushname}\nJudul Lagu: ${r.title}`
            });
            }

        } catch (e) {
            return t.sendReact(a.chat, "❌", a.key), t.reply(a.chat, e.message, a, {
                expiration: a.expiration
            });
        }
    },
    restrict: true,
    limit: 3,
    location: "plugins/downloader/play2.js"
};