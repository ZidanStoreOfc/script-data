exports.run={usage:["mediafire"],hidden:["mfire","mfdl"],use:"link mediafire",category:"downloader",async:async(e,{func:i,anya:a})=>{if(!e.text)return e.reply(i.example(e.cmd,"https://www.mediafire.com/file/a61862y1tgvfiim/ZackBotMans+(+Versi+1.0.1+).zip/file"));if(!e.args[0].includes("mediafire.com"))return e.reply(global.mess.error.url);a.sendReact(e.chat,"🕒",e.key);i=await i.fetchJson("https://api.siputzx.my.id/api/d/mediafire?url="+e.args[0]);if(!i.status)return e.reply("Something when wrong!");var i=i.data,t=`乂  *MEDIAFIRE DOWNLOADER*
`;t+=`
◦ File Name: `+i.fileName,a.sendMessage(e.chat,{text:t+(`
◦ File Size: `+i.fileSize)+`

_Please wait media is being sent..._`},{quoted:e,ephemeralExpiration:e.expiration}),await a.sendMedia(e.chat,i.downloadLink,e,{caption:global.mess.ok,fileName:i.fileName,expiration:e.expiration})},limit:3};