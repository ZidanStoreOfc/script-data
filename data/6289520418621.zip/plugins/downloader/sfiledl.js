const axios = require('axios');
const cheerio = require('cheerio');
const FileType = require('file-type');
exports.run = {
usage: ['sfiledl'],
hidden: [],
use: 'link sfile',
category: 'downloader',
async: async (m, { func, anya }) => {
const sfileLink = m.text.match(/https?:\/\/(www\.)?sfile\.mobi\/[^\s]+/);
if (!sfileLink) return m.reply(func.example(m.cmd, 'https://sfile.mobi/example-file.zip'));
anya.sendReact(m.chat, '🕒', m.key);
try {
const result = await sfile.download(sfileLink[0]);
if (result.status === 'error') {
return m.reply(result.message || global.mess.error.api);
}
const { filename, filesize, mimetype, result: fileData } = result.data;
let txt = `乂  SFILE DOWNLOADER*\n\n` +
`◦ File Name: ${filename}\n` +
`◦ File Size: ${filesize}\n` +
`◦ File Type: ${mimetype}\n\n` +
`Download URL: ${fileData.directLink}\n\n` +
`_File is being sent..._`;
await anya.reply(m.chat, txt, m);
const fileType = await FileType.fromBuffer(fileData.buffer);
const detectedMimeType = fileType ? fileType.mime : 'application/octet-stream';
if (detectedMimeType.startsWith('image/')) {
await anya.sendImage(m.chat, fileData.buffer, filename, global.mess.ok, m);
} else if (detectedMimeType.startsWith('video/')) {
await anya.sendVideo(m.chat, fileData.buffer, false, global.mess.ok, m);
} else if (detectedMimeType.startsWith('audio/')) {
await anya.sendAudio(m.chat, fileData.buffer, false, m);
} else {
await anya.sendDocument(m.chat, fileData.buffer, filename, global.mess.ok, m, { mimetype: detectedMimeType });
}
} catch (error) {
console.error(error);
m.reply(global.mess.error.api);
}
},
premium: false,
limit: 3
};
const sfile = {
download: async function(url) {
const headers = {
'referer': url,
'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
'accept-language': 'en-US,en;q=0.9',
'user-Agent': 'Postify/1.0.0',
};
try {
const response = await axios.get(url, { headers });
headers.Cookie = response.headers['set-cookie'].map(cookie => cookie.split(';')[0]).join('; ');
const $ = cheerio.load(response.data);
const filename = $('h1.intro').text().trim();
const mimetype = $('.list').text().match(/ - (.+?)$/)?.[1] || '';
const downloadLink = $('#download').attr('href');
if (!downloadLink) return { status: 'error', message: 'Download link tidak ditemukan!' };
headers.Referer = downloadLink;
const final = await axios.get(downloadLink, { headers });
const $final = cheerio.load(final.data);
const directLink = $final('#download').attr('href');
const key = final.data.match(/&k='\+(.*?)';/)?.[1]?.replace(`'`, '');
const filesize = $final('.w3-text-teal').text().match(/\((.+?)\)/)?.[1] || '';
const result = directLink + (key ? `&k=${key}` : '');
if (!result) return { status: 'error', message: 'Direct Link Download tidak ditemukan!' };
const fileData = await this.getFile(result, url);
return { 
status: 'success', 
code: 200, 
data: { 
filename, 
filesize, 
mimetype, 
result: { 
directLink: result,
...fileData
} 
} 
};
} catch (error) {
return { status: 'error', code: 500, message: error.message };
}
},
getFile: async function(url, referer) {
try {
const response = await axios.get(url, {
headers: {
'Referer': referer,
'User-Agent': 'Postify/1.0.0'
},
responseType: 'arraybuffer'
});
return {
mimeType: response.headers['content-type'],
buffer: Buffer.from(response.data)
};
} catch (error) {
throw error;
}
}
};