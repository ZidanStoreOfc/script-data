exports.run = {
    usage: ['instagram'],
    hidden: ['igdl', 'ig'],
    use: 'link instagram',
    category: 'downloader',
    async: async (m, {
        func,
        anya
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA=='));
        if (!m.args[0].match(/https:\/\/www.instagram.com\/(p|reel|tv)/gi)) return m.reply(`*Link salah! Perintah ini untuk mengunduh postingan ig/reel/tv, bukan untuk highlight/story!*\n\ncontoh:\n${m.cmd} https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA==`)
        await anya.sendReact(m.chat, '🕒', m.key)
        const result = await func.fetchJson(`https://lulli.vercel.app/api/snapsave?url=${m.args[0]}`);
        if (!result.status) return m.reply('Terjadi kesalahan.')
        if (result.data.length < 1) return m.reply('Data empty.');
        for (let [index, item] of result.data.entries()) {
            let message = index == 0 ? m : null;
            await anya.sendMedia(m.chat, item.url, m, {
                caption: result.data.length == 1 ? global.mess.ok : '',
                expiration: m.expiration
            })
        }
        await anya.sendReact(m.chat, '✅', m.key)
    },
    location: "plugins/downloader/instagram.js",
    premium: true,
    limit: 5
}