const fs = require('fs'),
    chalk = require('chalk'),
    util = require('util'),
    path = require('path'),
    crypto = require('crypto'),
    moment = require('moment-timezone'),
    phonenumber = require('awesome-phonenumber'),
    baileys = require('@whiskeysockets/baileys'),
    toMs = require('ms'),
    ytdl = require('ytdl-core'),
    axios = require('axios'),
    cheerio = require('cheerio'),
    request = require('request'),
    ms = require('parse-ms'),
    fetch = require('node-fetch');
const {
    exec
} = require('child_process');

exports.run = {
    main: async (m, {
        func,
        anya,
        plugins,
        update,
        store,
        users,
        groups,
        setting,
        week,
        time,
        calender,
        packname,
        author,
        isBanned,
        isPrem,
        quoted,
        mime,
        froms,
        fkon,
        errorMessage
    }) => {
        if (m.budy && m.isDevs) {
            // EVAL & EXEC CODE
            if (/^(x|xx)$/.test(m.command)) {
                let text;
                if (m.command === 'x') text = m.text ? m.text : false
                else if (m.command === 'xx') text = m.quoted && m.quoted.text ? m.quoted.text : m.text ? m.text : false;
                if (!text) return false;
                let evalCmd;
                try {
                    evalCmd = /await/i.test(text) ? eval("(async () => { " + text + " })()") : eval(text)
                    let evaled = await evalCmd;
                    if (typeof evaled !== 'string') evaled = util.inspect(evaled)
                    anya.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (error) {
                    anya.sendMessage(m.chat, {
                        text: util.format(error)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else if (m.command === '=>') {
                if (!m.text) return false;
                try {
                    let evaled = await eval(`(async () => { return ${m.text} })()`)
                    anya.sendMessage(m.chat, {
                        text: util.format(evaled)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } catch (e) {
                    anya.sendMessage(m.chat, {
                        text: util.format(e)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else if (m.command === '$') {
                if (!m.text) return false;
                anya.sendReact(m.chat, '🕒', m.key)
                exec(m.text, (err, stdout) => {
                    if (err) return anya.sendMessage(m.chat, {
                        text: err.toString()
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                    if (stdout) return anya.sendMessage(m.chat, {
                        text: util.format(stdout)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                })
            }
        }
    },
    devs: true
}

function get(jid) {
    if (jid.endsWith('@g.us')) {
        return global.db.groups[jid]
    } else {
        jid = jid.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
        return global.db.users[jid]
    }
};