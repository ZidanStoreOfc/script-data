exports.run = {
usage: [
'ceksubdo',
'sendngl',
'cekdns',
'scanurl',
],
use: 'url',
category: 'tools',
async: async (m, { func, anya }) => {
const axios = require('axios');
const dns = require('dns');

switch (m.command) {
case 'ceksubdo':{
let text;
if (m.args.length >= 1) {
text = m.args.slice(0).join(" ");
} else if (m.quoted && m.quoted.text) {
text = m.quoted.text;
} else return m.reply(`Input domain web!\n\nContoh :\n${m.cmd} google.com`)
if (text && !func.isUrl(text)) return m.reply(global.mess.error.url);
text = text.replace(/^https?:\/\//, '');
anya.sendReact(m.chat, '🕒', m.key)
try {
let response = await axios.get(`https://crt.sh/?q=${text}&output=json`, {
headers: {
'Content-Type': 'application/json'
}
});
let data = await response.data;
if (data.length == 0) m.reply('Empty data.')
let teks = `*乂 SUBDOMAIN - CHECK*`
let result = [];
for (let i of data) {
i.name_value.split("\n").map((v) => result.push(v));
}
for (let x of [...new Set(result.filter((v) => !v.startsWith("*")))]) {
teks += `\n\n- *Subdo* : ${x}\n- *DNS* :`
let DNS = await dns.promises.resolve4(x).catch(async () => "-" )
var subdomain
subdomain = DNS ? DNS.length : 0
for (let i = 0; i < subdomain; i++) {
teks += `\n- ${DNS[i] ? DNS[i] : "-"}`
}
}
anya.reply(m.chat, teks, m, {
expiration: m.expiration
})
} catch (error) {
console.log(error)
anya.reply(m.chat, String(error), m, {
expiration: m.expiration
})
}
}
break
case 'sendngl':{
if (!m.text) return m.reply(func.example(m.cmd, 'https://ngl.link/denakhtar1 hallo'))
if (!m.text.match('https://ngl.link/')) return m.reply(func.example(m.cmd, 'https://ngl.link/denakhtar1 hallo'))
let [username, ...message] = m.text.split(' ');
if (!(username && message.length > 0)) return m.reply(func.example(m.cmd, 'https://ngl.link/denakhtar1 hallo'))
let usn = username.split('https://ngl.link/')[1]
message = message.join(' ');
let ngl = await axios.post("https://ngl.link/api/submit", `username=${usn}&question=${message}&deviceId=18d7b980-ac6a-4878-906e-087dfec6ea1b&gameSlug=&referrer=`);
m.reply(`_Pesan terkirim..._

ID: ${ngl.data.questionId}
Region: ${ngl.data.userRegion}`)
}
break
case 'cekdns':{
let text;
if (m.args.length >= 1) {
text = m.args.slice(0).join(" ");
} else if (m.quoted && m.quoted.text) {
text = m.quoted.text;
} else return m.reply(`Input domain web!\n\nContoh :\n${m.cmd} google.com`)
if (text && !func.isUrl(text)) return m.reply(global.mess.error.url);
text = text.replace(/^https?:\/\//, '');
anya.sendReact(m.chat, '🕒', m.key)
try {
const options = {
method: 'GET',
headers: {
accept: 'application/json',
'x-apikey': 'd8d56420a997b7372501df999e2fa9b6226c5864ccf509bf142c9f618fdca90c'
}
};
let domain = await func.fetchJson(`https://www.virustotal.com/api/v3/domains/${text}/subdomains?limit=100`, options)
if (domain.data.length == 0) return m.reply('Empty data.')
let teks = `*乂 DOMAIN DNS CHECK*`;
for (let x of domain.data) {
teks += `\n\n*Sub* : ${x.id}
*Type* : ${x.type}
*DNS Record* :`
for (let i of x.attributes.last_dns_records) {
teks += `\n\n- *Type* : ${i.type}
- *TTL* : ${i.ttl}
- *Value* : ${i.value}`;
}
}
anya.reply(m.chat, teks, m, {
expiration: m.expiration
})
} catch (error) {
console.log(error)
anya.reply(m.chat, String(error), m, {
expiration: m.expiration
})
}
}
break
case 'scanurl':{
let text;
if (m.args.length >= 1) {
text = m.args.slice(0).join(" ");
} else if (m.quoted && m.quoted.text) {
text = m.quoted.text;
} else return m.reply(`Input domain web!\n\nContoh :\n${m.cmd} google.com`)
if (text && !func.isUrl(text)) return m.reply(global.mess.error.url);
text = text.replace(/^https?:\/\//, '');
anya.sendReact(m.chat, '🕒', m.key)
let result = await axios.get(`https://urlscan.io/api/v1/search/?q=${text}`)
if (Array.isArray(result.result) && result.result.length == 0) m.reply('Empty data.')
if (result.data.total <= 1) return m.reply('Masukan url yang valid/aktif.')
let teks = `乂 DOMAIN CHECKER\n\n`;
for (let [i, x] of result.data.results.entries()) {
teks += `${i + 1}. *Visibility* : ${x.task.visibility}
- *Method* : ${x.task.method}
- *Country* : ${x.page.country}
- *IP* : ${x.page.ip}
- *Url* : ${x.page.url}
- *Sub Domain* : ${x.page.ptr}\n\n────────────────────\n\n`;
}
anya.reply(m.chat, teks, m, {
expiration: m.expiration
})
}
break
}
},
devs: true
}