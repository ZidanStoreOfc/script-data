const axios = require('axios');

exports.run = {
    usage: ['delacces'],
    hidden: ['dacces'],
    use: 'UserID',
    category: 'owner',
    async: async (m, { func, anya, setting }) => {
        if (!m.isDevs) return m.reply('Fitur ini hanya bisa digunakan oleh Developer.');
        if (!m.args[0]) return m.reply(func.example(m.cmd, 'UserID'));

        const filename = m.args[0].trim() + '.json'; // Menambahkan .json ke nama file

        // URL untuk API GitHub untuk mendapatkan file di folder license
        const url = `https://api.github.com/repos/ZidanStoreOfc/ZIDANSTORE/contents/license/${filename}`;

        // Konfigurasi untuk request
        const config = {
            headers: {
                'Authorization': `token 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`,
                'Accept': 'application/vnd.github.v3+json'
            }
        };

        try {
            // Pertama, ambil informasi file untuk mendapatkan SHA
            const response = await axios.get(url, config);
            const sha = response.data.sha; // Ambil SHA dari file yang ada

            // Data untuk request delete
            const body = {
                message: `Delete ${filename}`,
                sha: sha // Sertakan SHA untuk menghapus file
            };

            // Mengirim request untuk menghapus file
            await axios.delete(url, { headers: config.headers, data: body });
            m.reply(`UserID: ${filename} berhasil dihapus.`);
        } catch (error) {
            console.error(error);
            if (error.response && error.response.status === 404) {
                m.reply(`UserID ${filename} tidak ditemukan.`);
            } else {
                m.reply('Terjadi kesalahan saat menghapus UserID. Pastikan UserID yang Anda masukkan benar.');
            }
        }
    }
};