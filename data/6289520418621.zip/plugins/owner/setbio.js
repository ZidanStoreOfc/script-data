exports.run = {
usage: ['setbio'],
use: 'text',
category: 'owner',
async: async (m, { func, anya }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'Cukup donasi'))
await anya.updateProfileStatus(m.text)
m.reply(`Bio bot successfully changed to : ${m.text}`)
},
owner: true
}