exports.run = {
    usage: ['setmenu'],
    use: 'options',
    category: 'owner',
    async: async (m, {
        func,
        anya,
        setting
    }) => {
        try {
            if (!m.args || !m.args[0]) return m.reply(func.example(m.cmd, '2'))
            if (!['1', '2', '3', '4', '5'].includes(m.args[0])) return m.reply('Style not available.')
            anya.reply(m.chat, `Bot menu successfully set using style *${m.args[0]}*.`, m, {
                expiration: m.expiration
            }).then(() => setting.style = parseInt(m.args[0]))
        } catch (e) {
            anya.reply(m.chat, e.message, m, {
                expiration: m.expiration
            })
        }
    },
    owner: true,
    location: 'plugins/owner/setmenu.js'
}