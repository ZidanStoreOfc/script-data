const fs = require('fs');

exports.run = {
usage: ['savekontak'],
hidden: ['svkontak'],
use: 'groupId',
category: 'owner',
async: async (m, { func, anya }) => {
if (m.isPc && m.text) {
let groupId = m.args[0].trim();
if (!groupId.endsWith('@g.us')) return m.reply(func.example(m.cmd, '120363185217910448@g.us'));
let metadata = global.db.metadata[groupId]
if (typeof metadata === 'undefined') return m.reply('this group not found.')
let participants = metadata.participants.map(x => x.id)
let vcard = '';
let count = 0;
for (let jid of participants) {
count++;
vcard += `BEGIN:VCARD\nVERSION:3.0\nFN:${global.db.users[jid]?.name || await anya.getName(jid)}\nTEL;type=CELL;type=VOICE;waid=${jid.split('@')[0]}:+${jid.split('@')[0]}\nEND:VCARD\n`
} // (?); mengimpor kontak seluruh member - save
let contacts = './database/contacts.vcf'
m.reply('Mengimpor '+ participants.length + ' kontak..')
fs.writeFileSync(contacts, vcard.trim())
await func.delay(2000)
anya.sendMessage(m.chat, {
document: fs.readFileSync(contacts),
mimetype: 'text/vcard', 
fileName: 'Contact.vcf', 
caption: 'Group: *' + metadata.subject + '*\nTotal peserta: *' + participants.length + '*'
}, {quoted: m, ephemeralExpiration: m.expiration})
fs.unlinkSync(contacts)
} else if (m.isGc) {
let participants = m.members.map(x => x.id)
let vcard = '';
let count = 0;
for (let jid of participants) {
count++;
vcard += `BEGIN:VCARD\nVERSION:3.0\nFN:${global.db.users[jid]?.name || await anya.getName(jid)}\nTEL;type=CELL;type=VOICE;waid=${jid.split('@')[0]}:+${jid.split('@')[0]}\nEND:VCARD\n`
} // (?); mengimpor kontak seluruh member - save
let contacts = './database/contacts.vcf'
m.reply('Mengimpor '+ participants.length + ' kontak..')
fs.writeFileSync(contacts, vcard.trim())
await func.delay(2000)
anya.sendMessage(m.chat, {
document: fs.readFileSync(contacts),
mimetype: 'text/vcard', 
fileName: 'Contact.vcf', 
caption: 'Group: *' + m.groupName + '*\nTotal peserta: *' + participants.length + '*'
}, {quoted: m, ephemeralExpiration: m.expiration})
fs.unlinkSync(contacts)
}
},
owner: true
}