exports.run = {
    usage: ['setbadword'],
    use: 'amount',
    category: 'owner',
    async: async (m, {
        func,
        anya,
        setting
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, '15'))
        if (isNaN(m.args[0])) return m.reply('Amount harus berupa angka!')
        let badword = Number(parseInt(m.args[0]));
        if (setting.max_toxic == badword) return m.reply('Max bad word already this.')
        setting.max_toxic = badword;
        m.reply(`Max bad word successfully set to *${badword}*`)
    },
    owner: true
}