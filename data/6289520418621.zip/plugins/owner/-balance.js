exports.run = {
usage: ['subbalance', 'balance-'],
use: 'mention or reply',
category: 'owner',
async: async (m, { func, anya, froms, setting }) => {
if (m.quoted) {
if (!m.text) return m.reply('Input nominalnya.')
let nominal = m.text.replace(/[^0-9]/g, '')
if (isNaN(nominal)) return m.reply('Nominal harus berupa angka.')
let count = nominal.length > 0 ? Math.min(9999999999999999, Math.max(parseInt(nominal), 1)) : Math.min(1)
let user = global.db.users[m.quoted.sender]
if (typeof user == 'undefined') return m.reply('User data not found.')
user.balance -= parseInt(count);
m.reply(`Sukses Mengurangi ${count.rupiah()} Saldo Deposit Ke @${m.quoted.sender.replace(/@.+/, '')}\n- Saldo Deposit Dia Saat Ini: ${user.balance.rupiah()}`)
} else if (m.text) {
const [target, amount] = m.text.split('|');
if (!(target && amount)) return m.reply(`Contoh : ${m.cmd} 62895354291993|1.000.000`)
let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : (target).split('@')[1]) : target
if (isNaN(number)) return m.reply('Invalid number.')
if (number.length > 15) return m.reply('Invalid format.')
let jid = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
let user = global.db.users[jid]
let nominal = amount.replace(/[^0-9]/g, '')
if (typeof user == 'undefined') return m.reply('User data not found.')
if (isNaN(nominal)) return m.reply('Nominal harus berupa angka.')
let count = nominal.length > 0 ? Math.min(9999999999999999, Math.max(parseInt(nominal), 1)) : Math.min(1)
user.balance -= parseInt(count);
m.reply(`Sukses mengurangi ${count.rupiah()} Saldo Deposit ke @${jid.replace(/@.+/, '')}\n- Saldo Deposit dia saat ini: ${user.balance.rupiah()}`)
} else m.reply('Mention or Reply chat target.')
},
owner: true
}