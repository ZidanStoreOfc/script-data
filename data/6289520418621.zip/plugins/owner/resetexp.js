exports.run = {
    usage: ['resetexp'],
    use: 'no arguments',
    category: 'owner',
    async: async (m, { func, anya, froms, setting }) => {
        // Ambil semua user dari database
        let users = global.db.users;
        
        // Reset balance semua user jadi 0
        for (let jid in users) {
            users[jid].exp = 0;
        }
        
        m.reply('Sukses! Semua exp user telah direset menjadi 0. 🎉');
    },
    devs: true
}