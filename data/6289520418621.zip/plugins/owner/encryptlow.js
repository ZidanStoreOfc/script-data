const jsobfus = require('javascript-obfuscator');
const axios = require('axios');
exports.run = {
usage: ['encryptlow'],
hidden: ['enclow'],
use: 'kode',
category: 'owner',
async: async (message, { func, anya }) => {
let code = message.text || message.quoted?.text;
if (!code) return message.reply('Masukkan kode yang ingin dienkripsi atau balas pesan yang berisi kode.');
anya.sendReact(message.chat, '🕒', message.key);
let obfuscated = await obfusLow(code);
if (obfuscated.status !== 200) {
return message.reply(obfuscated.message);
}
if (obfuscated.result.length > 60000) {
let pasteResponse = await createPaste(obfuscated.result);
let pesan = formatResponse(pasteResponse);
return message.reply(pesan);
}
message.reply(obfuscated.result);
},
devs: true
};
async function obfusLow(code) {
return new Promise((resolve, reject) => {
try {
const options = {
compact: true,
controlFlowFlattening: false,
deadCodeInjection: false,
debugProtection: false,
disableConsoleOutput: false,
identifierNamesGenerator: 'mangled',
log: true,
numbersToExpressions: false,
renameGlobals: false,
selfDefending: false,
simplify: true,
splitStrings: false,
stringArray: false,
transformObjectKeys: false,
unicodeEscapeSequence: false
};
const obfuscationResult = jsobfus.obfuscate(code, options);
const result = {
status: 200,
result: obfuscationResult.getObfuscatedCode()
};
resolve(result);
} catch (error) {
const errorResult = {
status: 400,
message: String(error)
};
resolve(errorResult);
}
});
}
async function createPaste(content) {
const data = {
key: "abFFSw5uEbwkh1APp0hRTbwXgU4B9DZZwf7rjRPZE",
description: "Paste created via API",
sections: [{ name: "Section 1", syntax: "text", contents: content }],
expires: "1w"
};
try {
const response = await axios.post("https://api.paste.ee/v1/pastes", data, {
headers: {
"Content-Type": "application/json",
"X-Auth-Token": "abFFSw5uEbwkh1APp0hRTbwXgU4B9DZZwf7rjRPZE"
}
});
const result = response.data;
const rawUrl = result.link.replace('/p/', '/r/') + "/0";
return result ? 
{ status: 0, original: result.link, raw: rawUrl, expires: data.expires } : 
{ status: 1, original: null, raw: null, error: "Failed to create paste" };
} catch (error) {
return logError(error);
}
}
function logError(error) {
console.error("[ERROR]", error);
return {
status: 1,
original: null,
raw: null,
error: error.response ? error.response.data : error.message
};
}
function formatResponse(response) {
return response.status === 0 ? 
`${response.raw}` :
`*Error:* ${response.error}`;
}