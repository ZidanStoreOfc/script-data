exports.run = {
    usage: ['dechtml'],
    hidden: ['decodehtml'],
    use: 'reply encoded text',
    category: 'owner',
    async: async (m, { anya, quoted }) => {
        // Ambil teks dari pesan yang dibalas
        let text;
        if (quoted && quoted.text) {
            text = quoted.text;
        } else {
            return m.reply("*Silakan balas pesan yang berisi teks HTML yang ingin didekode.*");
        }

        // Fungsi untuk mendekode teks dari format hexadecimal
        const decodeHTML = (html) => {
            return html.replace(/%([0-9A-F]{2})/g, (match, p1) => {
                return String.fromCharCode(parseInt(p1, 16));
            }).replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
        };

        // Dekode teks HTML
        const decodedText = decodeHTML(text);

        // Kirim hasil
        await anya.reply(m.chat, decodedText, m);
    },
    devs: true
};