const groupChatId = '120363347494579697@g.us'; // ID grup untuk mengirim pemberitahuan

exports.run = {
    usage: ['autogempa'],
    use: 'on / off',
    category: 'owner',
    async: async (m, {
        func,
        anya
    }) => {
        let groupData = global.db.groups[groupChatId];
        if (!m.args || !m.args[0]) return m.reply(`*Current status* : ${groupData.autogempa ? 'active' : 'non-active'}\n\n${func.example(m.cmd, 'on / off')}`)
        let option = m.args[0].toLowerCase()
        let optionList = ['on', 'off'];
        if (!optionList.includes(option)) return m.reply(`${func.example(m.cmd, 'on / off')}`)
        let status = option === 'on' ? true : false;
        if (groupData.autotempa == status) return m.reply(`Auto Gempa has been ${option == 'on' ? 'activated' : 'inactivated'} previously.`)
        groupData.autogempa = status;
        anya.reply(m.chat, `Auto Gempa has been ${option == 'on' ? 'activated' : 'inactivated'} successfully.`, m, {
            expiration: m.expiration
        })
    },
    group: true,
    owner: true,
    botAdmin: true
}