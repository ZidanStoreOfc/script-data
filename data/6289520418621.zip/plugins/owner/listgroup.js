const database = {};
let success = 0;
let failed = 0;

exports.run = {
    usage: ['listgroup'],
    hidden: ['listgrup', 'listgc'],
    category: 'owner',
    async: async (m, {
        func,
        anya
    }) => {
        const groupData = Object.values(await anya.groupFetchAllParticipating().catch(_ => []));
        if (groupData.length == 0) return m.reply('Tidak ada grup yang ditemukan.');

        let caption = `乂  *L I S T - G R U P*\n\nTerdapat total *${groupData.length}* grup.\n\n`;
        groupData.forEach((group, index) => {
            caption += `${index + 1}. ${group.subject}\n- ID: ${group.id}\n- Total peserta: ${group.participants ? Object.keys(group.participants).length : '0'}\n\n`;
        });
        caption += `*Pilihan Opsi:*\n_${m.cmd} [nomor] [opsi]_`
        caption += `\n\n*Contoh Penggunaan:*`
        caption += `\n- \`${m.cmd} 1 id\` - menampilkan id grup.`
        caption += `\n- \`${m.cmd} 1 detail\` - menampilkan detail grup.`
        caption += `\n- \`${m.cmd} 1 profile\` - menampilkan profil grup.`
        caption += `\n- \`${m.cmd} 1 desc\` - menampilkan deskripsi grup.`
        caption += `\n- \`${m.cmd} 1 link\` - menampilkan tautan grup.`
        caption += `\n- \`${m.cmd} 1 leave\` - mengeluarkan bot dari grup.`
        caption += `\n- \`${m.cmd} 1 close\` - menutup grup.`
        caption += `\n- \`${m.cmd} 1 open\` - membuka grup.`
        caption += `\n- \`${m.cmd} 1 admin\` - menampilkan daftar admin.`
        caption += `\n- \`${m.cmd} 1 member\` - menampilkan daftar anggota.`
        caption += `\n- \`${m.cmd} 1 kickall\` - mengeluarkan semua anggota.`

        const [number, action] = m.args;
        if (!(number && action)) return m.reply(caption);

        const selectedGroup = groupData[parseInt(number) - 1];
        if (!selectedGroup) return m.reply('Nomor grup tidak valid.');

        let groupId = selectedGroup.id;

        switch (action.toLowerCase()) {
            case 'id':
                anya.reply(m.chat, groupId, m, {
                    expiration: m.expiration
                })
                break;
            case 'detail': {
                let meta = await anya.groupMetadata(groupId).catch(() => {});
                let isBotAdmin = func.findAdmin(meta.participants).includes(m.bot);
                let caption = `◦  Nama Grup: ${meta.subject}`
                caption += `\n◦  ID Grup: ${meta.id}`
                caption += `\n◦  Total Member: ${meta.size}`
                caption += `\n◦  Edit Setelan Grup: ${meta.restrict ? 'Hanya admin' : 'Semua peserta'}`
                caption += `\n◦  Kirim Pesan: ${meta.announce ? 'Hanya admin' : 'Semua peserta'}`
                caption += `\n◦  Bot Admin: ${isBotAdmin ? 'Ya' : 'Tidak'}`
                caption += `\n◦  Pesan Sementara: ${meta.ephemeralDuration ? 'Aktif' : 'Mati'}`;
                if (meta.hasOwnProperty('isCommunity')) {
                    caption += `\n◦  isCommunity: ${meta.isCommunity ? 'Ya' : 'Tidak'}`;
                }
                if (meta.hasOwnProperty('isCommunityAnnounce')) {
                    caption += `\n◦  isCommunityAnnounce: ${meta.isCommunityAnnounce ? 'Ya' : 'Tidak'}`;
                }
                if (meta.hasOwnProperty('joinApprovalMode')) {
                    caption += `\n◦  Setujui Anggota Baru: ${meta.joinApprovalMode ? 'Ya' : 'Tidak'}`;
                }
                if (meta.hasOwnProperty('memberAddMode')) {
                    caption += `\n◦  Tambah anggota lain: ${meta.memberAddMode ? 'Ya' : 'Tidak'}`;
                }
                anya.reply(m.chat, caption, m, {
                    expiration: m.expiration
                });
                break;
            }
            case 'profile': {
                anya.sendReact(m.chat, '🕒', m.key);
                let profile = await func.getBuffer(await anya.profilePictureUrl(groupId, 'image').catch(_ => 'https://files.catbox.moe/ifx2y7.png'))
                anya.sendMessage(m.chat, {
                    image: profile
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
                break
            }
            case 'desc': {
                let meta = await anya.groupMetadata(groupId).catch(e => {})
                anya.reply(m.chat, meta.desc, m, {
                    expiration: m.expiration
                })
                break
            }
            case 'link': {
                let code = await anya.groupInviteCode(groupId).catch(_ => '')
                if (!code) return m.reply(global.mess.botAdmin)
                let meta = await anya.groupMetadata(groupId).catch(e => {})
                let caption = `Link Group ${meta.subject}\n\nhttps://chat.whatsapp.com/${code}`;
                anya.reply(m.chat, caption, m, {
                    expiration: m.expiration
                });
                break
            }
            case 'leave': {
                await anya.reply(groupId, 'Saya diperintahkan untuk keluar dari grup ini. Terima kasih dan maaf atas kesalahan selama di sini.');
                await anya.groupLeave(groupId)
                    .then(() => m.reply(`Berhasil keluar dari grup "${selectedGroup.subject}".`))
                    .catch(() => m.reply(`Gagal keluar dari grup "${selectedGroup.subject}".`));
                break;
            }
            case 'close': {
                await anya.groupSettingUpdate(groupId, 'announcement')
                    .then(() => m.reply(`Grup "${selectedGroup.subject}" berhasil ditutup.`))
                    .catch(() => m.reply(`Gagal menutup grup "${selectedGroup.subject}".`));
                break;
            }
            case 'open': {
                await anya.groupSettingUpdate(groupId, 'not_announcement')
                    .then(() => m.reply(`Grup "${selectedGroup.subject}" berhasil dibuka.`))
                    .catch(() => m.reply(`Gagal membuka grup "${selectedGroup.subject}".`));
                break;
            }
            case 'admin': {
                let meta = await anya.groupMetadata(groupId).catch(() => {});
                let adminList = meta.participants.filter(item => item.admin).map((item, index) => `${index + 1}. @${item.id.split('@')[0]}`).join('\n');
                let caption = `*Daftar Admin Grup "${meta.subject}"*\n\n${adminList}`;
                anya.reply(m.chat, caption, m, {
                    expiration: m.expiration
                });
                break;
            }
            case 'member': {
                let meta = await anya.groupMetadata(groupId).catch(() => {});
                let memberList = meta.participants.map((item, index) => `${index + 1}. @${item.id.split('@')[0]} (${item.admin === 'superadmin' ? 'Owner' : item.admin === 'admin' ? 'Admin' : 'Member'})`).join('\n');
                let caption = `*Daftar Member Grup "${meta.subject}"*\n\n${memberList}`;
                anya.reply(m.chat, caption, m, {
                    expiration: m.expiration
                });
                break;
            }
            case 'kickall': {
                let meta = await anya.groupMetadata(groupId).catch(() => {});
                let members = meta.participants.filter(item => item.admin == null).map(item => item.id);
                if (members.length == 0) return m.reply('Data empty.')
                let txt = `Are you sure you want to kick all participants group "${meta.subject}" ?\nTimeout *60* detik.\n\nketik *(Y/N)*`.trim()
                let {
                    key
                } = await anya.reply(m.chat, txt, m, {
                    expiration: m.expiration
                })
                database[m.sender] = {
                    jid: m.sender,
                    groupId: groupId,
                    groupName: meta.subject || '-',
                    key: m.key,
                    members: members,
                    timeout: setTimeout(() => {
                        m.reply('Timeout.');
                        anya.sendMessage(m.chat, {
                            delete: key
                        });
                        delete database[m.sender];
                    }, 60 * 1000)
                }
                break
            }
            default:
                anya.reply(m.chat, `Opsi "${action}" tidak valid. Pilihan Opsi: detail, profile, desc, link, leave, close, open, admin, member, kickall.`, m, {
                    expiration: m.expiration
                });
        }
    },
    main: async (m, {
        func,
        anya
    }) => {
        if (m.isBot) return
        if (!(m.sender in database)) return
        if (!m.budy) return
        let {
            jid,
            groupId,
            groupName,
            key,
            members,
            timeout
        } = database[m.sender];
        if (m.id === key.id) return
        if (/^(n|no)$/i.test(m.budy)) {
            clearTimeout(timeout)
            delete database[jid];
            return m.reply(`Kick all in group "${groupName}" successfully cancelled.`)
        } else if (/^(y|yes)$/i.test(m.budy)) {
            try {
                clearTimeout(timeout)
                m.reply(`Wait is kicking ${members.length} participants...`)
                for (let item of members) {
                    try {
                        await anya.groupParticipantsUpdate(groupId, [item], 'remove')
                        success++;
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    } catch (error) {
                        console.log(error);
                        failed++;
                    }
                }
                delete database[jid];
                m.reply(`Succes kick all *${failed > 0 ? success : success + failed}* participants in group "${groupName}".\n- Success: ${success}\n- Failed: ${failed}`)
                success = 0;
                failed = 0;
            } catch (error) {
                console.log(error);
                m.reply(`Failed to kick all participants.`)
            }
        }
    },
    owner: true,
    location: 'plugins/owner/listgroup.js'
}