const fs = require('fs');
const path = require('path');

exports.run = {
  usage: ['delall', 'resetall'],
  category: 'owner',
  async: async (m, { client, anya, func }) => {
    try {
      let output = '✅ *Delall & Reset Report*\n\n';

      // 1. Reset Pengguna yang tidak terdaftar
      let removedCount = Object.keys(global.db.users)
        .filter(jid => !global.db.users[jid].register)
        .map(jid => delete global.db.users[jid])
        .length;
      output += `- Pengguna tidak terdaftar: ${removedCount} pengguna dihapus.\n`;

      // 2. CLEAR REGISTER
      const beforeRegister = Object.keys(global.db.register || {}).length;
      global.db.register = {};
      const afterRegister = Object.keys(global.db.register || {}).length;
      output += `- Sesi Register: ${beforeRegister} ➔ ${afterRegister}\n`;

      // 3. CLEAR SAMBUNG KATA (delsk)
      const beforeSK = Object.keys(global.db.sambungkata || {}).length;
      global.db.sambungkata = {};
      const afterSK = Object.keys(global.db.sambungkata || {}).length;
      output += `- Sesi Sambung Kata: ${beforeSK} ➔ ${afterSK}\n`;

      // 4. CLEAR WEREWOLF
      const beforeWW = Object.keys(global.db.werewolf || {}).length;
      global.db.werewolf = {};
      const afterWW = Object.keys(global.db.werewolf || {}).length;
      output += `- Sesi Werewolf: ${beforeWW} ➔ ${afterWW}\n`;

      // 5. CLEAR PETAK BOM
      const beforePetakBom = Object.keys(global.db.petakbom || {}).length;
      global.db.petakbom = {}; // Hapus semua sesi petak bom
      const afterPetakBom = Object.keys(global.db.petakbom || {}).length;
      output += `- Sesi Petak Bom: ${beforePetakBom} ➔ ${afterPetakBom}\n`;

      // 6. CLEAR QUIZ
      const beforeQuiz = Object.keys(global.db.quizRooms || {}).length;
      global.db.quizRooms = {};
      const afterQuiz = Object.keys(global.db.quizRooms || {}).length;
      output += `- Sesi Quiz: ${beforeQuiz} ➔ ${afterQuiz}\n`;

      // 7. CLEAR SETTINGS (RESETBOT)
      const beforeSettings = Object.keys(global.db.setting || {}).length;
      global.db.setting = {};
      const afterSettings = Object.keys(global.db.setting || {}).length;
      output += `- Pengaturan Bot: ${beforeSettings} ➔ ${afterSettings}\n`;

      // 8. CLEAR MEMORY STORE
      let memoryStore = global.db.memoryStore;
      if (typeof memoryStore === 'string') {
        memoryStore = JSON.parse(memoryStore);
      }
      const beforeMemory = Object.keys(memoryStore || {}).length;
      memoryStore = {
        chats: [],
        contacts: {},
        messages: {},
        labels: [],
        labelAssociations: []
      };
      global.db.memoryStore = JSON.stringify(memoryStore);
      const afterMemory = Object.keys(memoryStore || {}).length;
      output += `- Memory Store: ${beforeMemory} ➔ ${afterMemory}\n`;

      // 9. CLEAR JUNK FILES
      const directoryPath = path.join('./sampah');
      const junkFiles = fs.existsSync(directoryPath)
        ? fs.readdirSync(directoryPath).filter(file =>
            ['gif', 'png', 'mp3', 'm4a', 'opus', 'mp4', 'jpg', 'jpeg', 'webp', 'webm', 'bin'].some(ext => file.endsWith(ext))
          )
        : [];
      const junkCount = junkFiles.length;
      if (junkCount > 0) {
        junkFiles.forEach(file => fs.unlinkSync(`${directoryPath}/${file}`));
      }
      output += `- File Sampah: ${junkCount} file dihapus\n`;

      // 10. DELETE CONTACT FILE
      const contactFilePath = './database/contact.vcf';
      const contactDeleted = fs.existsSync(contactFilePath);
      if (contactDeleted) fs.unlinkSync(contactFilePath);
      output += `- Kontak File: ${contactDeleted ? 'Dihapus' : 'Tidak Ada'}\n`;

      // 11. CLEAR GROUPS DATA (delgc)
      const allGroups = Object.keys(global.db.groups || {});
      const removedGroups = [];

      for (const groupJid of allGroups) {
        try {
          const group = await client.groupMetadata(groupJid);
          if (!group) {
            removedGroups.push(groupJid);
            delete global.db.groups[groupJid];
          }
        } catch (err) {
          removedGroups.push(groupJid);
          delete global.db.groups[groupJid];
        }
      }

      fs.writeFileSync('./database.json', JSON.stringify(global.db, null, 2));
      output += `- Data grup: ${removedGroups.length} grup dihapus.\n`;

      // 12. CLEAR METADATA (clearmt)
      if (global.db.metadata) {
        const beforeMetadata = Object.keys(global.db.metadata || {}).length;
        global.db.metadata = {};
        const afterMetadata = Object.keys(global.db.metadata || {}).length;
        output += `- Metadata: ${beforeMetadata} ➔ ${afterMetadata}\n`;
      } else {
        output += '- Metadata: Tidak ada metadata untuk dihapus\n';
      }

      // 13. CLEAR TIC-TAC-TOE (delttts)
      const beforeTTT = Object.keys(global.db.tictactoe || {}).length;
      global.db.tictactoe = {};
      const afterTTT = Object.keys(global.db.tictactoe || {}).length;
      output += `- Sesi Tic-Tac-Toe: ${beforeTTT} ➔ ${afterTTT}\n`;

      // 14. CLEAR CHESS (delchess)
      const beforeChess = Object.keys(global.db.chess || {}).length;
      global.db.chess = {};
      const afterChess = Object.keys(global.db.chess || {}).length;
      output += `- Sesi Chess: ${beforeChess} ➔ ${afterChess}\n`;

      // 15. CLEAR CASINO (delcasino)
      const beforeCasino = Object.keys(global.db.casino || {}).length;
      global.db.casino = {};
      const afterCasino = Object.keys(global.db.casino || {}).length;
      output += `- Sesi Casino: ${beforeCasino} ➔ ${afterCasino}\n`;

      // 16. CLEAR MENFES (delmenfes)
      const beforeMenfes = Object.keys(global.db.menfes || {}).length;
      global.db.menfes = {};
      const afterMenfes = Object.keys(global.db.menfes || {}).length;
      output += `- Sesi Menfes: ${beforeMenfes} ➔ ${afterMenfes}\n`;

      // 17. CLEAR OPENTIME
      const beforeOpenTime = Object.keys(global.db.opentime || {}).length;
      global.db.opentime = {};
      const afterOpenTime = Object.keys(global.db.opentime || {}).length;
      output += `- Open Time: ${beforeOpenTime} ➔ ${afterOpenTime}\n`;

      // 18. CLEAR CLOSETIME
      const beforeCloseTime = Object.keys(global.db.closetime || {}).length;
      global.db.closetime = {};
      const afterCloseTime = Object.keys(global.db.closetime || {}).length;
      output += `- Close Time: ${beforeCloseTime} ➔ ${afterCloseTime}\n`;

      m.reply(output);

      setTimeout(async () => {
        await anya.sendMessage(m.chat, { text: func.texted('monospace', 'Restarting...') }, { quoted: m, ephemeralExpiration: m.expiration });
        await global.database.save(global.db);
        if (!process.send) return m.reply('Tidak dapat me-restart bot karena file `index.js` tidak dijalankan.');
        process.send('reset');
        console.log('✅ Semua data berhasil dihapus dan bot sedang merestart.');
      }, 3000);

    } catch (err) {
      console.error('❌ Terjadi kesalahan saat menjalankan delall & reset:', err);
      m.reply('❌ Terjadi kesalahan saat menjalankan delall & reset.');
    }
  },
  devs: true
};