exports.run = {
    usage: ["eventpc", "eventgc", "eventsewa"],
    use: "text or reply media",
    category: "owner",
    async: async (i, {
        func: n,
        anya: s,
        setting: o,
        quoted: d
    }) => {
        if (s.quizset = s.quizset || [], !i.isOwner) return i.reply(global.mess.owner);
        try {
            var u = Object.values(global.db.users).filter(e => e.register && !e.banned).map(e => e.jid),
                l = Object.values(await s.groupFetchAllParticipating()).filter(e => e.participants.find(e => e.id == s.user.jid) && 0 == e.announce);
            let a = Object.values(global.db.groups).filter(e => e.sewa.status && e.sewa.expired && 0 != e.sewa.expired && !isNaN(e.sewa.expired)).map(e => e.jid);
            var m = l.map(e => e.id),
                p = m.filter(e => a.includes(e));
            let t = [];
            l.map(({
                participants: e
            }) => e.map(e => e.id)).map(e => t.push(...e));
            var c = "eventpc" == i.command ? u : "eventgc" == i.command ? m : p;
            if (0 == c.length) return i.reply("Error, ID does not exist.");
            if (!i.text) return i.reply(explain(i.cmd));
            var [w, g, h, y, f] = i.text.split("|");
            Object.freeze({
                1: "PREMIUM",
                2: "BALANCE",
                3: "LIMIT",
                4: "RANDOM_BALANCE",
                5: "RANDOM_LIMIT"
            });
            if (!w) return i.reply("Event should have questions.");
            if (!g) return i.reply("Event should have an answer.");
            if (!h) return i.reply("Give the number of respondents.");
            if (h && isNaN(h)) return i.reply("The number of respondents must be in numeric form.");
            s.sendReact(i.chat, "🕒", i.key);
            let r = n.makeid(15);
            var {
                dateNow: k,
                timeNow: b
            } = timeZone();
            let e;
            if (/video|image\/(jpe?g|png)/.test(d.mime)) {
                var v = await d.download();
                if (!(e = await n.catbox(v)).status) return i.reply(e.message || global.mess.error.api)
            }
            s.quizset.push({
                id: r,
                status: !0,
                question: w.trim(),
                answer: g.trim().toLowerCase(),
                reward_key: Number(y || 4),
                reward_value: Number(f || 1),
                slot: Number(h),
                correct: [],
                respondents: [],
                keyId: [],
                created_at: Date.now(),
                datenow: k,
                timenow: b,
                timer: 6e5,
                isImage: !!e,
                url: e ? e.url : o.cover,
                timeout: setTimeout(async function() {
                    var e = s.quizset.findIndex(e => e.id === r);
                    if (0 < s.quizset[e].keyId.length)
                        for (var a of s.quizset[e].keyId) await s.sendMessage(a.remoteJid, {
                            delete: {
                                remoteJid: a.remoteJid,
                                id: a.id,
                                fromMe: a.fromMe,
                                participant: i.bot
                            }
                        }), await new Promise(e => setTimeout(e, 2e3)); - 1 !== e && s.quizset.splice(e, 1)
                }, 6e5)
            });
            var x, I = `乂  *E V E N T - G I F T🎁*

`,
                I = (I = (I = (I = (I += `Event gift edisi ${k} (${b}) WIB

`) + `Question : *${w.trim()}*
`) + `Slot : *${h.trim()}*
`) + `Expired : *10 menit*
` + `- reply pesan broadcast ini dengan jawaban yang benar.

`) + ("#ID-" + r);
            for (x of c) {
                var $ = (await s.sendMessage(x, {
                    ...e ? {
                        image: {
                            url: e ? e.url : o.cover
                        },
                        caption: I
                    } : {
                        text: I
                    },
                    mentions: /eventgc|eventsewa/.test(i.command) ? t : []
                }, {
                    quoted: null,
                    ephemeralExpiration: i.expiration
                })).key;
                s.quizset.find(e => e.id == r).keyId.push($), await new Promise(e => setTimeout(e, 5e3))
            }
            s.reply(i.chat, `Successfully send broadcast message to ${c.length} ` + ("eventpc" == i.command ? "chats" : "groups"), i)
        } catch (e) {
            return s.reply(i.chat, e.message, i, {
                expiration: i.expiration
            })
        }
    },
    main: async (r, {
        func: i,
        anya: n,
        users: s,
        setting: o
    }) => {
        n.quizset = n.quizset || [];
        try {
            if (r.budy && r.quoted && r.quoted.fromMe && r.quoted.text && /[#]ID/.test(r.quoted.text)) {
                let a = r.quoted.text.split("#ID-")[1].trim(),
                    t = n.quizset.find(e => e.id == a);
                if (t) {
                    if (!t.status || t.correct.length == t.slot || new Date - t.created_at > o.timer) return n.reply(r.chat, "" + i.texted("italic", "❌ Event telah selesai silahkan tunggu edisi *Event gift* di lain kesempatan.") + `

${t.correct.map(e=>"- @"+e.split("@")[0]).join("\n")}

^ Ke-${t.correct.length} orang diatas adalah mereka yang mendapatkan hadiah event edisi saat ini.`, r, {
                        expiration: r.expiration
                    }).then(e => t.status = !1);
                    if (/^(qzclue|clue)$/i.test(r.budy)) return r.reply("Clue : " + i.texted("monospace", t.answer.replace(/[bcdfghjklmnpqrstvwxyz]/g, "-")));
                    if (t.respondents.includes(r.sender)) return r.reply("Maaf kamu hanya bisa menjawab 1 kali saja jika code yang kamu masukan salah kesempatan kamu akan *hangus*.");
                    if (t.respondents.push(r.sender), t.answer != r.budy.toLowerCase()) return n.sendMessage(r.chat, {
                        sticker: {
                            url: "https://files.catbox.moe/x5v3fl.webp"
                        }
                    }, {
                        quoted: r,
                        ephemeralExpiration: r.expiration
                    });
                    t.correct.push(r.sender);
                    let e;
                    var d, u, l, m, p, c, w = r.isGc ? "@" + r.sender.replace(/@.+/, "") : "kamu";
if (1 == t.reward_key ? (d = t.reward_value || 1, u = 864e5 * parseInt(d), s.premium ? (s.limit += 10, s.premium = !0, s.expired.premium += u) : (s.limit += 10, s.premium = !0, s.expired.premium = Date.now() + u), e = `✅ selamat ${w} mendapatkan reward akses premium untuk ${d} hari.`) 
: 2 == t.reward_key ? (l = 1e3 * t.reward_value || 5e3, s.balance += l, e = `✅ selamat ${w} mendapatkan reward saldo deposit sebanyak ${i.rupiah(l)}. fungsi: bisa buat top up game, dana dll, ketik .menu topup`) 
: 3 == t.reward_key ? (m = t.reward_value || 10, s.limit += m, e = `✅ selamat ${w} mendapatkan reward limit sebanyak ${i.rupiah(m)}.`) 
: 4 == t.reward_key ? (p = i.ranNumb(1, 1e4), s.balance += p, e = `✅ selamat ${w} mendapatkan reward balance sebanyak ${i.rupiah(p)}.`) 
: 5 == t.reward_key ? (c = i.ranNumb(1, 15), s.limit += c, e = `✅ selamat ${w} mendapatkan reward limit sebanyak ${i.rupiah(c)}.`) 
: 6 == t.reward_key ? (value = (t.reward_value * 1000) || 5000, s.money += value, e = `✅ selamat ${w} mendapatkan reward money sebanyak ${i.rupiah(value)}.`) 
: 7 == t.reward_key ? (value = (t.reward_value * 1000) || 5000, e = `✅ selamat ${w} mendapatkan reward saldo dana sebanyak ${i.rupiah(value)}. screenshot lalu kirim ke owner dengan cara ketik .owner`) 
: 8 == t.reward_key ? (value = (t.reward_value * 1000) || 5000, e = `✅ selamat ${w} mendapatkan reward uang bussid sebanyak ${i.rupiah(value)}.`) 
: 9 == t.reward_key ? (value = t.reward_value || 1, e = `✅ selamat ${w} mendapatkan reward sewa bot gratis selama ${i.rupiah(value)} hari. screenshot lalu kirim ke owner dengan cara ketik .owner.`) 
: 10 == t.reward_key ? (value = t.reward_value || 1, s.level += value, e = `✅ selamat ${w} mendapatkan level up. level kamu naik sebanyak ${i.rupiah(value)} level.`) 
: null, // Tambahkan null untuk menghindari error jika tidak ada reward_key yang cocok
n.sendReact(r.chat, "🎉", r.key), t.correct.length >= t.slot) return t.status = !1, await n.reply(r.chat, `Event Gift edisi ${t.datenow} (${t.timenow}) WIB telah selesai.
${t.correct.map(e=>"- @"+e.split("@")[0]).join("\n")}

^ Ke-${t.correct.length} orang diatas adalah mereka yang mendapatkan hadiah event edisi saat ini.`, null, {
                        expiration: r.expiration
                    });
                    await n.reply(r.chat, i.texted("bold", e), i.verified, {
                        expiration: r.expiration
                    }).then(async () => {
                        r.isGc && r.isBotAdmin && await n.sendMessage(r.chat, {
                            delete: {
                                remoteJid: r.chat,
                                fromMe: !1,
                                id: r.key.id,
                                participant: r.sender
                            }
                        });
                        var e = `乂  *E V E N T - G I F T🎁*

`,
                            e = (e = (e = (e = (e = (e += `Event Gift edisi ${t.datenow} (${t.timenow}) WIB

`) + `Question : *${t.question.trim()}*
`) + `Slot : *${t.slot-t.correct.length}*
`) + `Timeout : *${t.timer/1e3/60} menit*
` + `- reply pesan broadcast ini dengan jawaban yang benar.

`) + ("#ID-" + t.id), await n.sendMessage(r.chat, {
                                ...t.isImage ? {
                                    image: {
                                        url: t.url
                                    },
                                    caption: e
                                } : {
                                    text: e
                                }
                            }, {
                                quoted: null,
                                ephemeralExpiration: r.expiration
                            })).key;
                        t.keyId.push(e)
                    })
                }
            }
        } catch (e) {
            return n.reply(r.chat, e.message, r, {
                expiration: r.expiration
            })
        }
    }
};
let explain = e => `乂  *R K E Y*

1: 'PREMIUM'
2: 'SALDO_DEPOSIT'
3: 'LIMIT' 
4: 'RANDOM_BALANCE'
5: 'RANDOM_LIMIT'
6: 'MONEY'
7: 'DANA'
8: 'UANG_BUSSID'
9: 'SEWABOT_FREE'
10: 'LEVEL_UP'

Format : ${e} question | answer | slot | rKey | rValue`;

function timeZone() {
    var e = new Date,
        a = new Date(e.toLocaleString("en-US", {
            timeZone: "Asia/Jakarta"
        })),
        t = a.getHours(),
        a = a.getMinutes();
    return {
        dateNow: e.getDate() + `/${e.getMonth()+1}/` + e.getFullYear(),
        timeNow: t.toString().padStart(2, "0") + ":" + a.toString().padStart(2, "0")
    }
}