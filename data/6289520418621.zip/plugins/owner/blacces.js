const axios = require('axios');

const GITHUB_TOKEN = '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'; // Token akses GitHub
const GITHUB_REPO = 'ZidanStoreOfc/ZIDANSTORE'; // Ganti dengan nama repositori Anda
const FILE_PATH = 'blacklist.json'; // Path file yang ingin diperbarui

async function fetchBlacklist() {
    try {
        const response = await axios.get('https://raw.githubusercontent.com/ZidanStoreOfc/ZIDANSTORE/main/blacklist.json');
        return response.data.blacklist;
    } catch (error) {
        console.error('Error fetching blacklist:', error);
        return [];
    }
}

async function updateBlacklist(newBlacklist) {
    const jsonData = JSON.stringify({ blacklist: newBlacklist }, null, 2);
    
    // Ambil SHA dari file yang ada untuk memperbarui
    const { data: { sha } } = await axios.get(`https://api.github.com/repos/${GITHUB_REPO}/contents/${FILE_PATH}`, {
        headers: {
            Authorization: `token ${GITHUB_TOKEN}`
        }
    });

    // Update file di GitHub
    await axios.put(`https://api.github.com/repos/${GITHUB_REPO}/contents/${FILE_PATH}`, {
        message: 'Update blacklist',
        content: Buffer.from(jsonData).toString('base64'),
        sha: sha
    }, {
        headers: {
            Authorization: `token ${GITHUB_TOKEN}`
        }
    });
}

exports.run = {
    usage: ['blacces'],
    use: 'userId',
    category: 'owner',
    async: async (m, { anya, froms }) => {
    if (!m.isDevs) return m.reply("Fitur ini hanya untuk developer.")
        const userId = m.args[0]; // Ambil userId dari argumen
        if (!userId) {
            return m.reply('Silakan masukkan userId yang ingin ditambahkan ke blacklist.');
        }

        const blacklist = await fetchBlacklist();

        // Cek apakah userId sudah ada di blacklist
        if (blacklist.includes(userId)) {
            return m.reply(`User ID "${userId}" sudah ada di blacklist.`);
        }

        // Tambahkan userId ke blacklist
        blacklist.push(userId);
        await updateBlacklist(blacklist);

        return m.reply(`User ID "${userId}" telah berhasil ditambahkan ke blacklist.`);
    }
};