exports.run = {
usage: ['listspamkode'],
hidden: ['listspamcode'],
category: 'owner',
async: async (m, { func, anya, setting }) => {
const data = global.db.spamcode.filter(v => v.status)
if (data.length == 0) return m.reply('Empty data.')
let txt = '乂  *L I S T  S P A M  C O D E*'
data.forEach((v, i) => {
txt += `\n\n${i + 1}. @${v.number.split('@')[0]}`
txt += `\n◦  Status: ${v.status ? '✅' : '❌'}`
txt += `\n◦  Success : ${func.toRupiah(v.success)}`
txt += `\n◦  Failed : ${func.toRupiah(v.failed)}`
})
await m.reply(txt)
},
owner: true
}