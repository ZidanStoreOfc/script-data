exports.run = {
    usage: ['banned'],
    hidden: ['ban'],
    use: 'mention or reply',
    category: 'owner',
    async: async (m, {
        func,
        anya,
        froms,
        setting
    }) => {
        const toMs = require('ms');
        const [target, duration] = m.text.split('|');
        if (m.quoted) {
            let user = global.db.users[m.quoted.sender]
            let expire = m.text ? Date.now() + toMs(m.text) : Date.now() + 31557600000;
            if (typeof user == 'undefined') return m.reply('User data not found.')
            if (user.banned) return m.reply('Target already banned.')
            user.banned = true;
            user.expired.banned = expire;
            m.reply(`Successfully added @${m.quoted.sender.replace(/@.+/, '')} to banned user`)
        } else if (m.text) {
            if (!target) return m.reply(`Contoh : ${comand} 62xxx|30d`)
            let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : target.split('@')[1]) : target
            if (isNaN(number)) return m.reply('Invalid number.')
            if (number.length > 15) return m.reply('Invalid format.')
            let ban = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
            let user = global.db.users[ban]
            let expire = duration ? Date.now() + toMs(duration) : Date.now() + 31557600000;
            if (typeof user == 'undefined') return m.reply('User data not found.')
            if (user.banned) return m.reply('Target already banned.')
            user.banned = true;
            user.expired.banned = expire;
            m.reply(`Successfully added *${user.name}* into banned list.`)
        } else m.reply('Mention or Reply chat target.')
    },
    owner: true
}