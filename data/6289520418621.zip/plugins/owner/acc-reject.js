let toMs = require("ms");
exports.run = {
    usage: ["accdepo", "rejectdepo", "accprem", "rejectprem", "accsewa", "rejectsewa", "accpanel", "rejectpanel", "accjadibot", "rejectjadibot"],
    use: "628xxx",
    category: "owner",
    async: async (e, {
        func: a,
        anya: t
    }) => {
        var i = a.fstatus("System Notification");
        switch (e.command) {
            case "accdepo":
            case "rejectdepo":
                if (!e.text) return e.reply(`Contoh: ${e.cmd} 628xxx`);
                if (e.text.startsWith("08")) return e.reply("Awali nomor dengan 62");
                var r = e.text.replace(/[^0-9]/g, "") + "@s.whatsapp.net",
                    r = global.db.deposit[r];
                if (!r) return e.reply("Data deposit tidak ditemukan!");
                /accdepo/.test(e.command) ? (a.addSaldo(r.number, Number(r.amount_deposit)), n = `*D E P O S I T - S U K S E S*

*⋄ ID :* ${r.id}
*⋄ Nomor :* ${r.number.split("@")[0]}
*⋄ Payment :* ${r.payment}
*⋄ Tanggal :* ${r.date.split(" ")[0]}
*⋄ Jumlah Deposit :* Rp${a.toRupiah(r.amount_deposit)},-
*⋄ Pajak :* Rp${a.toRupiah(Number(Math.ceil(r.pajak)))},-`, o = [
                    ["check saldo", e.prefix + "saldo"]
                ], t.sendbut(e.chat, n, "click the button bellow to check saldo.", o, e, {
                    expiration: e.expiration
                }), await e.reply("Sukses acc deposit dengan ID: " + r.id), delete global.db.deposit[r.number]) : /rejectdepo/.test(e.command) && (await t.reply(r.number, `_Maaf deposit dengan ID: *${r.id}* ditolak, jika ada kendala hubungi owner bot._`, i, {
                    expiration: e.expiration
                }), await e.reply("Sukses reject deposit dengan ID: " + r.id), delete global.db.deposit[r.number]);
                break;
            case "accprem":
            case "rejectprem":
                if (!e.text) return e.reply(`Contoh: ${e.cmd} 628xxx`);
                if (e.text.startsWith("08")) return e.reply("Awali nomor dengan 62");
                var n = e.text.replace(/[^0-9]/g, "") + "@s.whatsapp.net",
                    o = global.db.users[n];
                if (o.premium) return e.reply(`@${n.replace(/@.+/,"")} has become registered as a premium account.`);
                if (void 0 === global.db.premium[n]) return e.reply("Data premium tidak ditemukan!");
                r = global.db.premium[n];
                /accprem/.test(e.command) ? (o.premium = !0, o.limit += 99999, o.expired.premium = Date.now() + toMs(r.data.duration), n = [
                    ["cek premium", e.prefix + "cekprem"]
                ], o = `*P R E M I U M - S U K S E S*

⋄ ID : ${r.id}
⋄ Nomor : ${r.number.split("@")[0]}
⋄ Tanggal : ${r.date}
⋄ Nama Paket : ${r.data.name}
⋄ Durasi : ${r.data.duration}
⋄ Harga : Rp${a.toRupiah(r.data.price)},-`, t.sendbut(r.number, o, "premium kamu telah dikonfirmasi oleh owner.", n, a.fverified, {
                    expiration: e.expiration
                }), await e.reply("Sukses acc premium dengan ID: " + r.id), delete global.db.premium[r.number]) : /rejectprem/.test(e.command) && (await t.reply(r.number, `_Maaf premium dengan ID: *${r.id}* ditolak, jika ada kendala hubungi owner bot._`, i, {
                    expiration: e.expiration
                }), await e.reply("Sukses reject premium dengan ID: " + r.id), delete global.db.premium[r.number]);
                break;
            case "accsewa":
            case "rejectsewa":
                if (!e.text) return e.reply(`Contoh: ${e.cmd} 628xxx`);
                if (e.text.startsWith("08")) return e.reply("Awali nomor dengan 62");
                o = e.text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
                if (void 0 === global.db.sewabot[o]) return e.reply("Data sewabot tidak ditemukan!");
                n = global.db.sewabot[o];
                /accsewa/.test(e.command) ? (n.session = "link_group", t.reply(n.number, "_Sewabot kamu telah dikonfirmasi oleh owner, silahkan kirim link grup yang ingin sewa bot._", i, {
                    expiration: e.expiration
                }), await e.reply("Sukses acc sewabot dengan ID: " + n.id)) : /rejectsewa/.test(e.command) && (await t.reply(n.number, `_Maaf sewabot dengan ID: *${n.id}* ditolak, jika ada kendala hubungi owner bot._`, i, {
                    expiration: e.expiration
                }), await e.reply("Sukses reject sewabot dengan ID: " + n.id), delete global.db.sewabot[n.number]);
                break;
            case "accpanel":
            case "rejectpanel":
                if (!e.text) return e.reply(`Contoh: ${e.cmd} 628xxx`);
                if (e.text.startsWith("08")) return e.reply("Awali nomor dengan 62");
                r = e.text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
                if (void 0 === global.db.panel[r]) return e.reply("Data panel tidak ditemukan!");
                o = global.db.panel[r];
                /accpanel/.test(e.command) ? ((n = global.db.server[o.number]) && 0 < n.data.length ? (o.session = "panel_options", r = (await t.sendbut(o.number, "Kamu sudah memiliki akun panel sebelumnya, ingin membuat akun baru atau menambahkan server?", "click the button bellow to create new or add server", [
                    ["create new", "1"],
                    ["add server", "2"]
                ], a.fverified, {
                    expiration: e.expiration
                })).key, o.keyId = r) : (o.session = "create_new", t.reply(o.number, "_Panel kamu telah dikonfirmasi oleh owner, silahkan KETIK username untuk akun panel kamu._", a.fverified, {
                    expiration: e.expiration
                })), t.reply(e.chat, "Sukses acc panel dengan ID: " + o.id, e, {
                    expiration: e.expiration
                })) : /rejectpanel/.test(e.command) && (await t.reply(o.number, `_Maaf panel dengan ID: *${o.id}* ditolak, jika ada kendala hubungi owner bot._`, i, {
                    expiration: e.expiration
                }), t.reply(e.chat, "Sukses reject panel dengan ID: " + o.id, e, {
                    expiration: e.expiration
                }), delete global.db.panel[o.number]);
                break;
            case "accjadibot":
            case "rejectjadibot":
                if (!e.text) return e.reply(`Contoh: ${e.cmd} 628xxx`);
                if (e.text.startsWith("08")) return e.reply("Awali nomor dengan 62");
                n = e.text.replace(/[^0-9]/g, "") + "@s.whatsapp.net", r = global.db.users[n];
                if (r.jadibot) return e.reply(`@${n.replace(/@.+/,"")} has become registered as a jadibot user.`);
                if (void 0 === global.db.buyjadibot[n]) return e.reply("Data jadibot tidak ditemukan!");
                o = global.db.buyjadibot[n];
                /accjadibot/.test(e.command) ? (r.jadibot = !0, r.expired.jadibot = Date.now() + toMs(o.data.duration), n = [
                    ["jadibot", e.prefix + "jadibot"]
                ], r = `*J A D I B O T - S U K S E S*

⋄ ID : ${o.id}
⋄ Nomor : ${o.number.split("@")[0]}
⋄ Tanggal : ${o.date}
⋄ Nama Paket : ${o.data.name}
⋄ Durasi : ${o.data.duration}
⋄ Harga : Rp${a.toRupiah(o.data.price)},-`, t.sendbut(o.number, r, "jadibot kamu telah dikonfirmasi oleh owner.", n, null, {
                    expiration: e.expiration
                }), await e.reply("Sukses acc jadibot dengan ID: " + o.id), delete global.db.buyjadibot[o.number]) : /rejectjadibot/.test(e.command) && (await t.reply(o.number, `_Maaf jadibot dengan ID: *${o.id}* ditolak, jika ada kendala hubungi owner bot._`, i, {
                    expiration: e.expiration
                }), await e.reply("Sukses reject jadibot dengan ID: " + o.id), delete global.db.buyjadibot[o.number])
        }
    },
    owner: !0,
    location: "plugins/owner/acc-reject.js"
};