const toMs = require('ms');

exports.run = {
  usage: ['addvvip'],
  hidden: ['addvip'],
  use: 'mention or reply',
  category: 'owner',
  async: async (m, { func, anya, setting }) => {
    const [text1, text2] = m.text.split('|');
    if (m.quoted) {
      let user = global.db.users[m.quoted.sender]
      let expire = m.text ? Date.now() + toMs(m.text) : 'PERMANENT'
      if (typeof user == 'undefined') return m.reply('User  data not found.')
      if (user.vvip) return m.reply(`@${m.quoted.sender.replace(/@.+/, '')} sudah menjadi akun VVIP.`)
      user.vvip = true;
      user.limit += setting.limit.vvip;
      user.expired.vvip = expire;
      m.reply(`Berhasil menambahkan @${m.quoted.sender.replace(/@.+/, '')} sebagai akun VVIP`)
    } else if (m.text) {
      if (!text1) return m.reply(`Contoh : ${m.cmd} 62895354291993|30d`)
      let number = isNaN(text1) ? (text1.startsWith('+') ? text1.replace(/[()+\s-]/g, '') : (text1).split('@')[1]) : text1
      if (isNaN(number)) return m.reply('Nomor tidak valid.')
      if (number.length > 15) return m.reply('Format tidak valid.')
      let vvipnya = text1.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
      let user = global.db.users[vvipnya]
      let expire = text2 ? Date.now() + toMs(text2) : 'PERMANENT'
      if (typeof user == 'undefined') return m.reply('User  data not found.')
      if (user.vvip) return m.reply(`@${vvipnya.replace(/@.+/, '')} sudah menjadi akun VVIP.`)
      user.vvip = true;
      user.limit += setting.limit.vvip;
      user.expired.vvip = expire;
      m.reply(`Berhasil menambahkan @${vvipnya.replace(/@.+/, '')} sebagai akun VVIP.`)
    } else m.reply('Mention atau Reply chat target.')
  },
  devs: true,
  location: "plugins/owner/addvvip.js",
}