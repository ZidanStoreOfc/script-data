exports.run = {
usage: ['leave'],
use: 'id grup',
category: 'owner',
async: async (m, { func, anya }) => {
let id = m.args[0] && m.args[0].endsWith('@g.us') ? m.args[0] : m.chat.endsWith('@g.us') ? m.chat : '';
if (!id) return m.reply('Input id grup dengan benar!')
anya.reply(m.chat, 'SIAP TUAN 🫡', m)
.then(() => anya.groupLeave(id))
},
owner: true
}