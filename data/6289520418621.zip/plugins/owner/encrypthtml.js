exports.run = {
    usage: ['encrypthtml'],
    hidden: ['enchtml'],
    use: 'reply text',
    category: 'owner',
    async: async (m, { anya, quoted }) => {
        // Ambil teks dari pesan yang dibalas
        let text;
        if (quoted && quoted.text) {
            text = quoted.text;
        } else {
            return m.reply("*Silakan balas pesan yang berisi teks HTML yang ingin dienkripsi.*");
        }

        // Fungsi untuk mengenkripsi teks menjadi format hexadecimal
        const encryptHTML = (html) => {
            return html.split('').map(char => {
                return '%' + ('0' + char.charCodeAt(0).toString(16)).slice(-2).toUpperCase();
            }).join('');
        };

        // Enkripsi teks HTML
        const encryptedText = encryptHTML(text);

        // Hasilkan skrip HTML
        const result = `<script>
document.write(unescape('${encryptedText}'));
</script>`;

        // Kirim hasil
        await anya.reply(m.chat, result, m);
    },
    devs: true
};