const crypto = require('crypto');
const axios = require('axios');
async function createPaste(content) {
const data = {
key: global.paste,
description: "Encoded text paste",
sections: [{ name: "Encoded Text", syntax: "text", contents: content }],
expires: "1w"
};
try {
const response = await axios.post("https://api.paste.ee/v1/pastes", data, {
headers: {
"Content-Type": "application/json",
"X-Auth-Token": global.paste
}
});
const result = response.data;
const rawUrl = result.link.replace('/p/', '/r/') + "/0";
return { success: true, link: rawUrl };
} catch {
return { success: false, link: null };
}
}
exports.run = {
usage: ['encode'],
use: 'reply text',
category: 'owner',
async: async (m, { anya, quoted }) => {
if (!m.text) return anya.reply(m.chat, 'Masukkan teks yang ingin dienkode.', m);
await anya.sendReact(m.chat, '🕒', m.key);
try {
const binaryEncode = (text) => {
return text.split('').map(char => {
return char.charCodeAt(0).toString(2).padStart(8, '0');
}).join(' ');
};
const reverseString = (str) => {
return str.split('').reverse().join('');
};
const base64Encode = (str) => {
return Buffer.from(str).toString('base64');
};
const hexEncode = (str) => {
return str.split('').map(char => {
return char.charCodeAt(0).toString(16);
}).join('');
};
const encryptAES = (text, secretKey) => {
const cipher = crypto.createCipher('aes-256-cbc', secretKey);
let encrypted = cipher.update(text, 'utf8', 'hex');
encrypted += cipher.final('hex');
return encrypted;
};
const secretKey = 'HCZpGQadP53RB4bxVXKuo2kwWjrvNnYSthLiUgfM7JEcm68sqeDz9AyTFn34TRUQuv5drbRxXgRvDRmL7hwLJvtpaoSZJfgaFuCNUprVDDD5prvbct6MG9fmohdSAN62yWCwZDAFh6ZVfrZHYaL2cxoJEKqryGWGNG2h4vkWB5huJMihhouTMfm7NhaZBxRPCLeuDRd9DJnfngSQN3wao3Rw64hQvL39wP66xRVAPZNBc8pmiajBvdox75qq7sq3UiKJvq4bp7nxAftYqWM6hcDp55WzQbuNksEFrjRsfAaJ7cfhQ4wWBh4ggFuoSY7fbagmvtRTsnb7b9VGTLRCaYQWKsWmjBkkmjR3WayeMkc4bxz3gsxrYeoSVhsxDXUBpJJsV653PshnazGZ4rW7taib54VrMJFRWbn2ZWYLHH4j6JmCf6pMwx7k7PioHK3AmP5EJeYU29dMCNxo9tcZx7rS5qei5E5jT7rzQE9QrccdAmhfG87fWdvWJDgJSieCsQmKj36kiF5MHBWHzVsb5T3LzaJ34jYUVGzuYBGrZstT4mBuCXqfVcjxmCCGBLRfHTfTSBdS3TAi6X7FYEA5H97DhCvSukvRvj3DwciG3DSDZNnXsZXZLxdX5LzfT4sdATRutAjZFYyYxg5xj4xLV5UrP5mM4CDAaGC2bwBHgmpBbHFeFynM9HqSUZHqjqrSSpBog3YucAmAycXcazUHZSnkkXZhBvMCYDPyFD7xwoXeF8YcvmZPvDWt5HSBWB3ukntqeen8cgK8yPtacPYh5wCcPCcnrVwrJfj7y2UdRocRanCCdPoZ39zYYSG8Bim4AstzqFGqsavYYW2Xzu8oYTQdJYBBuHsYaNopAGAwG4aj6EWDykwQ5Rm4uXZeM4gxci49nsSqHGbySiYU2PD2MJwpjufVtVd6zb3hBuCT84Z9N2wtH7qb74SVpWU46ARmRjWZZCzZzYzx5zNRdfXpvcq4k2wPm2vDQJ9m2hd';
const binary = binaryEncode(m.text);
const reversedBinary = reverseString(binary);
const base64Encoded = base64Encode(reversedBinary);
const hexEncoded = hexEncode(base64Encoded);
const encrypted = encryptAES(hexEncoded, secretKey);
if (!encrypted) return anya.reply(m.chat, 'Gagal mengenkode teks.', m);
if (encrypted.length > 4000) {
const pasteData = await createPaste(encrypted);
if (pasteData.success) {
await anya.reply(m.chat, `Teks terenkripsi terlalu panjang. Lihat hasilnya di sini: ${pasteData.link}`, m);
} else {
await anya.reply(m.chat, 'Gagal membuat tautan paste.', m);
}
} else {
await anya.reply(m.chat, encrypted, m);
}
await anya.sendReact(m.chat, '✅', m.key);
} catch {
await anya.sendReact(m.chat, '❌', m.key);
}
},
devs: true
};