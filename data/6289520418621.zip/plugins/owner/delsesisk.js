exports.run = {
  usage: ['delsesisk'],
  category: 'owner',
  async: async (m, { func, anya }) => {
    // Cek apakah user adalah owner
    if (!m.isOwner) return m.reply('Fitur ini hanya bisa digunakan oleh Owner.');

    // Ambil data sambung kata di database
    if (!global.db || !global.db.sambungkata) return m.reply('Tidak ada sesi Sambung Kata yang ditemukan di database.');

    let sambungkataSessions = Object.keys(global.db.sambungkata);
    if (sambungkataSessions.length === 0) return m.reply('Tidak ada sesi Sambung Kata yang aktif untuk dihapus.');

    // Hapus semua sesi sambung kata
    sambungkataSessions.forEach(session => {
      delete global.db.sambungkata[session];
    });

    // Konfirmasi ke owner
    m.reply(`Semua sesi permainan Sambung Kata berhasil dihapus.\nJumlah sesi yang dihapus: *${sambungkataSessions.length}*`);
  },
  owner: true
};