let database = {},
count = 0;

exports.run = {
usage: ['getallsticker'],
hidden: ['getallstiker', 'getallstik'],
category: 'owner',
async: async (m, { func, anya, packname, author }) => {
const data = Object.keys(global.db.sticker)
if (data.length == 0) return m.reply('Data empty.')
if (data.length >= 100) {
let txt = `Are you sure you want to get ${data.length} stickers?
Timeout *60* seconds.\n\nketik *(Y/N)*`.trim()
anya.reply(m.chat, txt, m)
database[m.sender] = {
sender: m.sender,
from: m.chat,
key: m.key,
data: data,
timeout: setTimeout(() => (m.reply('Timeout.'), delete database[m.sender]), 60 * 1000)
}
} else {
m.reply(`Wait is sending ${data.length} stickers...`)
for (let i of data) {
await anya.sendStickerFromUrl(m.chat, global.db.sticker[i].link, null, {
packname: packname, 
author: author, 
expiration: m.expiration
}).then(() => count++)
await func.delay(500)
}
m.reply(`Succes sending *${count}* stickers.`)
}
},
main: async (m, { func, anya, packname, author }) => {
if (m.isBot) return
if (!(m.sender in database)) return
if (!m.body) return
let { sender, from, key, data, timeout } = database[m.sender];
if (m.id === key.id) return
if (func.somematch(['n', 'no'], m.body.toLowerCase())) {
clearTimeout(timeout)
delete database[sender]
return m.reply('Send all stickers successfully cancelled.')
}
if (func.somematch(['y', 'yes'], m.body.toLowerCase())) {
try {
clearTimeout(timeout)
m.reply(`Wait is sending ${data.length} stickers...`)
for (let i of data) {
await anya.sendStickerFromUrl(from, global.db.sticker[i].link, null, {
packname: packname, 
author: author, 
expiration: m.expiration
}).then(() => count++)
await func.delay(500)
}
m.reply(`Succes sending *${count}* stickers.`).then(() => delete database[sender])
} catch (err) {
m.reply(`Failed to send all stickers.`)
}
}
},
owner: true
}