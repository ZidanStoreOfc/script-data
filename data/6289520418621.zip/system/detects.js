let {
  getContentType,
  WAMessageStubType,
  jidNormalizedUser
} = require("@whiskeysockets/baileys");
let func = require("./functions.js");
let processedMessages = new Set();
module.exports = async (m, e) => {
  if (m) {
    var i = jidNormalizedUser(m.user.id);
    if (!global.db.setting[i]?.maintenance) {
      var d = {
        subject: "@admin telah mengubah subject grup menjadi @subject",
        profile: "@admin telah mengubah icon grup ini.",
        open: "@admin telah membuka grup ini, sekarang member dapat mengirim pesan ke grup ini.",
        close: "@admin telah menutup grup ini, sekarang member tidak dapat mengirim pesan ke grup ini.",
        allowEdit: "@admin telah mengubah setelan grup ini, sekarang member dapat mengedit info grup ini.",
        disallowEdit: "@admin telah mengubah setelan grup ini, sekarang member tidak dapat mengedit info grup ini.",
        joinApprovalModeOn: "@admin menyalakan persetujuan admin untuk bergabung ke grup ini.",
        joinApprovalModeOff: "@admin mematikan persetujuan admin untuk bergabung ke grup ini.",
        memberAddModeOn: "@admin mengubah pengaturan grup ini untuk mengizinkan semua anggota menambahkan orang lain ke grup ini.",
        memberAddModeOff: "@admin mengubah pengaturan grup ini untuk mengizinkan hanya admin yang bisa menambahkan orang lain ke grup ini.",
        promote: "@admin telah menaikan jabatan @user menjadi admin.",
        demote: "@admin telah menurunkan jabatan @user menjadi member biasa.",
        addAdmin: "@admin telah menambahkan @user kedalam grup ini.",
        addLink: "@user bergabung ke grup ini menggunakan tautan.",
        addInv: "@user telah bergabung dengan grup menggunakan undangan bot.",
        leave: "@user telah keluar dari grup ini\n- kalau udah keluar jangan harap bisa balik lagi.",
        kick: "@admin telah mengeluarkan @user dari grup ini.",
        ephemeralOn: "@admin telah menetapkan pesan sementara pada grup ini @jumlah",
        ephemeralOff: "@admin telah mematikan pesan sementara pada grup ini."
      };
      try {
        var u = e.messages[e.messages.length - 1];
        if (u && !processedMessages.has(u.key.id)) {
          processedMessages.add(u.key.id);
          let r = u.key.remoteJid;
          if (/^\d.*(@g\.us)$/.test(r)) {
            var a;
            var l = u.message ? getContentType(u.message) : "";
            var p = u.message ? u.message[l] : {};
            var o = global.db.groups[r];
            if (global.db.metadata[r]) {
              if (/^(21|22|25|26|27|28|29|30|32|145|171)$/.test(u.messageStubType)) {
                console.log("messageStubType:", u.messageStubType);
                require("./metadata.js")(m, r);
              }
            } else {
              a = await m.groupMetadata(r).catch(e => {});
              global.db.metadata[r] = {
                ...a
              };
              console.log(`Pembuatan metadata pada: ${r} telah siap`);
            }
            if (o && o.detect && !o.banned) {
              let e = u.key.participant;
              let a = u.messageStubParameters;
              let s = func.fstatus("System Notification");
              let t = p?.ephemeralExpiration || 86400;
              let n = (e, a) => {
                let n = e;
                for (var i in a) {
                  n = n.replace("@" + i, a[i]);
                }
                m.sendMessage(r, {
                  text: n,
                  mentions: m.ments(n)
                }, {
                  quoted: s,
                  ephemeralExpiration: t
                });
              };
              switch (u.messageStubType) {
                case 21:
                  n(d.subject, {
                    subject: a.join(),
                    admin: "@" + e.split("@")[0]
                  });
                  break;
                case 22:
                  n(d.profile, {
                    admin: "@" + e.split("@")[0]
                  });
                  break;
                case 25:
                  n(a.includes("off") ? d.allowEdit : d.disallowEdit, {
                    admin: "@" + e.split("@")[0]
                  });
                  break;
                case 26:
                  var g = a.includes("off") ? d.open : d.close;
                  if (e !== i) {
                    n(g, {
                      admin: "@" + e.split("@")[0]
                    });
                  }
                  break;
                case 27:
                  if (![...a, e].includes(i)) {
                    if (u.key.participant) {
                      if (e !== i) {
                        n(d.addAdmin, {
                          user: a.map(e => "@" + e.split("@")[0]).join(", "),
                          admin: "@" + e.split("@")[0]
                        });
                      }
                    } else {
                      if (o.blacklist.some(e => a.includes(e))) {
                        m.sendMessage(r, {
                          text: `Sorry ${a.map(e => "@" + e.split("@")[0]).join(", ")}, you have been blacklisted from this group.`,
                          mentions: a
                        }, {
                          quoted: s,
                          ephemeralExpiration: t
                        });
                        await func.delay(2000);
                        return await m.groupParticipantsUpdate(r, a, "remove");
                      }
                      n(d.addLink, {
                        user: a.map(e => "@" + e.split("@")[0]).join(", ")
                      });
                    }
                  }
                  break;
                case 28:
                  if (![...a, e].includes(i)) {
                    n(d.kick, {
                      admin: "@" + e.split("@")[0],
                      user: a.map(e => "@" + e.split("@")[0]).join(", ")
                    });
                  }
                  break;
                case 29:
                  if (![...a, e].includes(i)) {
                    n(d.promote, {
                      admin: "@" + e.split("@")[0],
                      user: a.map(e => "@" + e.split("@")[0]).join(", ")
                    });
                  }
                  break;
                case 30:
                  if (![...a, e].includes(i)) {
                    n(d.demote, {
                      admin: "@" + e.split("@")[0],
                      user: a.map(e => "@" + e.split("@")[0]).join(", ")
                    });
                  }
                  break;
                case 32:
                  if (![...a, e].includes(i)) {
                    n(d.leave, {
                      admin: "@" + e.split("@")[0],
                      user: a.map(e => "@" + e.split("@")[0]).join(", ")
                    });
                    a.forEach(async e => {
                      await m.updateBlockStatus(e, "block");
                    });
                  }
                  break;
                case 145:
                  n(a.includes("off") ? d.joinApprovalModeOff : d.joinApprovalModeOn, {
                    admin: "@" + e.split("@")[0]
                  });
                  break;
                case 171:
                  n(a.includes("off") ? d.memberAddModeOff : d.memberAddModeOn, {
                    admin: "@" + e.split("@")[0]
                  });
                  break;
                default:
                  var b = p?.ephemeralExpiration;
                  var k = b !== 0 ? d.ephemeralOn.replace("@jumlah", b) : d.ephemeralOff;
                  if (/protocolMessage/.test(l) && p?.type == 3) {
                    n(k, {
                      admin: "@" + e.split("@")[0]
                    });
                  }
              }
            }
          }
        }
      } catch (e) {
        console.error(e);
      }
    }
  }
};
func.reloadFile(__filename);