let fetch = require("node-fetch");
let func = require("./functions.js");
function removeDuplicateMember(e) {
  let t = new Set();
  return e.filter(e => !t.has(e.jid) && (t.add(e.jid), true));
}
module.exports = class {
  expiration = 86400;
  fchannel = {
    key: {
      remoteJid: "status@broadcast",
      fromMe: false,
      participant: "0@s.whatsapp.net"
    },
    message: {
      newsletterAdminInviteMessage: {
        newsletterJid: "120363312671301398@newsletter",
        newsletterName: global.footer,
        jpegThumbnail: null,
        caption: global.footer,
        inviteExpiration: Date.now() + 1814400000
      }
    }
  };
  groupAdd = async (i, l) => {
    let o = global.db.setting[i.user.jid];
    if (!o.maintenance) {
      let {
        from: e,
        subject: t,
        desc: a,
        jid: r
      } = l;
      if (global.db.groups[e] !== undefined) {
        var n;
        var l = global.db.groups[e];
        var s = l.tekswelcome.replace("+user", "@" + r.split("@")[0]).replace("+group", t).replace("+desc", a);
        if (!l.member.find(e => e.jid == r)) {
          l.member.push({
            jid: r,
            lastseen: Date.now(),
            toxic: 0,
            chat: 0
          });
        }
        if (l && l.antiluar && !r.startsWith("62")) {
          i.reply(e, func.texted("bold", `Sorry @${sender.split("@")[0]}, this group is only for indonesian people and you will removed automatically.`), {
            expiration: this.expiration
          });
          i.updateBlockStatus(r, "block");
          return func.delay(2000).then(() => i.groupParticipantsUpdate(e, [r], "remove"));
        }
        if (l && l.blacklist.some(e => e === r) && !l.detect) {
          i.reply(e, func.texted("bold", `Sorry @${r.split("@")[0]}, you have been blacklisted from this group.`));
          return func.delay(2000).then(() => i.groupParticipantsUpdate(e, [r], "remove"));
        }
        if (l.welcome) {
          n = await i.profilePictureUrl(r, "image").catch(e => o.cover);
          i.sendMessageModify(e, s, this.fchannel, {
            title: "Welcome Message",
            body: global.header,
            thumbnail: await fetch(n).then(e => e.buffer()),
            largeThumb: false,
            expiration: this.expiration,
            newsletter: true
          });
        }
        s = removeDuplicateMember(l.member);
        l.member = s;
      }
    }
  };
  groupRemove = async (e, t) => {
    var a;
    var r;
    var i;
    var l;
    var o = global.db.setting[e.user.jid];
    if (!o.maintenance) {
      ({
        from: t,
        subject: l,
        desc: a,
        jid: i
      } = t);
      if (global.db.groups[t] !== undefined) {
        i = (r = global.db.groups[t]).teksleft.replace("+user", "@" + i.split("@")[0]).replace("+group", l).replace("+desc", a);
        if (r.left) {
          e.sendMessageModify(t, i, this.fchannel, {
            title: "Leave Message",
            body: global.header,
            thumbnail: await fetch(o.cover).then(e => e.buffer()),
            largeThumb: false,
            expiration: this.expiration,
            newsletter: true
          });
        }
        l = removeDuplicateMember(r.member);
        r.member = l;
      }
    }
  };
};
func.reloadFile(__filename);