let {
  default: makeWASocket,
  downloadContentFromMessage,
  getContentType,
  generateWAMessage,
  generateWAMessageFromContent,
  generateForwardMessageContent,
  prepareWAMessageMedia,
  getBinaryNodeChild,
  areJidsSameUser,
  generateMessageIDV2,
  generateWAMessageContent,
  proto,
  delay,
  jidDecode
} = require("@whiskeysockets/baileys");
let fs = require("fs");
let chalk = require("chalk");
let moment = require("moment-timezone");
let fetch = require("node-fetch");
let util = require("util");
let phoneNumber = require("awesome-phonenumber");
let jimp = require("jimp");
let path = require("path");
let fromBuffer = require("file-type").fromBuffer;
let randomBytes = require("crypto").randomBytes;
let func = require("./functions.js");
let {
  imageToWebp,
  videoToWebp,
  writeExifImg,
  writeExifVid,
  writeExifWebp
} = require("../lib/exif.js");
module.exports = class {
  mention = (e = "") => e.match("@") ? [...e.matchAll(/@([0-9]{5,16}|0)/g)].map(e => e[1] + "@s.whatsapp.net") : [];
  generateMessageId = () => {
    let e = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    return "ANYA" + Array.from({
      length: 11
    }, () => e.charAt(Math.floor(Math.random() * e.length))).join("");
  };
  initExtraFunc = c => {
    let i = c.sendMessage;
    c.sendMessage = async (e, t, s) => {
      var a = /^(\d.*@(s\.whatsapp\.net|g\.us|newsletter)|status@broadcast)$/;
      var e = a.test(e) ? e : e.replace(/[^0-9]/gi, "") + "@s.whatsapp.net";
      return !!a.test(e) && i(e, t, {
        messageId: this.generateMessageId(),
        ...s
      });
    };
    c.decodeJid = e => {
      var t;
      return e && (/:\d+@/gi.test(e) && (t = jidDecode(e) || {}).user && t.server && t.user + "@" + t.server || e);
    };
    c.getBusinessProfile = async e => {
      var t;
      var s;
      var a;
      var i;
      var r;
      var e = await c.query({
        tag: "iq",
        attrs: {
          to: "s.whatsapp.net",
          xmlns: "w:biz",
          type: "get"
        },
        content: [{
          tag: "business_profile",
          attrs: {
            v: "244"
          },
          content: [{
            tag: "profile",
            attrs: {
              jid: e
            }
          }]
        }]
      });
      var e = getBinaryNodeChild(getBinaryNodeChild(e, "business_profile"), "profile");
      if (e) {
        t = getBinaryNodeChild(e, "address");
        s = getBinaryNodeChild(e, "description");
        a = getBinaryNodeChild(e, "website");
        i = getBinaryNodeChild(e, "email");
        r = getBinaryNodeChild(getBinaryNodeChild(e, "categories"), "category");
        return {
          jid: e.attrs?.jid,
          address: t?.content.toString(),
          description: s?.content.toString(),
          website: a?.content.toString(),
          email: i?.content.toString(),
          category: r?.content.toString()
        };
      } else {
        return {};
      }
    };
    c.sendGroupInvite = async (e, t, s = {}) => {
      var {
        inviteCode: s,
        inviteExpiration: a,
        groupName: i,
        jpegThumbnail: r,
        caption: n,
        quoted: o
      } = s;
      if (e && s) {
        s = generateWAMessageFromContent(e, proto.Message.fromObject({
          groupInviteMessage: {
            groupJid: e,
            inviteCode: s,
            inviteExpiration: a || +new Date(new Date() + 259200000),
            groupName: i || c.getName(e),
            jpegThumbnail: await c.resize(r || "https://telegra.ph/file/0d25a520bfa0909c74466.jpg", 200, 200),
            caption: n || "Invitation to join my WhatsApp group"
          }
        }), {
          userJid: t,
          quoted: o
        });
        return await c.relayMessage(t, s.message, {
          messageId: s.key.id
        });
      }
    };
    c.groupQueryInvite = async e => {
      var e = await c.query({
        tag: "iq",
        attrs: {
          type: "get",
          xmlns: "w:g2",
          to: "@g.us"
        },
        content: [{
          tag: "invite",
          attrs: {
            code: e
          }
        }]
      });
      var e = getBinaryNodeChild(e, "group");
      var t = getBinaryNodeChild(e, "description");
      let s;
      let a;
      let i;
      let r;
      if (t) {
        s = getBinaryNodeChild(t, "body")?.content?.toString();
        a = t?.attrs?.id;
        i = t?.attrs?.participant;
        r = t?.attrs?.t;
      }
      return {
        id: e?.attrs?.id.includes("@") ? e?.attrs?.id : e?.attrs?.id + "@g.us",
        owner: e?.attrs?.creator,
        subject: e?.attrs?.subject,
        subjectOwner: e?.attrs?.s_o,
        subjectTime: e?.attrs?.s_t,
        size: e?.attrs?.size,
        creation: e?.attrs?.creation,
        participants: e?.content?.filter(e => e.tag == "participant").map(e => e.attrs),
        desc: s,
        descId: a,
        descOwner: i,
        descTime: r
      };
    };
    if (c.user && c.user.id) {
      c.user.jid = c.decodeJid(c.user.id);
    }
    c.ments = this.mention;
    c.makeid = e => randomBytes(e).toString("hex");
    c.sendMessageModify = (e, t = "", s = "", a = {}) => !!/^\d.*(@s\.whatsapp\.net|@g\.us|@newsletter)$/.test(e) && c.sendMessage(e, {
      text: t,
      contextInfo: {
        mentionedJid: this.mention(t),
        forwardingScore: 256,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: "120363375037255604@newsletter",
          newsletterName: `Ping : ${func.ping(4)} • Powered by ZidanDev`,
          serverMessageId: -1
        },
        externalAdReply: {
          showAdAttribution: a.ads,
          title: a.title || global.header,
          body: a.body || global.footer,
          mediaType: 1,
          previewType: "PHOTO",
          thumbnailUrl: a.thumbUrl,
          thumbnail: a.thumbnail,
          sourceUrl: a.url,
          renderLargerThumbnail: a.largeThumb
        }
      }
    }, {
      quoted: s,
      ephemeralExpiration: func.expiration(a.expiration),
      ...a
    });
    c.reply = async (e, t, s, a = {}) => !!/^\d.*(@s\.whatsapp\.net|@g\.us|@newsletter)$/.test(e) && (a && a.typing && (await c.sendPresenceUpdate(/^(composing|recording)$/.test(a.typing) ? a.typing : "composing", e)), c.sendMessage(e, {
      text: t,
      mentions: this.mention(t),
      ...a
    }, {
      quoted: s,
      ephemeralExpiration: func.expiration(a.expiration)
    }));
    c.sendReact = async (e, t, s = {}) => c.sendMessage(e, {
      react: {
        text: t,
        key: s
      }
    });
    c.sendPoll = (e, t = "", s = [], a = 1) => c.sendMessage(e, {
      poll: {
        name: t,
        values: s,
        selectableCount: a
      }
    });
    c.sendbut = async (e, t = "", a = "", i = [display, content], r, n = {}) => {
      var o;
      var d;
      if (!/^\d.*(@s\.whatsapp\.net|@g\.us|@newsletter)$/.test(e)) {
        return false;
      }
      if (Array.isArray(i) && i.length != 0) {
        n.mentions ||= [];
        let s = [];
        i.map(([e, t]) => {
          s.push({
            buttonId: t,
            buttonText: {
              displayText: e
            },
            type: 1
          });
        });
        if (n.media) {
          ({
            mime: o,
            data: d
          } = await c.getFile(n.media, true));
        }
        return c.sendMessage(e, {
          ...(n.media ? {
            ["" + o.split("/")[0]]: d,
            caption: t
          } : {
            text: t
          }),
          buttons: s,
          footer: a,
          mentions: [...n.mentions, ...this.mention(t)],
          viewOnce: true,
          headerType: 6
        }, {
          quoted: r,
          ephemeralExpiration: func.expiration(n.expiration)
        });
      }
    };
    c.sendButton = async (e, t = "", s = "", a = "", r = [type, s, content], n, o = {}) => {
      if (!/^\d.*(@s\.whatsapp\.net|@g\.us|@newsletter)$/.test(e)) {
        return false;
      }
      if (Array.isArray(r) && r.length != 0) {
        o.mentions ||= [];
        let i = [];
        r.map(([e, t, s], a) => e == "list" ? i.push({
          name: "single_select",
          buttonParamsJson: JSON.stringify({
            title: t,
            sections: s
          })
        }) : e == "button" ? i.push({
          name: "quick_reply",
          buttonParamsJson: JSON.stringify({
            display_text: t,
            id: s
          })
        }) : e == "url" ? i.push({
          name: "cta_url",
          buttonParamsJson: JSON.stringify({
            display_text: t,
            url: s,
            merchant_url: s
          })
        }) : e == "call" ? i.push({
          name: "cta_call",
          buttonParamsJson: JSON.stringify({
            display_text: t,
            id: s
          })
        }) : e == "copy" ? i.push({
          name: "cta_copy",
          buttonParamsJson: JSON.stringify({
            display_text: t,
            id: s,
            copy_code: s
          })
        }) : e == "reminder" ? i.push({
          name: "cta_reminder",
          buttonParamsJson: JSON.stringify({
            display_text: t,
            id: s
          })
        }) : e == "address" ? i.push({
          name: "address_message",
          buttonParamsJson: JSON.stringify({
            display_text: t,
            id: s
          })
        }) : e == "location" ? i.push({
          name: "send_location",
          buttonParamsJson: JSON.stringify({
            display_text: t,
            id: s
          })
        }) : undefined);
        if (o.media) {
          ({
            mime: d,
            data: m
          } = await c.getFile(o.media, true));
        }
        var d;
        var m;
        var r = generateWAMessageFromContent(e, proto.Message.fromObject({
          viewOnceMessage: {
            message: {
              interactiveMessage: proto.Message.InteractiveMessage.create({
                contextInfo: {
                  mentionedJid: [...o.mentions, ...this.mention(t + s)],
                  isForwarded: true,
                  forwardingScore: 256,
                  forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363375037255604@newsletter",
                    newsletterName: `Ping : ${func.ping(4)} • Powered by ZidanDev`,
                    serverMessageId: -1
                  }
                },
                body: proto.Message.InteractiveMessage.Body.create({
                  text: s
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                  text: a
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                  title: t,
                  subtitle: "ZidanDev",
                  hasMediaAttachment: !!o.media,
                  ...(o.media ? await prepareWAMessageMedia({
                    ["" + d.split("/")[0]]: m
                  }, {
                    upload: c.waUploadToServer
                  }) : {})
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                  buttons: i
                })
              })
            }
          }
        }), {
          userJid: c.user.jid,
          quoted: n
        });
        return c.relayMessage(r.key.remoteJid, r.message, {
          messageId: r.key.id
        });
      }
    };
    c.sendIAMessage = async (e, t = [], s, a = {}, i = {}) => {
      var r;
      var n;
      if (Array.isArray(t) && t.length != 0) {
        a.mentions ||= [];
        if (a.media) {
          ({
            mime: n,
            data: r
          } = await c.getFile(a.media, true));
          r = /image/.test(n) ? {
            imageMessage: (await prepareWAMessageMedia({
              image: r
            }, {
              upload: c.waUploadToServer
            })).imageMessage
          } : /video/.test(n) ? {
            videoMessage: (await prepareWAMessageMedia({
              video: r
            }, {
              upload: c.waUploadToServer
            })).videoMessage
          } : {};
        }
        n = generateWAMessageFromContent(e, {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2
              },
              interactiveMessage: {
                header: proto.Message.InteractiveMessage.create({
                  title: a.header || "",
                  subtitle: a.subtitle || "",
                  hasMediaAttachment: !!a.media && !!/image|video/.test(n),
                  ...r
                }),
                body: proto.Message.InteractiveMessage.create({
                  text: a.content || ""
                }),
                footer: proto.Message.InteractiveMessage.create({
                  text: a.footer || ""
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.create({
                  buttons: t,
                  messageParamsJson: ""
                }),
                contextInfo: {
                  mentionedJid: [...a.mentions, ...this.mention(a.content)],
                  isForwarded: true,
                  forwardingScore: 256,
                  forwardedNewsletterMessageInfo: {
                    newsletterJid: "120363375037255604@newsletter",
                    newsletterName: `Ping ${func.ping(4)} • Powered by ZidanDev`,
                    serverMessageId: -1
                  },
                  ...i
                }
              }
            }
          }
        }, {
          userJid: c.user.jid,
          quoted: s
        });
        await c.sendPresenceUpdate("composing", e);
        c.relayMessage(e, n.message, {
          messageId: n.key.id
        });
        return n;
      }
    };
    c.notify = async e => {
      var t = {
        mentionedJid: this.mention(e),
        externalAdReply: {
          title: "System Notification",
          body: global.header,
          thumbnailUrl: setting.cover,
          sourceUrl: "https://tiktok.com/@zidanstoreofficial",
          mediaType: 1,
          renderLargerThumbnail: false
        }
      };
      var e = {
        extendedTextMessage: {
          text: e,
          mentions: this.mention(e),
          contextInfo: t
        }
      };
      var t = proto.Message.encode(e).finish();
      return c.query({
        tag: "message",
        attrs: {
          to: "120363375037255604@newsletter",
          type: "text"
        },
        content: [{
          tag: "plaintext",
          attrs: {},
          content: t
        }]
      });
    };
    c.replyAI = async (e, t, s, a = {}) => {
      await c.sendPresenceUpdate("composing", e);
      var i = [];
      i.push({
        attrs: {
          biz_bot: "1"
        },
        tag: "bot"
      });
      i.push({
        attrs: {},
        tag: "biz"
      });
      var t = generateWAMessageFromContent(e, {
        extendedTextMessage: {
          text: t,
          contextInfo: {
            mentionedJid: this.mention(t),
            ...a
          },
          message: {
            messageContextInfo: {
              messageSecret: randomBytes(32),
              supportPayload: JSON.stringify({
                version: 1,
                is_ai_message: true,
                should_show_system_message: true,
                ticket_id: 1669945700536053
              })
            }
          }
        }
      }, {
        userJid: c.user.jid,
        quoted: s
      });
      c.relayMessage(e, t.message, {
        messageId: t.key.id,
        additionalNodes: i
      });
      return t;
    };
    c.setStatus = async e => c.query({
      tag: "iq",
      attrs: {
        to: "@s.whatsapp.net",
        type: "set",
        xmlns: "status"
      },
      content: [{
        tag: "status",
        attrs: {},
        content: Buffer.from(e, "utf-8")
      }]
    });
    c.resize = async (e, t, s) => {
      t = t || 400;
      s = s || 400;
      e = Buffer.isBuffer(e) ? e : /^data:.*?\/.*?;base64,/i.test(e) ? Buffer.from(e.split(",")[1], "base64") : /^https?:\/\//.test(e) ? await (await fetch(e)).buffer() : fs.existsSync(e) ? fs.readFileSync(e) : typeof e == "string" ? e : Buffer.alloc(0);
      if (Buffer.isBuffer(e)) {
        return await (await jimp.read(e)).resize(t, s).getBufferAsync(jimp.MIME_JPEG);
      }
      throw new TypeError("Result is not a buffer");
    };
    c.createprofile = async (e, t) => {
      t = await jimp.read(t);
      t = await t.crop(0, 0, await t.getWidth(), await t.getHeight()).scaleToFit(720, 720).getBufferAsync(jimp.MIME_JPEG);
      return c.query({
        tag: "iq",
        attrs: {
          to: "@s.whatsapp.net",
          type: "set",
          xmlns: "w:profile:picture"
        },
        content: [{
          tag: "picture",
          attrs: {
            type: "image"
          },
          content: t
        }]
      });
    };
    c.downloadM = async (e, t, s) => {
      if (!e || !e.url && !e.directPath) {
        return Buffer.alloc(0);
      }
      var a;
      var i;
      var e = await downloadContentFromMessage(e, t);
      let r = Buffer.from([]);
      for await (a of e) {
        r = Buffer.concat([r, a]);
      }
      if (s) {
        i = (await c.getFile(r, true)).filename;
      }
      if (s && fs.existsSync(i)) {
        return i;
      } else {
        return r;
      }
    };
    c.downloadAndSaveMediaMessage = async (e, t) => {
      var s;
      var a = ((e = (e.quoted ? e.quoted.message : e.msg.viewOnce) ? (a = e.quoted ? Object.keys(e.quoted.message)[0] : e.mtype, e.quoted ? e.quoted.message[a] : e.msg) : (a = e.quoted || e).msg || a).msg || e).mimetype || "";
      var a = e.mtype ? e.mtype.replace(/Message/gi, "") : a.split("/")[0];
      var e = await downloadContentFromMessage(e, a);
      let i = Buffer.from([]);
      for await (s of e) {
        i = Buffer.concat([i, s]);
      }
      a = await fromBuffer(i);
      e = "./sampah/" + (t || func.filename(a.ext));
      await fs.writeFileSync(e, i);
      return e;
    };
    c.getFile = async (e, t) => {
      let s;
      let a;
      var i;
      var e = Buffer.isBuffer(e) ? e : /^data:.*?\/.*?;base64,/i.test(e) ? Buffer.from(e.split(",")[1], "base64") : /^https?:\/\//.test(e) ? await (s = await fetch(e)).buffer() : fs.existsSync(e) ? (a = e, fs.readFileSync(e)) : typeof e == "string" ? e : Buffer.alloc(0);
      if (Buffer.isBuffer(e)) {
        i = (await fromBuffer(e)) || {
          mime: "application/octet-stream",
          ext: ".bin"
        };
        if (e && t && !a) {
          a = path.join(__dirname, "../sampah/" + +new Date() + "." + i.ext);
          await fs.promises.writeFile(a, e);
        }
        return {
          res: s,
          filename: a,
          ...i,
          data: e
        };
      }
      throw new TypeError("Result is not a buffer");
    };
    c.getmetadata = async t => {
      var s = await c.groupFetchAllParticipating();
      try {
        if (Object.keys(s).includes(t)) {
          return Object.values(s).find(e => e.id === t);
        } else {
          return {};
        }
      } catch (e) {
        if (Object.keys(s).includes(t)) {
          return (await c.groupMetadata(t)) || {};
        } else {
          return {};
        }
      }
    };
    c.isgroup = s => new Promise(async e => {
      var t = await c.groupFetchAllParticipating();
      e(!!Object.keys(t).find(e => e === s));
    });
    c.sendMedia = async (e, t, s, a = {}) => {
      var {
        mime: t,
        data: i
      } = await c.getFile(t);
      var r = t.split("/")[0];
      var r = r.replace("application", "document") || r;
      return c.sendMessage(e, {
        ["" + r]: i,
        mimetype: t,
        ...a
      }, {
        quoted: s,
        ephemeralExpiration: func.expiration(a.expiration)
      });
    };
    c.sendFile = async (e, t, s = "", a, i = false, r = {}) => {
      t = await c.getFile(t, true);
      let {
        res: n,
        data: o,
        filename: d
      } = t;
      if (n && n.status !== 200 || o.length <= 65536) {
        try {
          throw {
            json: JSON.parse(o.toString())
          };
        } catch (e) {
          if (e.json) {
            throw e.json;
          }
        }
      }
      if (!t) {
        r.asDocument = true;
      }
      let m = "";
      let g = t.mime;
      let p;
      if (/webp/.test(t.mime) || /image/.test(t.mime) && r.asSticker) {
        m = "sticker";
      } else if (/image/.test(t.mime) || /webp/.test(t.mime) && r.asImage) {
        m = "image";
      } else if (/video/.test(t.mime)) {
        m = "video";
      } else if (/audio/.test(t.mime)) {
        p = await (i ? toPTT : toAudio)(o, t.ext);
        o = p.data;
        d = p.filename;
        m = "audio";
        g = "audio/ogg; codecs=opus";
      } else {
        m = "document";
      }
      if (r.asDocument) {
        m = "document";
      }
      t = {
        ...r,
        caption: s,
        ptt: i,
        [m]: {
          url: d
        },
        mimetype: g
      };
      let u;
      try {
        u = await c.sendMessage(e, t, {
          quoted: a,
          ephemeralExpiration: func.expiration(r.expiration)
        });
      } catch (e) {
        c.logger.error(e);
        u = null;
      } finally {
        return u = u || (await c.sendMessage(e, {
          ...t,
          [m]: o
        }, {
          quoted: a,
          ephemeralExpiration: func.expiration(r.expiration)
        }));
      }
    };
    c.sendStickerFromUrl = async (e, t, s, a = {}) => {
      var i = require("../lib/sticker").writeExif;
      var {
        filename: t,
        mime: r,
        data: n
      } = await c.getFile(t, true);
      var i = await i({
        mimetype: r,
        data: n
      }, {
        packname: a.packname || "Zidan Ft Kayla.",
        author: a.author || "",
        categories: a.categories || []
      });
      await fs.promises.unlink(t);
      return c.sendMessage(e, {
        sticker: {
          url: i
        }
      }, {
        quoted: s,
        ephemeralExpiration: func.expiration(a.expiration),
        ...a
      });
    };
    c.sendSticker = async (e, t, s, a = {}) => {
      var t = /^https?:\/\//.test(t) ? await (await fetch(t)).buffer() : Buffer.isBuffer(t) ? t : /^data:.*?\/.*?;base64,/i.test(t) ? Buffer.from(t.split(",")[1], "base64") : Buffer.alloc(0);
      var i = (await fromBuffer(t)).mime;
      var i = /image\/(jpe?g|png|gif)|octet/.test(i) ? a && (a.packname || a.author) ? await writeExifImg(t, a) : await imageToWebp(t) : /video/.test(i) ? a && (a.packname || a.author) ? await writeExifVid(t, a) : await videoToWebp(t) : /webp/.test(i) ? await writeExifWebp(t, a) : Buffer.alloc(0);
      return c.sendMessage(e, {
        sticker: {
          url: i
        },
        ...a
      }, {
        quoted: s,
        ephemeralExpiration: func.expiration(a.expiration)
      });
    };
    c.sendkontak = (e, t, s, a, i = {}) => {
      t = t.replace(/[^0-9]/g, "");
      return c.sendMessage(e, {
        contacts: {
          displayName: s,
          contacts: [{
            vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:" + s + "\nORG:;\nTEL;type=CELL;type=VOICE;waid=" + t + ":+" + t + "\nitem1.X-ABLabel:Ponsel\nitem2.EMAIL;type=INTERNET:zidanmubarok9876@gmail.com\nitem2.X-ABLabel:Email\nitem3.URL:https://instagram.com/zidanstoreofficial\nitem3.X-ABLabel:Instagram\nitem4.ADR:;;Indonesia;;;;\nitem4.X-ABLabel:Region\nEND:VCARD"
          }]
        },
        mentions: [t + "@s.whatsapp.net"]
      }, {
        quoted: a,
        ephemeralExpiration: func.expiration(i.expiration)
      });
    };
    c.sendkontakV2 = (e, t, s = [satu = "", dua = "", tiga = ""], a = "", i = {}) => {
      t = {
        contacts: {
          displayName: t,
          contacts: s.map(e => ({
            displayName: e[0],
            vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:" + e[0] + "\nORG:" + e[2] + ";\nTEL;type=CELL;type=VOICE;waid=" + e[1] + ":+" + e[1] + "\nEND:VCARD"
          }))
        },
        ...i
      };
      return c.sendMessage(e, t, {
        quoted: a,
        ephemeralExpiration: func.expiration(i.expiration)
      });
    };
    c.sendContact = async (e, t, s, a = {}, i = {}) => {
      let r = [];
      t.map(e => r.push({
        displayName: e.name,
        vcard: "BEGIN:VCARD\nVERSION:3.0\nFN:" + e.name + "\nORG:;\nTEL;type=CELL;type=VOICE;waid:" + e.number + ":" + phoneNumber("+" + e.number).getNumber("international") + "\nEMAIL;type=Email:" + (a && a.email ? a.email : "zidanmubarok9876@gmail.com") + "\nURL;type=Website:" + (a && a.website ? a.website : "https://zidandev.vercel.app") + "\nADR;type=Location:;;Unknown;;\nOther:" + e.about + "\nEND:VCARD"
      }));
      return c.sendMessage(e, {
        contacts: {
          displayName: r.length + " Contact",
          contacts: r
        },
        ...i
      }, {
        quoted: s,
        ephemeralExpiration: func.expiration(i.expiration)
      });
    };
    c.copyNForward = async (e, t, s = false, a = {}) => {
      if (a.readViewOnce) {
        t.message = t.message && t.message.ephemeralMessage && t.message.ephemeralMessage.message ? t.message.ephemeralMessage.message : t.message || undefined;
        i = Object.keys(t.message.viewOnceMessage.message)[0];
        if (t.message && t.message.ignore) {
          t.message.ignore;
        } else {
          t.message;
        }
        delete t.message.viewOnceMessage.message[i].viewOnce;
        t.message = {
          ...t.message.viewOnceMessage.message
        };
      }
      var i = Object.keys(t.message)[0];
      var s = await generateForwardMessageContent(t, s);
      var r = Object.keys(s)[0];
      let n = {};
      if (i != "conversation") {
        n = t.message[i].contextInfo;
      }
      s[r].contextInfo = {
        ...n,
        ...s[r].contextInfo
      };
      t = await generateWAMessageFromContent(e, s, a ? {
        ...s[r],
        ...a,
        ...(a.contextInfo ? {
          contextInfo: {
            ...s[r].contextInfo,
            ...a.contextInfo
          }
        } : {})
      } : {});
      await c.relayMessage(e, t.message, {
        quoted: a.quoted,
        ephemeralExpiration: 86400,
        messageId: t.key.id
      });
      return t;
    };
    c.cMod = async (e, t, s = "", a = c.user.id, i = {}) => {
      if (getContentType(t.message) === "ephemeralMessage") {
        r = Object.keys(t.message.ephemeralMessage.message)[0];
        t.message = t.message.ephemeralMessage.message[r];
      }
      var r = t.message;
      if (typeof r == "string") {
        t.message = s || r;
      } else if (s || r.caption) {
        r.caption = s || r.caption;
      } else {
        r.text &&= s || r.text;
      }
      if (typeof r != "string") {
        t.message = {
          ...r,
          ...i
        };
      }
      if (t.key.participant) {
        a = a || t.key.participant;
      } else if (t.key.remoteJid.includes("@s.whatsapp.net") || t.key.remoteJid.includes("@broadcast")) {
        a = a || t.key.remoteJid;
      }
      t.key.remoteJid = e;
      t.key.fromMe = areJidsSameUser(a, c.user && c.user.id);
      return proto.WebMessageInfo.fromObject(t);
    };
    c.downloadMediaMessage = async e => {
      if ((e.quoted || e)?.msg?.viewOnce) {
        s = e.quoted ? Object.keys(e.quoted.message)[0] : e.mtype;
        e = e.quoted ? e.quoted.message[s] : e.msg;
      }
      var t;
      var s = (e.msg || e).mimetype || "";
      var s = e.mtype ? e.mtype.replace(/Message/gi, "") : s.split("/")[0];
      var e = await downloadContentFromMessage(e, s);
      let a = Buffer.from([]);
      for await (t of e) {
        a = Buffer.concat([a, t]);
      }
      return a;
    };
    c.preSudo = async (e, t, s, a) => {
      e = await generateWAMessage(s.chat, {
        text: e,
        mentions: s.mentionedJid
      }, {
        userJid: t,
        quoted: s.quoted && s.quoted.fakeObj
      });
      e.key.fromMe = areJidsSameUser(t, c.user.id);
      e.key.id = s.key.id;
      e.pushName = s.pushname;
      if (s.isGc) {
        e.key.participant = e.participant = t;
      }
      s = {
        ...a,
        messages: [proto.WebMessageInfo.fromObject(e)].map(e => {
          e.anya = this;
          return e;
        }),
        type: "append"
      };
      c.ev.emit("messages.upsert", s);
    };
    return c;
  };
  initSerialize = (i, r, t) => {
    if (!r) {
      return r;
    }
    var e = proto.WebMessageInfo;
    var s = () => {
      try {
        if (Object.keys(r.message)[0] == "senderKeyDistributionMessage") {
          if (Object.keys(r.message)[2] == "messageContextInfo") {
            return Object.keys(r.message)[1];
          } else {
            return Object.keys(r.message)[2];
          }
        } else if (Object.keys(r.message)[0] != "messageContextInfo") {
          return Object.keys(r.message)[0];
        } else {
          return Object.keys(r.message)[1];
        }
      } catch {
        return null;
      }
    };
    var n = e => !!/^(?=.{16}$)(ANYA|LULLI|BAE5)/.test(e) || !!/^(?=.{20}$)(B24E|B1EY)/.test(e) || !!/^(?=.{22}$)(3EB0)/.test(e);
    if (r.key) {
      r.id = r.key.id;
      r.isBot = !/pollCreationMessage/.test(s()) && n(r.id);
      r.chat = r.key.remoteJid;
      r.fromMe = !/pollCreationMessage/.test(s()) && r.key.fromMe;
      r.isGc = r.chat.endsWith("@g.us");
      r.isPc = r.chat.endsWith("@s.whatsapp.net");
      r.sender = r.fromMe ? i.user.id.split(":")[0] + "@s.whatsapp.net" || i.user.id : r.key.participant || r.key.remoteJid;
    }
    if (r.message) {
      r.pushname = r.pushName || "";
      r.bot = i.user.id ? i.user.id.split(":")[0] + "@s.whatsapp.net" : i.user.jid;
      r.setting = global.db.setting ? global.db.setting[r.bot] : {};
      r.user = {
        id: r.sender,
        device: r.isBot ? "web" : "smartphone",
        jadibot: !!i.user.jadibot
      };
      if (r.isGc) {
        r.metadata = global.db.metadata[r.chat] || {};
        r.groupName = r.metadata?.subject || "";
        r.members = r.metadata?.participants || [];
        r.admins = r.members.reduce((e, t) => (t.admin ? e.push({
          id: t.id,
          admin: t.admin
        }) : [...e]) && e, []);
        r.isAdmin = !!r.admins.find(e => e.id === r.sender);
        r.isBotAdmin = !!r.admins.find(e => e.id === r.bot);
      }
      if (r.message.viewOnceMessage) {
        r.mtype = Object.keys(r.message.viewOnceMessage.message)[0];
        r.msg = r.message.viewOnceMessage.message[r.mtype];
      } else if (r.message.viewOnceMessageV2) {
        r.mtype = Object.keys(r.message.viewOnceMessageV2.message)[0];
        r.msg = r.message.viewOnceMessageV2.message[r.mtype];
      } else {
        r.mtype = s();
        r.msg = r.message[r.mtype];
      }
      if (r.mtype === "ephemeralMessage" || r.mtype === "documentWithCaptionMessage") {
        this.initSerialize(i, r.msg, t);
        r.mtype = r.msg.mtype;
        r.msg = r.msg.msg;
      }
      r.isMedia = !!r.msg?.mimetype;
      if (r.isMedia && (r.mime = r.msg?.mimetype, r.size = r.msg?.fileLength, r.height = r.msg?.height || "", r.width = r.msg?.width || "", /webp/i.test(r.mime) && (r.isAnimated = r.msg?.isAnimated), /audio|video/i.test(r.mime))) {
        r.seconds = r.msg?.seconds;
      }
      s = r.quoted = r.msg !== undefined && r.msg.contextInfo ? r.msg.contextInfo.quotedMessage : null;
      r.mentionedJid = r.msg !== undefined && r.msg.contextInfo ? r.msg.contextInfo.mentionedJid : [];
      if (r.quoted) {
        var o = Object.keys(r.quoted)[0];
        r.quoted = r.quoted[o];
        if (/productMessage|documentWithCaptionMessage/i.test(o)) {
          o = Object.keys(r.quoted)[0];
          r.quoted = r.quoted[o];
        }
        if (typeof r.quoted == "string") {
          r.quoted = {
            text: r.quoted
          };
        }
        r.quoted.id = r.msg.contextInfo.stanzaId;
        r.quoted.chat = r.msg.contextInfo.remoteJid || r.chat;
        r.quoted.isBot = !!r.quoted.id && n(r.quoted.id);
        r.quoted.sender = r.msg.contextInfo.participant.split(":")[0] || r.msg.contextInfo.participant;
        r.quoted.fromMe = areJidsSameUser(r.quoted.sender, i.user && i.user.id);
        r.quoted.mentionedJid = r.msg.contextInfo ? r.msg.contextInfo.mentionedJid : [];
        r.quoted.copyNForward = (e, t = false, s = {}) => i.copyNForward(e, a, t, s);
        r.getQuotedObj = async () => {
          var e;
          return !!r.quoted.id && (e = await t.loadMessage(r.chat, r.quoted.id), this.initSerialize(i, e, t));
        };
        let a = r.quoted.fakeObj = e.fromObject({
          key: {
            remoteJid: r.quoted.chat,
            fromMe: r.quoted.fromMe,
            id: r.quoted.id
          },
          message: s,
          ...(r.isGc ? {
            participant: r.quoted.sender
          } : {})
        });
        r.quoted.mtype = r.quoted != null ? Object.keys(r.quoted.fakeObj.message)[0] : null;
        r.quoted.text = r.quoted?.text || r.quoted?.caption || (r.quoted.mtype === "interactiveMessage" ? r.quoted?.body?.text : "") || (/viewOnceMessage/.test(r.quoted.mtype) ? r.quoted.message[Object.keys(r.quoted.message)[0]].caption : "") || (r.quoted.mtype == "buttonsMessage" ? r.quoted.contentText : "") || (r.quoted.mtype == "templateMessage" ? r.quoted?.hydratedFourRowTemplate?.hydratedContentText : "") || "";
        r.quoted.isMedia = !!(r.quoted.message ? r.quoted.message[Object.keys(r.quoted.message)[0]] : r.quoted).mimetype;
        r.quoted.download = () => {
          var e;
          if (r.quoted.isMedia) {
            e = r.quoted.message ? Object.keys(r.quoted.message)[0] : r.quoted;
            e = r.quoted.message ? r.quoted.message[e] : r.quoted;
            return i.downloadMediaMessage(e);
          }
        };
        if (r.quoted.isMedia && (o = r.quoted.message ? Object.keys(r.quoted.message)[0] : r.quoted, n = r.quoted.message ? r.quoted.message[o] : r.quoted, r.quoted.mime = n.mimetype, r.quoted.size = n.fileLength, r.quoted.height = n.height || "", r.quoted.width = n.width || "", /webp/i.test(r.quoted.mime) && (r.quoted.isAnimated = n.isAnimated || false), /audio|video/i.test(r.quoted.mime))) {
          r.quoted.seconds = n.seconds;
        }
      }
      r.reply = async (e, t = {}) => {
        i.sendMessage(r.chat, {
          text: e,
          contextInfo: r.setting.fakereply ? {
            mentionedJid: [r.sender, ...this.mention(e)],
            forwardingScore: 256,
            isForwarded: true,
            externalAdReply: {
              title: global.header,
              body: global.fake,
              sourceUrl: "https://whatsapp.com/channel/0029VayOUJW2975HrgEX6T24",
              thumbnail: await (await fetch(r.setting.cover)).buffer()
            }
          } : {
            mentionedJid: [r.sender, ...this.mention(e)]
          },
          ...t
        }, {
          quoted: r,
          ephemeralExpiration: func.expiration(r.expiration),
          detectLinks: false,
          ...t
        });
      };
      r.copyNForward = (e = r.chat, t, s = false, a = {}) => i.copyNForward(e, t, s, a);
      if (r.msg !== undefined && r.msg.url) {
        r.download = () => i.downloadMediaMessage(r.msg);
      }
    }
    r.body = (r.mtype == "interactiveResponseMessage" ? JSON.parse(r.msg?.nativeFlowResponseMessage?.paramsJson).id : "") || (r.mtype == "stickerMessage" && global.db && global.db.stickercmd && global.db.stickercmd[r.msg.fileSha256.toString()] !== undefined ? global.db.stickercmd[r.msg.fileSha256.toString()].text : "") || (r.mtype == "editedMessage" ? r.msg.message?.protocolMessage?.editedMessage?.extendedTextMessage?.text : "") || (r.mtype == "listResponseMessage" ? r.message.listResponseMessage.singleSelectReply.selectedRowId : "") || (r.mtype == "buttonsResponseMessage" ? r.message.buttonsResponseMessage.selectedButtonId : "") || (r.mtype == "templateButtonReplyMessage" ? r.message.templateButtonReplyMessage.selectedId : "") || (r.msg !== undefined ? r.msg.text : "") || (r.msg !== undefined ? r.msg.caption : "") || r.msg || "";
    r.budy = typeof r.body == "string" ? r.body : "";
    r.prefix = r.setting.multiprefix ? global.prefixes.test(r.budy) ? r.budy.match(global.prefixes)[0] : "." : r.setting.prefix;
    r.isDevs = [...global.developer, ...global.devs].includes(r.sender);
    r.isOwner = [global.owner, r.bot, ...(r?.setting?.owner || []), ...global.developer, ...global.devs].includes(r.sender);
    r.isPrem = [...Object.values(global.db.users).filter(user => user.premium).map(item => item.jid)].includes(r.sender);
    r.isVvip = [...Object.values(global.db.users).filter(user => user.vvip).map(item => item.jid)].includes(r.sender);
    r.isPrefix = r.budy.startsWith(r.prefix);
    r.command = (r.isOwner || r.isPrem || r.isVvip) ? r.budy.replace(r.prefix, '').trim().split(/ +/).shift().toLowerCase() : r.isPrefix ? r.budy.replace(r.prefix, '').trim().split(/ +/).shift().toLowerCase() : '';
    r.cmd = r.prefix + r.command;
    r.arg = r.budy.trim().split(/ +/).filter(e => e) || [];
    r.args = r.budy.trim().replace(new RegExp("^" + func.escapeRegExp(r.prefix), "i"), "").replace(r.budy.replace(r.prefix, "").trim().split(/ +/).shift(), "").split(/ +/).filter(e => e) || [];
    r.text = r.args.join(" ");
    r.expiration = r.msg?.contextInfo?.expiration || 0;
    return e.fromObject(r);
  };
  initPrototype = () => {
    Number.prototype.rupiah = function () {
      var e = this.toString();
      var t = e.length % 3;
      var s = e.substr(0, t);
      var e = e.substr(t).match(/\d{3}/g);
      if (e) {
        s += (t ? "," : "") + e.join(",");
      }
      return s;
    };
    Array.prototype.random = function () {
      return this[Math.floor(Math.random() * this.length)];
    };
    Number.prototype.datestring = function () {
      var e = this.getFullYear();
      var t = this.getMonth();
      return `${this.getDate()}-${t + 1}-${e} ${this.getHours()}:${this.getMinutes()}`;
    };
    Number.prototype.timers = function () {
      var e = Math.floor(this / 1000 % 60);
      var t = Math.floor(this / 60000 % 60);
      var s = Math.floor(this / 3600000 % 24);
      var a = Math.floor(this / 86400000);
      return (a ? a + " hari " : "") + (s ? s + " jam " : "") + (t ? t + " menit " : "") + (e ? e + " detik" : "");
    };
    Number.prototype.sizeString = function (e = 2) {
      var t;
      if (this === 0) {
        return "0 Bytes";
      } else {
        e = e < 0 ? 0 : e;
        t = Math.floor(Math.log(this) / Math.log(1024));
        return parseFloat((this / Math.pow(1024, t)).toFixed(e)) + " " + ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"][t];
      }
    };
    Number.prototype.toTimeString = function () {
      var e = Math.floor(this / 1000 % 60);
      var t = Math.floor(this / 60000 % 60);
      var s = Math.floor(this / 3600000 % 24);
      var a = Math.floor(this / 86400000);
      return ((a ? a + " day " : "") + (s ? s + " hour " : "") + (t ? t + " minute " : "") + (e ? e + " second" : "")).trim();
    };
  };
};
func.reloadFile(__filename);